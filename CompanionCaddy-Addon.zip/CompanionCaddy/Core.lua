-------------------------------------------------------------------------------
-- Companion Caddy  —  Core.lua
-- Care system, pet state, challenges, minimap, slash commands, server comms.
--
-- Inspired by MurlocMinder (original concept by Kagrok).
-- Rebuilt from the ground up for WoW 3.3.5a compatibility.
-------------------------------------------------------------------------------

CC = {}
_G.CompanionCaddy = CC
CC.VERSION = "0.2.0"

-------------------------------------------------------------------------------
-- C_Timer polyfill (not available in 3.3.5a)
-------------------------------------------------------------------------------
if not C_Timer then
    C_Timer = {}
    local _tf = CreateFrame("Frame")
    local _tq = {}
    _tf:SetScript("OnUpdate", function(_, dt)
        for i = #_tq, 1, -1 do
            local t = _tq[i]
            t.e = t.e + dt
            if t.e >= t.d then table.remove(_tq, i); t.fn() end
        end
    end)
    function C_Timer.After(d, fn)
        table.insert(_tq, { d = d, e = 0, fn = fn })
    end
end

-------------------------------------------------------------------------------
-- Constants
-------------------------------------------------------------------------------
CC.TICK_INTERVAL  = 5       -- seconds per care decay tick

CC.DECAY = {                -- stat points lost per tick (5s)
    hunger      = 0.25,     -- empty in ~33 min
    joy         = 0.20,     -- ~42 min
    energy      = 0.15,     -- ~55 min
    cleanliness = 0.10,     -- ~83 min
}

CC.BOND_PER_ACTION = 4.0    -- bonding progress per soothe/warm/clean
CC.ACTION_COOLDOWN = 30     -- seconds between same care action
CC.TREAT_PER_ACTION   = 2   -- treats earned per care action
CC.TREAT_PER_CHALLENGE = 5  -- treats earned per challenge completion

CC.SCAVENGE_OPTS = {
    { label = "30 min",  sec = 1800, min = 8,  max = 18, tier = "green"  },
    { label = "1 hour",  sec = 3600, min = 18, max = 35, tier = "blue"   },
    { label = "2 hours", sec = 7200, min = 35, max = 65, tier = "purple" },
}

CC.PERSONALITIES = {
    { key = "Playful",     stat = "joy",         bonus = 0.15, desc = "Extra joyful." },
    { key = "Lazy",        stat = "energy",       bonus = 0.15, desc = "Loves to rest." },
    { key = "Glutton",     stat = "hunger",       bonus = 0.15, desc = "Always hungry." },
    { key = "Pristine",    stat = "cleanliness",  bonus = 0.15, desc = "Loves to be clean." },
    { key = "Adventurous", stat = nil,            bonus = 0.20, desc = "Born scavenger.", scavengeBonus = true },
    { key = "Cautious",    stat = nil,            bonus = 0.10, desc = "Methodical care.", cooldownReduce = true },
}

-------------------------------------------------------------------------------
-- Care quality tiers
-------------------------------------------------------------------------------
CC.CARE_TIERS = {
    { key = "struggling", label = "Struggling", min = 0,  color = {0.85, 0.35, 0.30} },
    { key = "okay",       label = "Okay",       min = 26, color = {0.85, 0.75, 0.30} },
    { key = "good",       label = "Good",       min = 51, color = {0.55, 0.85, 0.40} },
    { key = "thriving",   label = "Thriving",   min = 76, color = {0.45, 0.80, 1.00} },
}

-------------------------------------------------------------------------------
-- Care streak / Treat combo
-------------------------------------------------------------------------------
CC.STREAK_STEP_SECONDS  = 300   -- one "step" of sustained Thriving care
CC.STREAK_MULT_PER_STEP = 0.05  -- +5% Treats per step
CC.STREAK_MULT_MAX      = 0.50  -- cap at +50% Treats
CC.STREAK_MULT_DECAY    = 0.10  -- lost per drop out of Thriving (not a full reset)
CC.STREAK_ITEM_CHANCE   = 0.15  -- chance per step of also getting a free Care Item

-------------------------------------------------------------------------------
-- Neglect
-------------------------------------------------------------------------------
CC.NEGLECT_WARN_AVG     = 15      -- avg-of-four that starts the "at risk" clock
CC.NEGLECT_MIN_MULT     = 2.0     -- penalty if caught quickly after the warning
CC.NEGLECT_MAX_MULT     = 5.0     -- penalty if left neglected a full day+
CC.NEGLECT_RAMP_SECONDS = 86400   -- time to ramp from MIN to MAX

-------------------------------------------------------------------------------
-- Spontaneous companion events
-------------------------------------------------------------------------------
CC.SPONT_EVENT_CHECK_SECONDS = 300   -- how often a roll is even attempted
CC.SPONT_EVENT_CHANCE        = 0.12  -- chance on each roll, while Good/Thriving

CC.SPONT_EVENT_FLAVOR = {
    "%s nuzzles up to you happily and nudges over a %s it had stashed away!",
    "%s is clearly thrilled with all the attention, and surprises you with a %s!",
    "While playing, %s digs up a %s from somewhere nearby!",
    "%s's good mood is contagious -- you find a %s tucked in with your things!",
}

-- Profession skill-line IDs (3.3.5a values)
local PROF = {
    herbalism = 182, mining = 186, skinning = 393,
    fishing   = 356, cooking = 185,
}

CC.CHALLENGE_DEFS = {
    { type = "feed",              label = "Feed your companion 5 times",           goal = 5,  reward = 12, companionOnly = true,  hint = "Click Feed in Care Actions, or use a Care Item." },
    { type = "play",              label = "Play with your companion 5 times",       goal = 5,  reward = 12, companionOnly = true,  hint = "Click Play in Care Actions." },
    { type = "rest",              label = "Help your companion rest 5 times",       goal = 5,  reward = 12, companionOnly = true,  hint = "Click Rest in Care Actions." },
    { type = "clean",             label = "Clean your companion 5 times",           goal = 5,  reward = 12, companionOnly = true,  hint = "Click Clean in Care Actions." },
    { type = "soothe",            label = "Soothe your companion 3 times",          goal = 3,  reward = 10, bondingOnly = true,    hint = "Click Soothe during the Bonding stage." },
    { type = "warm",              label = "Warm your companion 3 times",            goal = 3,  reward = 10, bondingOnly = true,    hint = "Click Warm during the Bonding stage." },
    { type = "summon_companion",  label = "Summon your companion",                  goal = 1,  reward =  8, hint = "Cast your companion's summon spell." },
    { type = "scavenge",          label = "Complete a scavenging session",          goal = 1,  reward = 15, companionOnly = true,  hint = "Start a scavenge and wait for it to finish." },
    { type = "scavenge_squad",    label = "Send 3 companions scavenging at once",   goal = 1,  reward = 30, hint = "Have 3 different companions all out scavenging simultaneously -- requires owning multiple companion pets." },
    { type = "quest_turnin",      label = "Turn in 3 quests",                       goal = 3,  reward = 25, hint = "Hand in completed quests to any quest giver." },
    { type = "dungeon_complete",  label = "Complete a dungeon",                     goal = 1,  reward = 30, minLevel = 15, hint = "Finish a dungeon via the Dungeon Finder." },
    { type = "leave_combat",      label = "Survive 3 fights",                       goal = 3,  reward = 18, hint = "Leave combat alive 3 separate times." },
    { type = "level_up",          label = "Level up!",                              goal = 1,  reward = 50, maxLevel = 79, hint = "Gain a character level." },
    { type = "emote_dance",       label = "Dance for your companion  (/dance)",     goal = 1,  reward = 12, hint = "Type /dance in chat." },
    { type = "emote_salute",      label = "Salute your companion  (/salute)",       goal = 1,  reward =  8, hint = "Type /salute in chat." },
    { type = "emote_wave",        label = "Wave hello 3 times  (/wave)",            goal = 3,  reward = 10, hint = "Type /wave in chat 3 times." },
    { type = "emote_laugh",       label = "Share a laugh  (/laugh)",                goal = 1,  reward =  8, hint = "Type /laugh in chat." },
    { type = "emote_cheer",       label = "Cheer for your companion  (/cheer)",     goal = 1,  reward =  8, hint = "Type /cheer in chat." },
    { type = "emote_bow",         label = "Take a bow  (/bow)",                     goal = 1,  reward =  8, hint = "Type /bow in chat." },
    { type = "visit_inn",         label = "Rest at an inn",                         goal = 1,  reward = 10, hint = "Stand inside any inn until you see the Zzz icon." },
    { type = "visit_major_city",  label = "Visit a major city",                     goal = 1,  reward = 10, hint = "Travel to any major capital city." },
    { type = "check_mail",        label = "Check your mail",                        goal = 1,  reward =  8, hint = "Open any mailbox." },
    { type = "visit_vendor",      label = "Visit a vendor",                         goal = 1,  reward =  8, hint = "Open a vendor/merchant window." },
    { type = "visit_trainer",     label = "Visit a trainer",                        goal = 1,  reward =  8, hint = "Open any class or profession trainer window." },
    { type = "visit_bank",        label = "Open your bank",                         goal = 1,  reward =  8, hint = "Open your bank in any city." },
    { type = "use_hearthstone",   label = "Use your Hearthstone",                   goal = 1,  reward = 12, hint = "Use your Hearthstone item." },
    { type = "use_mount",         label = "Ride a mount",                           goal = 1,  reward =  8, minLevel = 20, hint = "Summon a mount, or take a flight path." },
    { type = "use_bandage",       label = "Use a First Aid bandage",                goal = 1,  reward = 10, hint = "Apply a bandage from First Aid." },
    { type = "craft_anything",    label = "Craft something",                        goal = 1,  reward = 10, hint = "Create any item from a profession window." },
    { type = "fish_zone",         label = "Catch 3 fish",                           goal = 3,  reward = 15, needsProf = "fishing",   hint = "Fish up 3 catches (requires Fishing)." },
    { type = "cook_food",         label = "Cook some food",                         goal = 1,  reward = 12, needsProf = "cooking",   hint = "Cook a recipe (requires Cooking)." },
    { type = "gather_herb",       label = "Gather 5 herbs",                         goal = 5,  reward = 18, needsProf = "herbalism", hint = "Pick 5 herbs (requires Herbalism)." },
    { type = "gather_ore",        label = "Mine 3 ore",                             goal = 3,  reward = 18, needsProf = "mining",    hint = "Mine 3 ore (requires Mining)." },
    { type = "gather_skin",       label = "Skin 3 beasts",                          goal = 3,  reward = 15, needsProf = "skinning",  hint = "Skin 3 corpses (requires Skinning)." },

    -- World activity
    { type = "loot_gold",         label = "Loot gold 5 times",                      goal = 5,  reward =  8, hint = "Loot any amount of gold from a kill or container." },
    { type = "gain_reputation",   label = "Gain reputation 3 times",                goal = 3,  reward = 15, hint = "Complete quests or kill enemies that raise a faction's standing." },
    { type = "honorable_kill",    label = "Earn Honor from a kill",                 goal = 1,  reward = 15, minLevel = 10, hint = "Get an honorable kill in a battleground or in the open world." },
    { type = "explore_zone",      label = "Discover a new zone",                    goal = 1,  reward = 10, hint = "Travel to a zone you haven't been to yet on this character." },
    { type = "trade_player",      label = "Trade with another player",              goal = 1,  reward =  8, hint = "Open a trade window with another player." },
    { type = "visit_auction_house", label = "Visit the Auction House",              goal = 1,  reward =  8, hint = "Open an Auctioneer's Auction House window." },
    { type = "group_up",          label = "Group up with another player",           goal = 1,  reward = 10, hint = "Form or join a party." },
    { type = "loot_rare_item",    label = "Loot a rare item or better",             goal = 1,  reward = 15, hint = "Loot a blue (rare) or purple (epic) quality item." },
    { type = "learn_companion",   label = "Learn a new companion pet",              goal = 1,  reward = 20, hint = "Use a new companion pet item to add it to your collection." },
    { type = "duel_request",      label = "Take part in a friendly duel",           goal = 1,  reward = 10, hint = "Accept another player's duel challenge." },
    { type = "return_from_death", label = "Recover from a death",                   goal = 1,  reward = 12, hint = "Get resurrected, or release and return from the graveyard." },
    { type = "roll_dice",         label = "Try your luck  (/roll)",                 goal = 1,  reward =  8, hint = "Type /roll in chat." },

    -- More emotes -- same "type /x in chat" pattern as the existing ones.
    { type = "emote_thank",       label = "Say thanks  (/thank)",                   goal = 1,  reward =  8, hint = "Type /thank in chat." },
    { type = "emote_cry",         label = "Have a good cry  (/cry)",                goal = 1,  reward =  8, hint = "Type /cry in chat." },
    { type = "emote_roar",        label = "Let out a roar  (/roar)",                goal = 1,  reward =  8, hint = "Type /roar in chat." },
    { type = "emote_yawn",        label = "Yawn for your companion  (/yawn)",       goal = 1,  reward =  8, hint = "Type /yawn in chat." },
    { type = "emote_clap",        label = "Give a round of applause  (/applaud)",   goal = 1,  reward =  8, hint = "Type /applaud in chat." },

    -- Class-specific -- one per class, using the existing classOnly filter.
    { type = "mage_conjure",        label = "Conjure food or water",                goal = 1,  reward = 10, classOnly = "MAGE",        hint = "Cast a Conjure Food, Water, or Mana Gem spell." },
    { type = "warlock_summon_pet",  label = "Summon your demon",                    goal = 1,  reward = 10, classOnly = "WARLOCK",     hint = "Summon an Imp, Voidwalker, Succubus, or Felhunter." },
    { type = "paladin_blessing",    label = "Bestow a Blessing",                    goal = 1,  reward = 10, classOnly = "PALADIN",     hint = "Cast any Blessing on yourself or an ally." },
    { type = "priest_heal",         label = "Cast a healing spell 3 times",         goal = 3,  reward = 12, classOnly = "PRIEST",      hint = "Heal yourself or an ally 3 times." },
    { type = "hunter_feign_death",  label = "Play dead  (Feign Death)",             goal = 1,  reward =  8, classOnly = "HUNTER",      hint = "Cast Feign Death." },
    { type = "rogue_stealth",       label = "Slip into the shadows",                goal = 1,  reward =  8, classOnly = "ROGUE",       hint = "Enter Stealth." },
    { type = "warrior_charge",      label = "Charge into battle",                   goal = 1,  reward =  8, classOnly = "WARRIOR",     hint = "Use Charge or Intercept." },
    { type = "shaman_totem",        label = "Drop a totem",                         goal = 1,  reward =  8, classOnly = "SHAMAN",      hint = "Cast any totem spell." },
    { type = "druid_shapeshift",    label = "Shapeshift into a new form",           goal = 1,  reward = 10, classOnly = "DRUID",       hint = "Shift into Bear, Cat, Travel, Aquatic, or Moonkin form." },
    { type = "dk_ability",          label = "Unleash the Death Knight's power",     goal = 1,  reward =  8, classOnly = "DEATHKNIGHT", hint = "Cast Raise Dead or Death Grip." },

    { type = "use_potion",   label = "Use a potion or elixir",            goal = 1,  reward = 10, hint = "Drink a potion or elixir." },
    { type = "drink_any",    label = "Take a drink",                      goal = 1,  reward =  6, hint = "Consume any food or drink item." },
    { type = "swim_short",   label = "Go for a swim",                     goal = 1,  reward =  8, hint = "Swim underwater for a little while." },
    { type = "swim_long",    label = "Take a long swim",                  goal = 1,  reward = 15, hint = "Swim underwater long enough to need a breath." },
    { type = "create_fire",  label = "Light a campfire",                  goal = 1,  reward =  8, hint = "Use an item that creates a campfire." },
    { type = "zone_activity",label = "Explore a new area",                goal = 3,  reward = 10, hint = "Move between 3 distinct sub-areas of a zone." },
    { type = "work_ticks",   label = "Stay active for a while",           goal = 1,  reward =  8, hint = "Just keep playing -- this completes itself periodically." },

    -----------------------------------------------------------------------
    -- Brand new challenge types.
    -----------------------------------------------------------------------
    { type = "earn_achievement", label = "Earn an achievement",           goal = 1,  reward = 25, hint = "Complete any in-game achievement." },
    { type = "guild_chat",       label = "Say hello in guild chat",       goal = 1,  reward =  8, hint = "Send a message in the /guild channel.", needsGuild = true },
    { type = "use_flight_path",  label = "Take a flight path",            goal = 1,  reward = 10, hint = "Open the flight master's map and fly somewhere." },

    { type = "loot_gold_streak",      label = "Loot gold 15 times",              goal = 15, reward = 25, hint = "Keep looting coin from kills and containers." },
    { type = "quest_turnin_marathon", label = "Turn in 10 quests",               goal = 10, reward = 40, hint = "Keep completing and turning in quests." },
    { type = "dungeon_crawler",       label = "Complete 3 dungeons",             goal = 3,  reward = 60, minLevel = 15, hint = "Clear 3 dungeons via the Dungeon Finder." },
    { type = "gather_herb_master",    label = "Gather 20 herbs",                 goal = 20, reward = 35, needsProf = "herbalism", hint = "Keep picking herbs (requires Herbalism)." },
    { type = "honor_hunter",          label = "Earn Honor from 5 kills",         goal = 5,  reward = 30, minLevel = 10, hint = "Rack up honorable kills in PvP." },
    { type = "emote_socialite",       label = "Perform 10 emotes",               goal = 10, reward = 25, hint = "Use any /emote command 10 times -- variety counts." },
}

CC.STORE_ITEMS = {
    { key = "trailMix",      name = "Trail Mix",       stat = "hunger",      gain = 25, cost =  5, icon = "inv_misc_food_02" },
    { key = "heartyWorm",    name = "Hearty Worm",     stat = "hunger",      gain = 32, cost =  8, icon = "inv_misc_monstertail_03" },
    { key = "crunchyBiscuit",name = "Crunchy Biscuit", stat = "hunger",      gain = 40, cost = 12, icon = "inv_misc_petbiscuit_01" },
    { key = "savoryJerky",   name = "Savory Jerky",    stat = "hunger",      gain = 48, cost = 18, icon = "inv_misc_food_16" },
    { key = "grandFeast",    name = "Grand Feast",     stat = "hunger",      gain = 60, cost = 28, icon = "inv_holiday_thanksgiving_cornucopia" },
    { key = "playToy",       name = "Play Toy",        stat = "joy",         gain = 30, cost =  8, icon = "inv_misc_toy_10" },
    { key = "restPad",       name = "Rest Pad",        stat = "energy",      gain = 30, cost =  8, icon = "Spell_Nature_Sleep" },
    { key = "groomingKit",   name = "Grooming Kit",    stat = "cleanliness", gain = 30, cost =  8, icon = "inv_misc_comb_01" },
}

-- Fallback icon shown for any STORE_ITEMS entry that doesn't define its own
CC.STORE_ICON_DEFAULT = "INV_Misc_QuestionMark"

-------------------------------------------------------------------------------
-- Known-icon overrides for scavenge bonus loot
--
-- GetItemInfo (and therefore an item's icon/name/quality) returns nil
-- until the CLIENT has independently cached that item at least once --
-- per the client API reference: "Only returns information for items in
-- the WoW client's local cache; returns nil for items the client has not
-- seen." The very first time a given player's client ever encounters a
-- particular item ID, GetItemInfo triggers an async server query and
-- returns nil immediately; the data typically arrives well under a
-- second later, and a repeat call then succeeds. This can happen for any
-- item an admin puts in ScavengeLootPoolGreen/*Blue/*Purple (see
-- mod-companion-caddy.conf.dist) -- it depends on whether THIS player
-- happens to have already seen that specific item somewhere else
-- (vendor, loot, mail, etc.), not on the item itself being unusual.
--
-- CC:RefreshScavengeItemPopupInfo (UI.lua) already retries for a few
-- seconds to pick up the real icon once that async query completes --
-- that's the actual general-purpose fix, and needs nothing added here to
-- work for any item at all. This table exists only to make specific
-- items you've configured in your loot pools show their correct icon
-- INSTANTLY, with no momentary placeholder question mark, for whichever
-- ones you'd like zero-latency on -- there's no need (and no practical
-- way) to cover every item in the game here, only the ones actually in
-- your own ScavengeLootPool* lists. Keyed by item entry ID; value is the
-- icon's texture path exactly as GetItemInfo would return it (no file
-- extension).
--
-- Example (Hearthstone, item 6948):
--   CC.ITEM_ICON_OVERRIDES[6948] = "Interface\\Icons\\INV_Misc_Map_01"
-------------------------------------------------------------------------------
CC.ITEM_ICON_OVERRIDES = {
    -- [itemEntry] = "Interface\\Icons\\IconFileName",
}

-------------------------------------------------------------------------------
-- Promo shop icons (client-side only).
--
-- The server's catalog payload is "rewardGroup|displayName|cost|category" --
-- deliberately narrow, because every byte here eats into the ~200-byte addon
-- message budget that this module has already had one crash-inducing bug
-- around (see mod_companion_caddy.cpp). Icons are looked up locally by
-- rewardGroup instead of being sent over the wire, so the wire format and
-- chunking logic don't need to change.
--
-- PROMO_ICON_OVERRIDES gives a specific icon for a rewardGroup. Anything not
-- listed falls back to PROMO_CATEGORY_ICON[category], so every row always
-- gets a sensible, valid icon -- never a blank/missing texture.
--
-- NOTE: a number of these promo items reference real, historically
-- redemption-only WoW Trading Card Game / BlizzCon collectibles. The
-- overrides below are a best-effort match; if you want pixel-perfect
-- official icons for specific items, the fix is a one-line edit to the
-- table below (look up the item on Wowhead and take the icon name from the
-- large icon URL, e.g. ".../icons/large/inv_egg_02.jpg" -> "INV_Egg_02").
-------------------------------------------------------------------------------
CC.PROMO_CATEGORY_ICON = {
    Tabards    = "INV_Shirt_GuildTabard_01",
    Toys       = "INV_Misc_Gift_02",
    Companions = "INV_Box_PetCarrier_01",
    Mounts     = "Ability_Mount_RidingHorse",
    Special    = "INV_Misc_Gift_03",
}

CC.PROMO_ICON_OVERRIDES = {
    -- Tabards
    TCG_TABARD_OF_FROST        = "inv_misc_tabardpvp_01",
    TCG_TABARD_OF_FLAME        = "inv_misc_tabardpvp_02",
    TCG_TABARD_OF_THE_ARCANE   = "inv_shirt_guildtabard_01",
    TCG_TABARD_OF_BRILLIANCE   = "inv_shirt_guildtabard_01",
    TCG_TABARD_OF_THE_DEFENDER = "inv_shirt_guildtabard_01",
    TCG_TABARD_OF_FURY         = "inv_shirt_guildtabard_01",
    TCG_TABARD_OF_NATURE       = "inv_shirt_guildtabard_01",
    TCG_TABARD_OF_THE_VOID     = "inv_shirt_guildtabard_01",
    TCG_EPIC_PURPLE_SHIRT      = "inv_shirt_purple_01",

    -- Toys
    TCG_SANDBOX_TIGER             = "inv_misc_sandbox_spectraltiger_01",
    BLIZZCON_MURLOC_COSTUME       = "inv_misc_head_murloc_01",
    TCG_PERPETUAL_PURPLE_FIREWORK = "inv_misc_missilesmall_purple",
    TCG_CARVED_OGRE_IDOL          = "inv_misc_idol_01",
    TCG_PET_BISCUIT               = "inv_misc_petbiscuit_01",
    TCG_PAINT_BOMB                = "inv_potion_94",
    TCG_BANANA_CHARM              = "inv_misc_food_24",
    TCG_IMP_IN_A_BALL             = "inv_potion_27",
    TCG_PICNIC_BASKET             = "inv_box_01",
    TCG_GOBLIN_GUMBO_KETTLE       = "inv_drink_17",
    TCG_GOBLIN_WEATHER_MACHINE    = "inv_misc_weathermachine_01",
    TCG_DRAGON_KITE               = "inv_misc_dragonkite_02",
    TCG_TUSKARR_KITE              = "inv_misc_pet_01",
    TCG_ETHEREAL_PORTAL           = "ability_mage_netherwindpresence",
    TCG_FOAM_SWORD_RACK           = "ability_warrior_challange",
    TCG_PARTY_GRENADE             = "inv_ammo_bullet_03",
    TCG_PATH_OF_ILLIDAN           = "spell_fire_felfire",
    TCG_PATH_OF_CENARIUS          = "inv_misc_trailofflowers",
    TCG_PAPER_FLYING_MACHINE      = "inv_misc_toy_09",
    TCG_FLAG_OF_OWNERSHIP         = "inv_banner_03",
    TCG_FISHING_CHAIR             = "inv_fishingchair",
    TCG_INSTANT_STATUE_PEDESTAL   = "inv_misc_statue_02",
    TCG_DISCO                     = "inv_misc_discoball_01",

    -- Companions
    PROMO_ORANGE_MURLOC_EGG   = "inv_egg_03",
    PROMO_WHITE_MURLOC_EGG    = "inv_egg_03",
    PROMO_GURKY               = "inv_pet_pinkmurlocegg",
    PROMO_HEAVY_MURLOC_EGG    = "inv_egg_03",
    PROMO_MURKIMUS_SPEAR      = "inv_spear_05",
    BLIZZCON_MURKY            = "inv_egg_03",
    PROMO_ZERGLING_LEASH      = "spell_shadow_summonfelhunter",
    PROMO_PANDA_COLLAR        = "inv_belt_05",
    PROMO_DIABLO_STONE        = "inv_diablostone",
    PROMO_NETHERWHELP         = "inv_netherwhelp",
    PROMO_FROSTYS_COLLAR      = "inv_pet_frostwyrm",
    PROMO_GRYPHON_HATCHLING   = "inv_misc_pet_02",
    PROMO_WIND_RIDER_CUB      = "inv_misc_pet_04",
    PROMO_PANDAREN_MONK       = "inv_misc_pet_03",
    PROMO_ENCHANTED_ONYX      = "inv_misc_qirajicrystal_05",
    PROMO_CORE_HOUND_PUP      = "ability_hunter_pet_corehound",
    PROMO_ONYXIAN_WHELPLING   = "inv_misc_head_dragon_black",
    PROMO_LIL_PHYLACTERY      = "inv_misc_urn_01",
    PROMO_LIL_XT              = "achievement_boss_xt002deconstructor_01",
    PROMO_WARBOT_KEY          = "inv_misc_key_05",
    PROMO_MINI_THOR           = "t_roboticon",
    TCG_HIPPOGRYPH_HATCHLING  = "inv_egg_02",
    TCG_ROCKET_CHICKEN        = "inv_misc_enggizmos_rocketchicken",
    TCG_SPECTRAL_TIGER_CUB    = "ability_mount_spectraltiger",
    TCG_SOUL_TRADER_BEACON    = "spell_nature_groundingtotem",
    TCG_LANDROS_PET_BOX       = "inv_box_petcarrier_01",
    WWI_TYRAELS_HILT          = "inv_sword_07",

    -- Mounts
    TCG_SCOURGEWAR_MINIMOUNT   = "spell_nature_swiftness",
    TCG_RIDING_TURTLE          = "ability_hunter_pet_turtle",
    BLIZZCON_BIG_BLIZZARD_BEAR = "ability_mount_bigblizzardbear",
    TCG_BIG_BATTLE_BEAR        = "ability_druid_challangingroar",
    TCG_MAGIC_ROOSTER_EGG      = "inv_egg_03",
    TCG_WOOLY_WHITE_RHINO      = "ability_hunter_pet_rhino",
    TCG_BLAZING_HIPPOGRYPH     = "ability_mount_warhippogryph",
    TCG_X51_NETHER_ROCKET      = "ability_mount_rocketmount",
    TCG_SPECTRAL_TIGER         = "ability_mount_spectraltiger",

    -- Special
    TCG_LANDROS_GIFT_BOX = "inv_box_03",
}

-- Returns a valid icon path for a promo catalog entry: exact override first,
-- then category fallback, then a generic default so a row is never left
-- without an icon.
function CC:GetPromoIcon(rewardGroup, category)
    local icon = CC.PROMO_ICON_OVERRIDES[rewardGroup]
        or CC.PROMO_CATEGORY_ICON[category]
        or "INV_Misc_QuestionMark"
    return "Interface\\Icons\\" .. icon
end

-- Per-companion model frame sizes (creatureID → {w, h}).
-- Camera 0 fills the frame with the model; larger frame = larger apparent model.
-- Tuned for a 160×200 default panel.
CC.MODEL_SIZES = {
    default = { w = 160, h = 200 },
    [7547]  = { w = 280, h = 340 },  -- Westfall Chicken (tiny geometry)
    [11325] = { w = 240, h = 300 },  -- White Kitten
    [22445] = { w = 220, h = 280 },  -- Snowshoe Rabbit
}

-------------------------------------------------------------------------------
-- Util
-------------------------------------------------------------------------------
local function Clamp(v, mn, mx) return math.max(mn, math.min(mx, v)) end

-- Index (1..#CC.CARE_TIERS) of the tier a single bar VALUE falls into.
local function TierIndexForValue(v)
    for i = #CC.CARE_TIERS, 1, -1 do
        if v >= CC.CARE_TIERS[i].min then return i end
    end
    return 1
end

function CC:GetCareTier(pet)
    if not pet then return CC.CARE_TIERS[1] end
    local h, j, e, c = pet.hunger or 0, pet.joy or 0, pet.energy or 0, pet.cleanliness or 0
    local avg    = (h + j + e + c) / 4
    local lowest = math.min(h, j, e, c)
    local idx    = math.min(TierIndexForValue(avg), TierIndexForValue(lowest))
    return CC.CARE_TIERS[idx]
end

local function Split(s, d)
    if not s or s == "" then return {} end
    local r = {}
    for p in string.gmatch(s .. d, "(.-)" .. d) do r[#r+1] = p end
    return r
end

local function SafeRegister(frame, event)
    local ok, err = pcall(frame.RegisterEvent, frame, event)
    -- silently skip events that don't exist on this client version
end

-------------------------------------------------------------------------------
-- DB helpers
-------------------------------------------------------------------------------
local DB_UI_DEFAULTS = {
    minimapAngle   = 225,
    minimapHidden  = false,
    windowAlpha    = 0.95,
    modelBgAlpha   = 0.75,
    trackerAlpha   = 0.88,
    showTracker    = true,
    trackerX       = nil,
    trackerY       = nil,
    quickBuy       = { "trailMix", "playToy", "restPad" },
    tutorialSeen   = false,
}

function CC:GetUI()
    local db = CompanionCaddyDB
    db.ui = db.ui or {}
    for k, v in pairs(DB_UI_DEFAULTS) do
        if db.ui[k] == nil then db.ui[k] = v end
    end
    return db.ui
end

function CC:GetPlayerKey()
    if not self._playerKey then
        local name  = UnitName("player") or ""
        local realm = GetRealmName and GetRealmName() or ""
        self._playerKey = (realm ~= "") and (name .. "-" .. realm) or name
    end
    return self._playerKey
end

function CC:GetPlayerData()
    local pk = self:GetPlayerKey()
    if not pk or pk == "" then return nil end
    local db = CompanionCaddyDB
    db.players = db.players or {}
    if not db.players[pk] then
        db.players[pk] = { companions = {}, economy = {}, store = {}, scavenges = {} }
    end
    local pd = db.players[pk]
    pd.companions = pd.companions or {}
    if not pd.economy.challenges then
        pd.economy = {
            treats       = 80,
            challenges   = {},
        }
    end

    pd.scavenges = pd.scavenges or {}
    if pd.economy.scavenge then
        if self.activePet then
            local key = tostring(self.activePet.spellID)
            if not pd.scavenges[key] then
                pd.scavenges[key] = pd.economy.scavenge
            end
        end
        pd.economy.scavenge = nil
    end
    pd.store.inventory = pd.store.inventory or {}
    return pd
end

function CC:GetScavenges()
    local pd = self:GetPlayerData()
    return pd and pd.scavenges or nil
end

-- Returns the care-data record for the currently summoned companion (auto-creates).
function CC:GetPet()
    if not self.activePet then return nil end
    local pd = self:GetPlayerData()
    if not pd then return nil end
    local key = tostring(self.activePet.spellID)
    if not pd.companions[key] then
        local pDef = CC.PERSONALITIES[math.random(#CC.PERSONALITIES)]
        pd.companions[key] = {
            name        = self.activePet.name or "Companion",
            personality = pDef.key,
            stage       = "bonding",
            bondProg    = 0,
            hunger      = 85, joy = 75, energy = 90, cleanliness = 80,
            ageMinutes  = 0,
        }
    end
    return pd.companions[key]
end

function CC:GetEconomy()
    local pd = self:GetPlayerData()
    return pd and pd.economy or nil
end

function CC:GetStore()
    local pd = self:GetPlayerData()
    return pd and pd.store or nil
end

function CC:GrantRandomCareItem()
    local store = self:GetStore()
    if not store then return nil end
    store.inventory = store.inventory or {}
    local def = CC.STORE_ITEMS[math.random(#CC.STORE_ITEMS)]
    store.inventory[def.key] = (store.inventory[def.key] or 0) + 1
    self:RefreshUI()
    return def
end

function CC:GetTreatMultiplier(pet)
    return 1 + (pet and pet.streakMult or 0)
end

-------------------------------------------------------------------------------
-- Server state sync
-------------------------------------------------------------------------------
CC.STATE_CHUNK_SIZE    = 180   -- chars per outgoing chunk (headroom under the ~200-byte addon message budget)
CC.STATE_PUSH_DEBOUNCE = 60    -- minimum seconds between automatic full-state pushes

local function SanitizeStateField(v)
    v = tostring(v or "")
    return (v:gsub("[;,:~]", "_"))
end

function CC:ComputeStateChecksum(str)
    local sum = 0
    for i = 1, #str do
        sum = (sum + string.byte(str, i) * i) % 1000000007
    end
    return sum
end

function CC:SerializePlayerData()
    local pd = self:GetPlayerData()
    if not pd then return "" end
    local recs = {}

    recs[#recs+1] = "E," .. tostring(pd.economy and pd.economy.treats or 0)

    local storeParts = {}
    if pd.store and pd.store.inventory then
        for key, qty in pairs(pd.store.inventory) do
            if (qty or 0) > 0 then
                storeParts[#storeParts+1] = SanitizeStateField(key) .. ":" .. tostring(qty)
            end
        end
    end
    recs[#recs+1] = "S," .. table.concat(storeParts, "~")

    local zoneParts = {}
    if pd.economy and pd.economy.visitedZones then
        for zone in pairs(pd.economy.visitedZones) do
            zoneParts[#zoneParts+1] = SanitizeStateField(zone)
        end
    end
    recs[#recs+1] = "Z," .. table.concat(zoneParts, "~")

    for key, pet in pairs(pd.companions or {}) do
        recs[#recs+1] = table.concat({
            "C", key, SanitizeStateField(pet.name), SanitizeStateField(pet.personality),
            SanitizeStateField(pet.stage), pet.bondProg or 0,
            pet.hunger or 0, pet.joy or 0, pet.energy or 0, pet.cleanliness or 0,
            pet.ageMinutes or 0, pet.streakSec or 0, pet.streakSteps or 0,
            pet.streakMult or 0, pet.neglectSince or 0, pet.bondPenaltyMult or 0,
            pet.spontAccum or 0,
        }, ",")
    end

    for key, scav in pairs(pd.scavenges or {}) do
        if scav.active then
            recs[#recs+1] = table.concat({
                "G", key, scav.start or 0, scav.sec or 0, scav.min or 0, scav.max or 0,
                SanitizeStateField(scav.tier), SanitizeStateField(scav.careTierKey or "good"),
                SanitizeStateField(scav.petName or ""), SanitizeStateField(scav.petIcon or ""),
            }, ",")
        end
    end

    return table.concat(recs, ";")
end

function CC:DeserializePlayerData(blob)
    local pd = { companions = {}, economy = { treats = 0, challenges = {}, visitedZones = {} }, store = { inventory = {} }, scavenges = {} }
    if not blob or blob == "" then return pd end

    for _, rec in ipairs(Split(blob, ";")) do
        if rec ~= "" then
            local f = Split(rec, ",")
            local kind = f[1]

            if kind == "E" then
                pd.economy.treats = tonumber(f[2]) or 0

            elseif kind == "S" then
                if f[2] and f[2] ~= "" then
                    for _, pair in ipairs(Split(f[2], "~")) do
                        local kv = Split(pair, ":")
                        if kv[1] and kv[1] ~= "" then
                            pd.store.inventory[kv[1]] = tonumber(kv[2]) or 0
                        end
                    end
                end

            elseif kind == "Z" then
                if f[2] and f[2] ~= "" then
                    for _, zone in ipairs(Split(f[2], "~")) do
                        if zone ~= "" then pd.economy.visitedZones[zone] = true end
                    end
                end

            elseif kind == "C" and f[2] then
                local careDef
                pd.companions[f[2]] = {
                    name            = f[3] or "Companion",
                    personality     = f[4] or "Playful",
                    stage           = f[5] or "bonding",
                    bondProg        = tonumber(f[6]) or 0,
                    hunger          = tonumber(f[7]) or 0,
                    joy             = tonumber(f[8]) or 0,
                    energy          = tonumber(f[9]) or 0,
                    cleanliness     = tonumber(f[10]) or 0,
                    ageMinutes      = tonumber(f[11]) or 0,
                    streakSec       = tonumber(f[12]) or 0,
                    streakSteps     = tonumber(f[13]) or 0,
                    streakMult      = tonumber(f[14]) or 0,
                    neglectSince    = (tonumber(f[15]) or 0) > 0 and tonumber(f[15]) or nil,
                    bondPenaltyMult = (tonumber(f[16]) or 0) > 0 and tonumber(f[16]) or nil,
                    spontAccum      = tonumber(f[17]) or 0,
                }

            elseif kind == "G" and f[2] then
                local careKey = f[8] or "good"
                local careLabel = "Good"
                for _, t in ipairs(CC.CARE_TIERS) do
                    if t.key == careKey then careLabel = t.label; break end
                end
                pd.scavenges[f[2]] = {
                    active        = true,
                    start         = tonumber(f[3]) or 0,
                    sec           = tonumber(f[4]) or 0,
                    min           = tonumber(f[5]) or 0,
                    max           = tonumber(f[6]) or 0,
                    tier          = f[7] or "green",
                    careTierKey   = careKey,
                    careTierLabel = careLabel,
                    petName       = f[9] or "Companion",
                    petIcon       = f[10] or "",
                }
            end
        end
    end
    return pd
end

function CC:PushStateToServer()
    local pd = self:GetPlayerData()
    if not pd then return end

    local blob = self:SerializePlayerData()
    pd.stateRevision = (pd.stateRevision or 0) + 1
    local checksum = self:ComputeStateChecksum(blob)

    self:SendToServer("STATE_PUSH_BEGIN|" .. pd.stateRevision .. "|" .. checksum)
    local i = 1
    while i <= #blob do
        self:SendToServer("STATE_CHUNK:" .. blob:sub(i, i + CC.STATE_CHUNK_SIZE - 1))
        i = i + CC.STATE_CHUNK_SIZE
    end
    self:SendToServer("STATE_PUSH_END")

    self._lastStatePush = time()
end

function CC:RequestStateFromServer()
    local pd = self:GetPlayerData()
    local localRev = (pd and pd.stateRevision) or 0
    self._incomingState = nil
    self._stateSyncStarted = true
    self:SendToServer("STATE_QUERY|" .. localRev)
end

-- Return info table for a PERSONALITIES key
function CC:PetPersonality(pet)
    if not pet then return nil end
    for _, p in ipairs(CC.PERSONALITIES) do
        if p.key == pet.personality then return p end
    end
    return nil
end

-------------------------------------------------------------------------------
-- Active companion detection
-------------------------------------------------------------------------------
function CC:ScanActivePet()
    if not GetNumCompanions then self.activePet = nil; return end
    local n = GetNumCompanions("CRITTER") or 0
    for i = 1, n do
        local cid, name, sid, icon, active = GetCompanionInfo("CRITTER", i)
        if active then
            self.activePet = { index=i, creatureID=cid, name=name, spellID=sid, icon=icon }
            return
        end
    end
    self.activePet = nil
end

-------------------------------------------------------------------------------
-- Activity log
-------------------------------------------------------------------------------
local _log = {}
function CC:Log(text)
    if not text or text == "" then return end
    table.insert(_log, 1, { text = text, t = GetTime() })
    if #_log > 120 then table.remove(_log) end
    if self.UpdateLog then self:UpdateLog() end
end
function CC:GetLog() return _log end

-------------------------------------------------------------------------------
-- Care actions
-------------------------------------------------------------------------------
local _cooldowns = {}   -- [action] = GetTime() of last use

function CC:CooldownLeft(action)
    local cd = CC.ACTION_COOLDOWN
    local pet = self:GetPet()
    local pDef = self:PetPersonality(pet)
    if pDef and pDef.cooldownReduce then cd = cd * 0.85 end
    local last = _cooldowns[action] or 0
    local left = cd - (GetTime() - last)
    return (left > 0) and left or 0, cd
end

local function ApplyBonus(pDef, stat, base)
    if pDef and pDef.stat == stat then
        return math.floor(base * (1 + pDef.bonus))
    end
    return base
end

function CC:DoAction(action)
    local pet = self:GetPet()
    if not pet then return false, "No companion summoned." end

    if self.activePet and self:IsScavenging(tostring(self.activePet.spellID)) then
        return false, (pet.name or "This companion") .. " is out scavenging and can't be interacted with right now."
    end

    local left = self:CooldownLeft(action)
    if left > 0 then
        return false, string.format("%.0fs remaining.", left)
    end

    local pDef   = self:PetPersonality(pet)
    local gained = ""

    local ACTION_LABEL = {
        feed = "Feed", play = "Play", rest = "Rest", clean = "Clean",
        soothe = "Soothe", warm = "Warm",
    }
    local logMsg

    if pet.stage == "bonding" then
        local bondActions = { soothe=true, warm=true, clean=true }
        if not bondActions[action] then
            return false, "Only Soothe, Warm, and Clean work during bonding."
        end

        local g = CC.BOND_PER_ACTION / (pet.bondPenaltyMult or 1)
        pet.bondProg = Clamp(pet.bondProg + g, 0, 100)
        gained = string.format("+%.1f%% bonding", g)
        logMsg = string.format("Used %s  %s.", ACTION_LABEL[action] or action, gained)
        self:AdvanceChallenges(action, 1)
        if pet.bondProg >= 100 then
            pet.stage = "companion"
            pet.bondPenaltyMult = nil
            self:Log("Bonding complete! Your companion is ready.")
            self:Notify("Your companion has fully bonded with you!")
        end
    else
        local map = {
            feed  = "hunger",
            play  = "joy",
            rest  = "energy",
            clean = "cleanliness",
        }
        local stat = map[action]
        if not stat then return false, "Unknown action." end

        local gain = ApplyBonus(pDef, stat, 20)
        pet[stat] = Clamp(pet[stat] + gain, 0, 100)
        if action == "play" then
            pet.energy = Clamp(pet.energy - 8, 0, 100)
        end
        gained = string.format("+%d %s", gain, stat)
        self:AdvanceChallenges(action, 1)

        pet.neglectSince = nil

        local eco = self:GetEconomy()
        local treatsEarned = 0
        if eco then
            treatsEarned = math.floor(CC.TREAT_PER_ACTION * self:GetTreatMultiplier(pet))
            eco.treats = (eco.treats or 0) + treatsEarned
        end
        logMsg = string.format("Used %s  %s", ACTION_LABEL[action] or action, gained)
        if treatsEarned > 0 then
            logMsg = logMsg .. string.format(", +%d treats", treatsEarned)
        end
        logMsg = logMsg .. "."
    end

    _cooldowns[action] = GetTime()
    self:Log(logMsg)
    self:ReportChallengeToServer(action)
    self:RefreshUI()
    return true, gained
end

-- Use a food item from inventory
function CC:UseFood(itemKey)
    local pet = self:GetPet()
    if not pet or pet.stage ~= "companion" then return false, "Companion must be bonded." end
    local store = self:GetStore()
    local inv   = store and store.inventory or {}
    if (inv[itemKey] or 0) < 1 then return false, "None in inventory." end

    local def
    for _, d in ipairs(CC.STORE_ITEMS) do if d.key == itemKey then def = d; break end end
    if not def then return false, "Unknown item." end

    inv[itemKey] = inv[itemKey] - 1
    pet[def.stat] = Clamp(pet[def.stat] + def.gain, 0, 100)
    pet.neglectSince = nil   -- any care action clears the neglect clock -- see CC:CheckNeglect
    self:Log(string.format("Used %s  +%d %s.", def.name, def.gain, def.stat))
    self:RefreshUI()
    return true
end

-- Buy a food item from the store
function CC:BuyItem(itemKey)
    local eco   = self:GetEconomy()
    local store = self:GetStore()
    if not eco or not store then return false, "No companion data." end

    local def
    for _, d in ipairs(CC.STORE_ITEMS) do if d.key == itemKey then def = d; break end end
    if not def then return false, "Unknown item." end

    if (eco.treats or 0) < def.cost then
        return false, string.format("Need %d treats (have %d).", def.cost, eco.treats or 0)
    end

    eco.treats = eco.treats - def.cost
    store.inventory[itemKey] = (store.inventory[itemKey] or 0) + 1
    self:Log(string.format("Purchased %s.", def.name))
    self:RefreshUI()
    return true
end

-------------------------------------------------------------------------------
-- Companion summon lock (server-authoritative scavenging)
-------------------------------------------------------------------------------
local _origCallCompanion = CallCompanion
if type(_origCallCompanion) == "function" then
    CallCompanion = function(ctype, index)
        if ctype == "CRITTER" and index then
            local _, _, sid = GetCompanionInfo("CRITTER", index)
            if sid and CC:IsScavenging(tostring(sid)) then
                if UIErrorsFrame then
                    UIErrorsFrame:AddMessage("That companion is out scavenging!", 1.0, 0.1, 0.1, 1.0)
                end
                return
            end
        end
        return _origCallCompanion(ctype, index)
    end
end

function CC:ForceDismissActivePet()
    if not self.activePet then return end
    DismissCompanion("CRITTER")
end

-------------------------------------------------------------------------------
-- Scavenging
-------------------------------------------------------------------------------
function CC:StartScavenge(optIdx)
    if not self.activePet then
        return false, "No companion summoned."
    end
    local pet = self:GetPet()
    if not pet or pet.stage ~= "companion" then
        return false, "Companion must be bonded first."
    end
    local scavs = self:GetScavenges()
    if not scavs then return false, "No companion data." end
    local spellID = self.activePet.spellID
    local key = tostring(spellID)
    if scavs[key] and scavs[key].active then
        return false, "This companion is already scavenging."
    end
    local opt = CC.SCAVENGE_OPTS[optIdx] or CC.SCAVENGE_OPTS[1]

    local careTier = self:GetCareTier(pet)

    scavs[key] = {
        active = true, start = time(), sec = opt.sec, min = opt.min, max = opt.max,
        label  = opt.label, tier = opt.tier,
        petName = pet.name, petIcon = self.activePet.icon,
        careTierKey = careTier.key, careTierLabel = careTier.label,
    }

    self:SendToServer("SCAVENGE_START|" .. spellID .. "|" .. opt.tier .. "|" .. careTier.key)

    self:ForceDismissActivePet()

    self:Log(string.format("%s went scavenging (%s care) — returns in %s.",
        pet.name or "Your companion", careTier.label, opt.label))
    self:RefreshUI()
    self:RefreshTickFrame()

    local activeCount = 0
    for _, s in pairs(scavs) do
        if s.active then activeCount = activeCount + 1 end
    end
    if activeCount >= 3 then
        self:AdvanceChallenges("scavenge_squad", 1)
        self:ReportChallengeToServer("scavenge_squad")
    end

    return true
end

function CC:CheckScavenge()
    local scavs = self:GetScavenges()
    local pd    = self:GetPlayerData()
    local eco   = self:GetEconomy()
    if not scavs or not pd or not eco then return end

    for key, scav in pairs(scavs) do
        if scav.active then
            local elapsed = time() - scav.start
            if elapsed >= scav.sec then
                local scavPet = pd.companions[key]
                local pDef    = scavPet and self:PetPersonality(scavPet)
                local mult    = ((pDef and pDef.scavengeBonus) and 1.20 or 1.0) * self:GetTreatMultiplier(scavPet)
                local range   = scav.max - scav.min
                local got     = math.floor((scav.min + math.random(0, range)) * mult)
                eco.treats    = (eco.treats or 0) + got

                if scavPet then
                    scavPet.joy    = Clamp(scavPet.joy    + 6, 0, 100)
                    scavPet.energy = Clamp(scavPet.energy - 12, 0, 100)
                end

                self:AdvanceChallenges("scavenge", 1)
                self:ReportChallengeToServer("scavenge")
                self:SendToServer("SCAVENGE_DONE|" .. key)

                self:Log(string.format("%s returned from scavenging! +%d treats.",
                    scav.petName or (scavPet and scavPet.name) or "Your companion", got))
                scavs[key] = nil
            end
        end
    end
    self:RefreshUI()
end

-------------------------------------------------------------------------------
-- Care decay ticker + periodic UI refresh
-------------------------------------------------------------------------------
local _tickFrame = CreateFrame("Frame")
local _tickAccum = 0

local _cooldownAccum = 0
local CD_SWEEP_INTERVAL = 0.1

_tickFrame:SetScript("OnUpdate", function(_, dt)
    _cooldownAccum = _cooldownAccum + dt
    if _cooldownAccum >= CD_SWEEP_INTERVAL then
        _cooldownAccum = _cooldownAccum - CD_SWEEP_INTERVAL
        if CC.UpdateActionCooldowns then CC:UpdateActionCooldowns() end
    end

    _tickAccum = _tickAccum + dt
    if _tickAccum < CC.TICK_INTERVAL then return end
    _tickAccum = _tickAccum - CC.TICK_INTERVAL
    CC:OnTick()
end)
_tickFrame:Hide()

function CC:IsScavenging(key)
    if not key then return false end
    local scavs = self:GetScavenges()
    local s = scavs and scavs[key]
    return s ~= nil and s.active == true
end

function CC:HasAnyActiveScavenge()
    local scavs = self:GetScavenges()
    if not scavs then return false end
    for _, s in pairs(scavs) do
        if s.active then return true end
    end
    return false
end

function CC:RefreshTickFrame()
    if self.activePet or self:HasAnyActiveScavenge() then
        _tickFrame:Show()
    else
        _tickFrame:Hide()
    end
end

function CC:OnTick()
    local pet = self:GetPet()
    if pet and pet.stage == "companion" then
        local key = self.activePet and tostring(self.activePet.spellID)
        if self:IsScavenging(key) then
        else
            pet.ageMinutes  = (pet.ageMinutes or 0) + CC.TICK_INTERVAL / 60
            pet.hunger      = Clamp(pet.hunger      - CC.DECAY.hunger,      0, 100)
            pet.joy         = Clamp(pet.joy         - CC.DECAY.joy,         0, 100)
            pet.energy      = Clamp(pet.energy      - CC.DECAY.energy,      0, 100)
            pet.cleanliness = Clamp(pet.cleanliness - CC.DECAY.cleanliness, 0, 100)

            self:UpdateCareStreak(pet)
            self:CheckNeglect(pet)
            self:CheckSpontaneousEvent(pet)
        end
    end
    self:CheckScavenge()
    if self.UpdateTracker then self:UpdateTracker() end
    if self.RefreshUI then self:RefreshUI() end   -- RefreshUI no-ops if window is hidden
    self:RefreshTickFrame()

    if self._stateSyncStarted and not self._incomingState
        and (time() - (self._lastStatePush or 0)) >= CC.STATE_PUSH_DEBOUNCE then
        self:PushStateToServer()
    end
end

function CC:UpdateCareStreak(pet)
    local tier = self:GetCareTier(pet)
    if tier.key == "thriving" then
        pet.streakSec   = (pet.streakSec or 0) + CC.TICK_INTERVAL
        local steps     = math.floor(pet.streakSec / CC.STREAK_STEP_SECONDS)
        local prevSteps = pet.streakSteps or 0
        if steps > prevSteps then
            pet.streakSteps = steps
            for _ = 1, steps - prevSteps do
                local before = pet.streakMult or 0
                if before < CC.STREAK_MULT_MAX then
                    pet.streakMult = Clamp(before + CC.STREAK_MULT_PER_STEP, 0, CC.STREAK_MULT_MAX)
                    self:Log(string.format("%s's Treat combo grew to +%.0f%%!",
                        pet.name or "Your companion", pet.streakMult * 100))
                end
                if math.random() < CC.STREAK_ITEM_CHANCE then
                    local item = self:GrantRandomCareItem()
                    if item then
                        self:Log(string.format("%s's dedication paid off — you got a free %s!",
                            pet.name or "Your companion", item.name))
                        self:Notify("Your companion's care earned you a free " .. item.name .. "!")
                    end
                end
            end
        end
    elseif (pet.streakSec or 0) > 0 or (pet.streakSteps or 0) > 0 or (pet.streakMult or 0) > 0 then
        pet.streakSec   = 0
        pet.streakSteps = 0
        if (pet.streakMult or 0) > 0 then
            pet.streakMult = Clamp(pet.streakMult - CC.STREAK_MULT_DECAY, 0, CC.STREAK_MULT_MAX)
        end
    end
end

function CC:CheckNeglect(pet)
    local avg = (pet.hunger + pet.joy + pet.energy + pet.cleanliness) / 4

    if avg <= CC.NEGLECT_WARN_AVG then
        if not pet.neglectSince then
            pet.neglectSince = time()
            self:Log(string.format(
                "%s is being badly neglected! If every Need bar hits zero, it'll need to fully re-bond "
                .. "with you -- and the longer this goes on, the longer that takes. A little care now avoids it entirely.",
                pet.name or "Your companion"))
            self:Notify((pet.name or "Your companion") .. " urgently needs attention!")
        end
    else
        pet.neglectSince = nil
    end

    if pet.hunger <= 0 and pet.joy <= 0 and pet.energy <= 0 and pet.cleanliness <= 0 then
        local neglectDuration = pet.neglectSince and (time() - pet.neglectSince) or 0
        local ramp = Clamp(neglectDuration / CC.NEGLECT_RAMP_SECONDS, 0, 1)
        local mult = CC.NEGLECT_MIN_MULT + (CC.NEGLECT_MAX_MULT - CC.NEGLECT_MIN_MULT) * ramp

        pet.stage           = "bonding"
        pet.bondProg        = 0
        pet.bondPenaltyMult = mult
        pet.neglectSince    = nil
        pet.streakSec       = 0
        pet.streakSteps     = 0
        pet.streakMult      = 0

        self:Log(string.format(
            "%s was neglected until every Need bottomed out, and needs to fully re-bond with you — "
            .. "bonding will take %.1fx longer this time.", pet.name or "Your companion", mult))
        self:Notify((pet.name or "Your companion") .. " must re-bond with you after being neglected!")
    end
end

function CC:CheckSpontaneousEvent(pet)
    pet.spontAccum = (pet.spontAccum or 0) + CC.TICK_INTERVAL
    if pet.spontAccum < CC.SPONT_EVENT_CHECK_SECONDS then return end
    pet.spontAccum = 0

    local tier = self:GetCareTier(pet)
    if tier.key ~= "good" and tier.key ~= "thriving" then return end
    if math.random() >= CC.SPONT_EVENT_CHANCE then return end

    local item = self:GrantRandomCareItem()
    if not item then return end
    local flavor = CC.SPONT_EVENT_FLAVOR[math.random(#CC.SPONT_EVENT_FLAVOR)]
    local msg = string.format(flavor, pet.name or "Your companion", item.name)
    self:Log(msg)
    self:Notify(msg)
end

-------------------------------------------------------------------------------
-- Mount / taxi detection poll
-------------------------------------------------------------------------------
local _mountPollFrame = CreateFrame("Frame")
local _mountPollAccum = 0
local _wasMounted = false
local _wasOnTaxi  = false

_mountPollFrame:SetScript("OnUpdate", function(_, dt)
    _mountPollAccum = _mountPollAccum + dt
    if _mountPollAccum < 2 then return end
    _mountPollAccum = 0

    local mounted = (IsMounted and IsMounted()) or false
    local onTaxi  = (UnitOnTaxi and UnitOnTaxi("player")) or false

    if (mounted and not _wasMounted) or (onTaxi and not _wasOnTaxi) then
        CC:AdvanceChallenges("use_mount", 1)
        CC:ReportChallengeToServer("use_mount")
    end
    _wasMounted = mounted
    _wasOnTaxi  = onTaxi
end)

-------------------------------------------------------------------------------
-- Challenge system
-------------------------------------------------------------------------------
local function GetPlayerProfs()
    local profs = {}
    if not GetProfessions then return profs end
    local s1, s2, s3, s4, s5 = GetProfessions()
    for _, slot in ipairs({ s1, s2, s3, s4, s5 }) do
        if slot then
            local _, _, _, _, _, _, skillLine = GetProfessionInfo(slot)
            if skillLine then
                for k, v in pairs(PROF) do
                    if v == skillLine then profs[k] = true end
                end
            end
        end
    end
    return profs
end

-- Returns true if the challenge def is currently achievable by this character.
local function IsChallengeEligible(def, stage, profs)
    if def.bondingOnly    and stage ~= "bonding"   then return false end
    if def.companionOnly  and stage ~= "companion" then return false end
    if def.needsProf      and not profs[def.needsProf] then return false end
    if def.needsGuild      and not IsInGuild() then return false end
    if def.minLevel        and (UnitLevel("player") or 1) < def.minLevel then return false end
    if def.maxLevel        and (UnitLevel("player") or 1) > def.maxLevel then return false end
    if def.classOnly then
        local _, classToken = UnitClass("player")
        if classToken ~= def.classOnly then return false end
    end
    return true
end

-- Build a pool of eligible challenges for current pet stage, professions,
-- character level, and class.
function CC:BuildChallengePool()
    local pet   = self:GetPet()
    local stage = pet and pet.stage or "bonding"
    local profs = GetPlayerProfs()
    local pool  = {}
    for _, def in ipairs(CC.CHALLENGE_DEFS) do
        if IsChallengeEligible(def, stage, profs) then
            pool[#pool + 1] = def
        end
    end
    return pool
end

-- Pick one challenge def not already in active list.
function CC:PickChallenge(active, pool)
    local used = {}
    for _, ch in ipairs(active) do used[ch.type] = true end
    local eligible = {}
    for _, def in ipairs(pool) do
        if not used[def.type] then eligible[#eligible + 1] = def end
    end
    if #eligible == 0 then return nil end
    local def = eligible[math.random(#eligible)]
    return { type=def.type, label=def.label, goal=def.goal, progress=0, reward=def.reward, hint=def.hint }
end

-- Ensure exactly 4 active challenges exist.
function CC:RefreshChallenges()
    local eco  = self:GetEconomy()
    if not eco then return end
    eco.challenges = eco.challenges or {}
    local pool = self:BuildChallengePool()
    while #eco.challenges < 4 do
        local ch = self:PickChallenge(eco.challenges, pool)
        if not ch then break end
        eco.challenges[#eco.challenges + 1] = ch
    end
end

-- Advance all active challenges of the given type by amount.
function CC:AdvanceChallenges(ctype, amount, suppressRefresh)
    if not self.activePet then return end
    local eco = self:GetEconomy()
    if not eco then return end
    eco.challenges = eco.challenges or {}
    local completed = false
    for i = #eco.challenges, 1, -1 do
        local ch = eco.challenges[i]
        if ch.type == ctype then
            ch.progress = ch.progress + (amount or 1)
            if ch.progress >= ch.goal then
                local treatReward = math.floor(CC.TREAT_PER_CHALLENGE * self:GetTreatMultiplier(self:GetPet()))
                eco.treats = (eco.treats or 0) + treatReward
                local promoHint = self.promoTcgReady
                    and "  |cff7ec8e3(reported to Promo server)|r" or ""
                self:Log(string.format(
                    "|cff40ff40Challenge complete:|r %s  |cffffd700(+%d treats)|r%s",
                    ch.label, treatReward, promoHint))
                table.remove(eco.challenges, i)
                completed = true
            end
        end
    end
    if completed then self:RefreshChallenges() end
    if not suppressRefresh and self.UpdateChallengesUI then self:UpdateChallengesUI() end
end

-------------------------------------------------------------------------------
-- Server communication  (Promo Points via addon messages)
-------------------------------------------------------------------------------
CC.promoBalance   = 0
CC.promoDailyLeft = 0
CC.promoTcgReady  = false
CC.promoEnabled   = true   -- false when the server has DailyCap < 0 (promo points off)
CC.promoCatalog   = {}
CC._lastReport    = {}     -- [challengeType] = time() of last send

-- Renders promoDailyLeft for display: disabled/unlimited/a real count.
function CC:FormatDailyLeft()
    if not self.promoEnabled then return "disabled" end
    if (self.promoDailyLeft or 0) < 0 then return "unlimited" end
    return tostring(self.promoDailyLeft or 0)
end

function CC:SendToServer(payload)
    if not SendAddonMessage or not payload then return end
    local name = UnitName("player")
    if not name or name == "" then return end
    pcall(SendAddonMessage, "CCADDY", payload, "WHISPER", name)
end

function CC:ReportChallengeToServer(ctype)
    if not ctype then return end
    if not self.promoEnabled then return end  -- server has promo points off; nothing to report
    local now  = time()
    if (now - (self._lastReport[ctype] or 0)) < 30 then return end
    self._lastReport[ctype] = now
    self:SendToServer("CHALLENGE|" .. ctype)
end

function CC:HandleServerMessage(payload)
    if not payload or payload == "" then return end
    local parts = Split(payload, "|")
    local cmd   = parts[1]

    if cmd == "INIT" then
        self.promoBalance   = tonumber(parts[2]) or 0
        self.promoDailyLeft = tonumber(parts[3]) or 0
        self.promoTcgReady  = (parts[4] == "1")
        if parts[5] then
            self.promoEnabled = (parts[5] == "1")
        end

        self.promoCatalog   = {}
        if self.RefreshPromoUI then self:RefreshPromoUI() end

    elseif cmd == "BALANCE" then
        local prevBal = self.promoBalance or 0
        self.promoBalance   = tonumber(parts[2]) or 0
        self.promoDailyLeft = tonumber(parts[3]) or 0
        if parts[4] then
            self.promoTcgReady = (parts[4] == "1")
        end
        if parts[5] then
            self.promoEnabled = (parts[5] == "1")
        end
        local delta = self.promoBalance - prevBal
        if delta > 0 then
            self:Log(string.format(
                "|cffffd700+%d Promo Points|r  (balance: %d)", delta, self.promoBalance))
        end
        if self.RefreshPromoUI then self:RefreshPromoUI() end

    elseif string.sub(payload, 1, 8) == "CATALOG:" then
        local data = string.sub(payload, 9)
        for _, entry in ipairs(Split(data, ";")) do
            local ep = Split(entry, "|")
            if ep[1] and ep[1] ~= "" then
                self.promoCatalog[#self.promoCatalog + 1] = {
                    rewardGroup   = ep[1],
                    displayName   = ep[2] or ep[1],
                    pointCost     = tonumber(ep[3]) or 0,
                    category      = ep[4] or "Other",
                    itemEntry     = tonumber(ep[5]) or 0,
                    itemEntryAlt  = tonumber(ep[6]) or 0,
                    factionSplit  = ep[7] == "1",
                }
            end
        end

    elseif cmd == "CATALOG_END" then
        if self.RebuildPromoShop then self:RebuildPromoShop() end

    elseif cmd == "CODE_MAILED" then
        local rg = parts[2] or ""
        local dn = rg
        for _, it in ipairs(self.promoCatalog) do
            if it.rewardGroup == rg then dn = it.displayName; break end
        end
        self:Print("|cffffd700Promo code for " .. dn .. " has been mailed to you!|r")
        if self.ShowMailNotice then self:ShowMailNotice(dn) end

    elseif cmd == "SCAVENGE_ITEM" then
        local itemEntry = tonumber(parts[2]) or 0
        local mailed = parts[3] == "1"
        if itemEntry > 0 then
            self:Log(string.format(
                "|cffffd700Your companion scavenged up an item!|r%s",
                mailed and " (mailed -- bags were full)" or ""))
            if self.ShowScavengeItemNotice then self:ShowScavengeItemNotice(itemEntry, mailed) end
        end

    elseif cmd == "STATE_NONE" then
        self:PushStateToServer()

    elseif cmd == "STATE_CURRENT" then

    elseif cmd == "STATE_BEGIN" then
        self._incomingState = {
            revision = tonumber(parts[2]) or 0,
            checksum = tonumber(parts[3]) or 0,
            chunks   = {},
        }

    elseif string.sub(payload, 1, 12) == "STATE_CHUNK:" then
        if self._incomingState then
            local chunks = self._incomingState.chunks
            chunks[#chunks + 1] = string.sub(payload, 13)
        end

    elseif cmd == "STATE_END" then
        local inc = self._incomingState
        self._incomingState = nil
        if inc then
            local blob = table.concat(inc.chunks)
            if self:ComputeStateChecksum(blob) == inc.checksum then
                local incoming = self:DeserializePlayerData(blob)
                local pd = self:GetPlayerData()
                if pd then
                    pd.companions     = incoming.companions
                    pd.economy        = incoming.economy
                    pd.store          = incoming.store
                    pd.scavenges      = incoming.scavenges
                    pd.stateRevision  = inc.revision
                    self:ScanActivePet()
                    self:RefreshTickFrame()
                    self:RefreshChallenges()
                    self:Log("|cff40ff40Synced companion data from the server.|r")
                    if self.RefreshUI then self:RefreshUI() end
                    if self.UpdateTracker then self:UpdateTracker() end
                end
            else
                self:Log("|cffff4444Server data sync failed a corruption check -- keeping local data.|r")
            end
        end

    elseif cmd == "ERR" then
        local msgs = {
            daily_cap           = "Daily point limit reached. Come back tomorrow!",
            insufficient_points = "Not enough Promo Points.",
            tcg_unavailable     = "Promo shop not available on this server.",
            unknown_item        = "Item not found in catalog.",
            code_gen_failed     = "Code generation failed — points refunded.",
        }
        local text = msgs[parts[2]] or "Shop error: " .. tostring(parts[2])
        if parts[2] == "daily_cap" then
            -- A correctly synced client won't even report challenges once
            -- promoEnabled is false (see ReportChallengeToServer), so this
            -- shouldn't fire in that state -- but guard against a stale
            -- flag anyway rather than spamming the log for a feature the
            -- addon believes is off.
            if self.promoEnabled then
                self:Log("|cffff4444" .. text .. "|r")
            end
        else
            self:Print("|cffff4444" .. text .. "|r")
        end
    end
end

-------------------------------------------------------------------------------
-- Print
-------------------------------------------------------------------------------
function CC:Print(msg)
    DEFAULT_CHAT_FRAME:AddMessage("|cff7ec8e3Companion Caddy:|r " .. tostring(msg or ""))
end

function CC:Notify(msg)
    self:Print(msg)
end

-------------------------------------------------------------------------------
-- Minimap button
-------------------------------------------------------------------------------
local _mmBtn

local function UpdateMMPos()
    local ui  = CC:GetUI()
    local rad = math.rad(ui.minimapAngle or 225)
    _mmBtn:ClearAllPoints()
    _mmBtn:SetPoint("CENTER", Minimap, "CENTER", 80 * math.cos(rad), 80 * math.sin(rad))
end

local function CreateMinimapButton()
    _mmBtn = CreateFrame("Button", "CompanionCaddyMinimap", Minimap)
    _mmBtn:SetSize(31, 31)
    _mmBtn:SetFrameStrata("MEDIUM")
    _mmBtn:SetFrameLevel(8)
    _mmBtn:SetClampedToScreen(false)

    local border = _mmBtn:CreateTexture(nil, "OVERLAY")
    border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
    border:SetSize(53, 53)
    border:SetPoint("TOPLEFT")

    local icon = _mmBtn:CreateTexture(nil, "ARTWORK")
    icon:SetTexture("Interface\\Icons\\INV_Box_PetCarrier_01")
    icon:SetSize(20, 20)
    icon:SetPoint("CENTER")

    _mmBtn:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")
    _mmBtn:EnableMouse(true)
    _mmBtn:SetMovable(false)
    _mmBtn:RegisterForClicks("AnyUp")
    _mmBtn:RegisterForDrag("LeftButton")

    local _dragging = false
    _mmBtn:SetScript("OnDragStart", function(self) _dragging = true end)
    _mmBtn:SetScript("OnDragStop",  function(self) _dragging = false end)
    _mmBtn:SetScript("OnUpdate", function(self)
        if not _dragging then return end
        local mx, my = Minimap:GetCenter()
        local cx, cy = GetCursorPosition()
        local s = UIParent:GetEffectiveScale()
        CC:GetUI().minimapAngle = math.deg(math.atan2((cy / s) - my, (cx / s) - mx))
        UpdateMMPos()
    end)

    _mmBtn:SetScript("OnClick", function(self, btn)
        if btn == "RightButton" then CC:OpenConfig()
        else CC:ToggleMainWindow() end
    end)

    _mmBtn:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:SetText("Companion Caddy", 0.49, 0.78, 0.89)
        local pet = CC.activePet
        if pet then
            GameTooltip:AddLine(pet.name, 1.0, 0.82, 0.1)
            local pd = CC:GetPet()
            if pd then
                if pd.stage == "bonding" then
                    GameTooltip:AddDoubleLine("Bonding", string.format("%.0f%%", pd.bondProg), 1,1,1, 0.4,0.8,1)
                else
                    GameTooltip:AddDoubleLine("Hunger",      string.format("%.0f%%", pd.hunger),      1,1,1, 0.9,0.5,0.2)
                    GameTooltip:AddDoubleLine("Joy",         string.format("%.0f%%", pd.joy),         1,1,1, 0.4,0.9,0.4)
                    GameTooltip:AddDoubleLine("Energy",      string.format("%.0f%%", pd.energy),      1,1,1, 0.5,0.7,1.0)
                    GameTooltip:AddDoubleLine("Cleanliness", string.format("%.0f%%", pd.cleanliness), 1,1,1, 0.8,0.5,1.0)
                end
            end
        else
            GameTooltip:AddLine("No companion summoned.", 0.6, 0.6, 0.6)
        end
        GameTooltip:AddLine("Left: Toggle  |  Right: Config", 0.45, 0.45, 0.45)
        GameTooltip:Show()
    end)
    _mmBtn:SetScript("OnLeave", function() GameTooltip:Hide() end)

    UpdateMMPos()
    if CC:GetUI().minimapHidden then _mmBtn:Hide() end
end

CC.MinimapBtn = function() return _mmBtn end

-------------------------------------------------------------------------------
-- Slash commands  (registered at file scope — book p.379)
-------------------------------------------------------------------------------
SLASH_COMPANIONCADDY1 = "/companioncaddy"
SLASH_COMPANIONCADDY2 = "/caddy"
SLASH_COMPANIONCADDY3 = "/cc"
SlashCmdList["COMPANIONCADDY"] = function(msg)
    msg = string.lower(string.gsub(msg or "", "^%s*(.-)%s*$", "%1"))
    if msg == "" or msg == "open" or msg == "show" then
        CC:ShowMainWindow()
    elseif msg == "hide" or msg == "close" then
        CC:HideMainWindow()
    elseif msg == "toggle" then
        CC:ToggleMainWindow()
    elseif msg == "config" or msg == "options" then
        CC:OpenConfig()
    elseif msg == "minimap" then
        local ui = CC:GetUI()
        ui.minimapHidden = not ui.minimapHidden
        local btn = CC.MinimapBtn()
        if btn then
            if ui.minimapHidden then btn:Hide() else btn:Show() end
        end
    elseif msg == "tutorial" then
        CC:ShowTutorial()
    elseif msg == "debug" then
        CC:Print("v" .. CC.VERSION)
        if CC.activePet then
            CC:Print(string.format("Active: %s  creatureID=%s  spellID=%s",
                CC.activePet.name, CC.activePet.creatureID, CC.activePet.spellID))
            local pd = CC:GetPet()
            if pd then
                CC:Print(string.format("Stage: %s  Bond/Age: %.0f/%.0f",
                    pd.stage, pd.bondProg or 0, pd.ageMinutes or 0))
                CC:Print(string.format("H:%.0f J:%.0f E:%.0f C:%.0f",
                    pd.hunger, pd.joy, pd.energy, pd.cleanliness))
            end
        else
            CC:Print("No active companion.")
        end
        CC:Print(string.format("Promo points: %d  (daily left: %s)",
            CC.promoBalance, CC:FormatDailyLeft()))
    else
        CC:Print("Commands:  open  hide  toggle  config  minimap  debug")
    end
end

-------------------------------------------------------------------------------
-- Event handling
-------------------------------------------------------------------------------
local _ev = CreateFrame("Frame")
_ev:RegisterEvent("ADDON_LOADED")
_ev:RegisterEvent("PLAYER_LOGIN")
_ev:RegisterEvent("PLAYER_LOGOUT")
_ev:RegisterEvent("COMPANION_UPDATE")
_ev:RegisterEvent("CHAT_MSG_ADDON")

-- World-activity events for challenge advancement
local _inCombat = false
local _fishCastAt = 0
local _tradeSkillLine = nil   -- captured at TRADE_SKILL_SHOW, consumed at TRADE_SKILL_CLOSE
local _wasGrouped = false     -- for group_up: detects a 0 → >0 party-size transition
local _wasDead = false        -- for return_from_death: detects a death → alive transition
local _breathStartedAt = nil  -- for swim_short/swim_long: MIRROR_TIMER_START("BREATH") timestamp
local _drankThisBuff = false  -- for drink_any: rising-edge debounce on the "Drink" buff

function CC:MarkZoneVisited(zone)
    if not zone or zone == "" then return false end
    local eco = self:GetEconomy()
    if not eco then return false end
    eco.visitedZones = eco.visitedZones or {}
    if eco.visitedZones[zone] then return false end
    eco.visitedZones[zone] = true
    return true
end

-- Emote keyword → challenge type map
local EMOTE_MAP = {
    dance   = "emote_dance",
    salute  = "emote_salute",
    wave    = "emote_wave",
    laugh   = "emote_laugh",
    cheer   = "emote_cheer",
    bow     = "emote_bow",
    thank   = "emote_thank",
    cry     = "emote_cry",
    roar    = "emote_roar",
    yawn    = "emote_yawn",
    applaud = "emote_clap",
}

local HERB_NAMES = {
    "peacebloom","silverleaf","briarthorn","mageroyal","stranglekelp","bruiseweed",
    "wild steelbloom","kingsblood","liferoot","fadeleaf","goldthorn","sungrass",
    "blindweed","plaguebloom","dreamfoil","icecap","mountain silversage",
    "felweed","terocone","dreaming glory","ragveil","netherbloom","mana thistle",
    "adder's tongue","tiger lily","talandra's rose","lichbloom","icethorn",
    "goldclover","frost lotus",
}
local ORE_NAMES = {
    "copper ore","tin ore","silver ore","iron ore","gold ore","mithril ore",
    "truesilver ore","dark iron ore","thorium ore","fel iron ore","adamantite ore",
    "khorium ore","cobalt ore","saronite ore","titanium ore",
}
local SKIN_NAMES = {
    "light leather","medium leather","heavy leather","thick leather","rugged leather",
    "knothide leather","borean leather","arctic fur","ruined leather scraps",
}

local MAJOR_CITIES = {
    ["Stormwind City"]=true, ["Ironforge"]=true, ["Darnassus"]=true,
    ["Exodar"]=true, ["Dalaran"]=true, ["Shattrath City"]=true,
    ["Orgrimmar"]=true, ["Thunder Bluff"]=true, ["Undercity"]=true, ["Silvermoon City"]=true,
}

local function HasKeyword(str, words)
    local lower = string.lower(str)
    for _, w in ipairs(words) do
        if string.find(lower, w, 1, true) then return true end
    end
    return false
end

_ev:SetScript("OnEvent", function(_, event, ...)
    local a1, a2, a3, a4 = ...

    if event == "ADDON_LOADED" and a1 == "CompanionCaddy" then
        CC:OnLoad()

    elseif event == "PLAYER_LOGIN" then
        CC:OnLogin()

    elseif event == "PLAYER_LOGOUT" then
        if CC._stateSyncStarted then
            CC:PushStateToServer()
        end

    elseif event == "COMPANION_UPDATE" then
        if a1 == "CRITTER" or not a1 then
            local prevSID = CC.activePet and CC.activePet.spellID
            CC:ScanActivePet()
            local currSID = CC.activePet and CC.activePet.spellID
            if prevSID ~= currSID then
                CC:OnCompanionChanged(prevSID, currSID)
                if currSID then CC:AdvanceChallenges("summon_companion", 1) end
            end
        end

    elseif event == "CHAT_MSG_ADDON" then
        if a1 == "CCADDY" then CC:HandleServerMessage(a2) end

    elseif event == "QUEST_TURNED_IN" then
        CC:AdvanceChallenges("quest_turnin", 1)
        CC:ReportChallengeToServer("quest_turnin")
        CC:AdvanceChallenges("quest_turnin_marathon", 1)

    elseif event == "ENCOUNTER_END" then
        CC:AdvanceChallenges("dungeon_complete", 1)
        CC:ReportChallengeToServer("dungeon_complete")
        CC:AdvanceChallenges("dungeon_crawler", 1)

    elseif event == "LFG_COMPLETION_REWARD" then
        CC:AdvanceChallenges("dungeon_complete", 1)
        CC:ReportChallengeToServer("dungeon_complete")
        CC:AdvanceChallenges("dungeon_crawler", 1)

    elseif event == "PLAYER_LEVEL_UP" then
        CC:AdvanceChallenges("level_up", 1)
        CC:ReportChallengeToServer("level_up")

    elseif event == "PLAYER_REGEN_DISABLED" then
        _inCombat = true

    elseif event == "PLAYER_REGEN_ENABLED" then
        if _inCombat then
            _inCombat = false
            CC:AdvanceChallenges("leave_combat", 1)
            CC:ReportChallengeToServer("leave_combat")
        end

    elseif event == "PLAYER_UPDATE_RESTING" then
        if IsResting and IsResting() then
            CC:AdvanceChallenges("visit_inn", 1)
            CC:ReportChallengeToServer("visit_inn")
        end

    elseif event == "ZONE_CHANGED_NEW_AREA" then
        local zone = GetRealZoneText and GetRealZoneText() or ""
        if MAJOR_CITIES[zone] then
            CC:AdvanceChallenges("visit_major_city", 1)
            CC:ReportChallengeToServer("visit_major_city")
        end
        if CC:MarkZoneVisited(zone) then
            CC:AdvanceChallenges("explore_zone", 1)
            CC:ReportChallengeToServer("explore_zone")
        end

    elseif event == "BANKFRAME_OPENED" then
        CC:AdvanceChallenges("visit_bank", 1)
        CC:ReportChallengeToServer("visit_bank")

    elseif event == "MERCHANT_SHOW" then
        CC:AdvanceChallenges("visit_vendor", 1)
        CC:ReportChallengeToServer("visit_vendor")

    elseif event == "TRAINER_SHOW" then
        CC:AdvanceChallenges("visit_trainer", 1)
        CC:ReportChallengeToServer("visit_trainer")

    elseif event == "MAIL_INBOX_UPDATE" then
        CC:AdvanceChallenges("check_mail", 1)
        CC:ReportChallengeToServer("check_mail")

    elseif event == "CHAT_MSG_TEXT_EMOTE" then
        if a2 == (UnitName("player") or "") then
            local lower = string.lower(a1 or "")
            for word, ctype in pairs(EMOTE_MAP) do
                if string.find(lower, word, 1, true) then
                    CC:AdvanceChallenges(ctype, 1)
                    CC:ReportChallengeToServer(ctype)
                    CC:AdvanceChallenges("emote_socialite", 1)
                    CC:ReportChallengeToServer("emote")
                    break
                end
            end
        end

    elseif event == "CHAT_MSG_LOOT" then
        local msg = string.lower(a1 or "")
        -- fishing: check if recent cast flag set
        if string.find(msg, "fish", 1, true) and (GetTime() - _fishCastAt) < 30 then
            CC:AdvanceChallenges("fish_zone", 1)
            CC:ReportChallengeToServer("fish_zone")
        end
        if HasKeyword(msg, HERB_NAMES) then
            CC:AdvanceChallenges("gather_herb", 1)
            CC:ReportChallengeToServer("gather_herb")
            CC:AdvanceChallenges("gather_herb_master", 1)
        end
        if HasKeyword(msg, ORE_NAMES) then
            CC:AdvanceChallenges("gather_ore", 1)
            CC:ReportChallengeToServer("gather_ore")
        end
        if HasKeyword(msg, SKIN_NAMES) then
            CC:AdvanceChallenges("gather_skin", 1)
            CC:ReportChallengeToServer("gather_skin")
        end
        if string.find(msg, "cff0070dd", 1, true) or string.find(msg, "cffa335ee", 1, true) then
            CC:AdvanceChallenges("loot_rare_item", 1)
            CC:ReportChallengeToServer("loot_rare_item")
        end

    elseif event == "UNIT_SPELLCAST_SUCCEEDED" then
        if a1 ~= "player" then return end
        local spell = string.lower(a2 or "")
        if string.find(spell, "fishing", 1, true) or string.find(spell, "cast line", 1, true) then
            _fishCastAt = GetTime()
        end
        if string.find(spell, "hearthstone", 1, true) then
            CC:AdvanceChallenges("use_hearthstone", 1)
            CC:ReportChallengeToServer("use_hearthstone")
        end
        if string.find(spell, "bandage", 1, true) or string.find(spell, "field dressing", 1, true) then
            CC:AdvanceChallenges("use_bandage", 1)
            CC:ReportChallengeToServer("use_bandage")
        end
        if string.find(spell, "potion", 1, true) or string.find(spell, "elixir", 1, true) then
            CC:AdvanceChallenges("use_potion", 1)
            CC:ReportChallengeToServer("use_potion")
        end
        if string.find(spell, "campfire", 1, true) then
            CC:AdvanceChallenges("create_fire", 1)
            CC:ReportChallengeToServer("create_fire")
        end
        local _, classToken = UnitClass("player")
        if classToken == "MAGE" and string.find(spell, "conjure", 1, true) then
            CC:AdvanceChallenges("mage_conjure", 1)
            CC:ReportChallengeToServer("mage_conjure")
        elseif classToken == "WARLOCK" and string.find(spell, "summon", 1, true) then
            CC:AdvanceChallenges("warlock_summon_pet", 1)
            CC:ReportChallengeToServer("warlock_summon_pet")
        elseif classToken == "PALADIN" and string.find(spell, "blessing of", 1, true) then
            CC:AdvanceChallenges("paladin_blessing", 1)
            CC:ReportChallengeToServer("paladin_blessing")
        elseif classToken == "PRIEST" and string.find(spell, "heal", 1, true) then
            CC:AdvanceChallenges("priest_heal", 1)
            CC:ReportChallengeToServer("priest_heal")
        elseif classToken == "HUNTER" and string.find(spell, "feign death", 1, true) then
            CC:AdvanceChallenges("hunter_feign_death", 1)
            CC:ReportChallengeToServer("hunter_feign_death")
        elseif classToken == "ROGUE" and string.find(spell, "stealth", 1, true) then
            CC:AdvanceChallenges("rogue_stealth", 1)
            CC:ReportChallengeToServer("rogue_stealth")
        elseif classToken == "WARRIOR" and (string.find(spell, "charge", 1, true) or string.find(spell, "intercept", 1, true)) then
            CC:AdvanceChallenges("warrior_charge", 1)
            CC:ReportChallengeToServer("warrior_charge")
        elseif classToken == "SHAMAN" and string.find(spell, "totem", 1, true) then
            CC:AdvanceChallenges("shaman_totem", 1)
            CC:ReportChallengeToServer("shaman_totem")
        elseif classToken == "DEATHKNIGHT" and (string.find(spell, "raise dead", 1, true) or string.find(spell, "death grip", 1, true)) then
            CC:AdvanceChallenges("dk_ability", 1)
            CC:ReportChallengeToServer("dk_ability")
        end

    elseif event == "UPDATE_SHAPESHIFT_FORM" then
        local _, classToken = UnitClass("player")
        if classToken == "DRUID" and GetShapeshiftForm and GetShapeshiftForm() ~= 0 then
            CC:AdvanceChallenges("druid_shapeshift", 1)
            CC:ReportChallengeToServer("druid_shapeshift")
        end

    elseif event == "CHAT_MSG_MONEY" then
        CC:AdvanceChallenges("loot_gold", 1)
        CC:ReportChallengeToServer("loot_gold")
        CC:AdvanceChallenges("loot_gold_streak", 1)

    elseif event == "CHAT_MSG_COMBAT_FACTION_CHANGE" then
        if string.find(string.lower(a1 or ""), "increased", 1, true) then
            CC:AdvanceChallenges("gain_reputation", 1)
            CC:ReportChallengeToServer("gain_reputation")
        end

    elseif event == "CHAT_MSG_COMBAT_HONOR_GAIN" then
        CC:AdvanceChallenges("honorable_kill", 1)
        CC:ReportChallengeToServer("honorable_kill")
        CC:AdvanceChallenges("honor_hunter", 1)

    elseif event == "ACHIEVEMENT_EARNED" then
        CC:AdvanceChallenges("earn_achievement", 1)
        CC:ReportChallengeToServer("earn_achievement")

    elseif event == "CHAT_MSG_GUILD" then
        if a2 == (UnitName("player") or "") then
            CC:AdvanceChallenges("guild_chat", 1)
            CC:ReportChallengeToServer("guild_chat")
        end

    elseif event == "TAXIMAP_OPENED" then
        CC:AdvanceChallenges("use_flight_path", 1)
        CC:ReportChallengeToServer("use_flight_path")

    elseif event == "ZONE_CHANGED" then
        CC:AdvanceChallenges("zone_activity", 1)
        CC:ReportChallengeToServer("zone_activity")

    elseif event == "MIRROR_TIMER_START" then
        if a1 == "BREATH" then _breathStartedAt = GetTime() end

    elseif event == "MIRROR_TIMER_STOP" then
        if a1 == "BREATH" and _breathStartedAt then
            local dur = GetTime() - _breathStartedAt
            _breathStartedAt = nil
            if dur >= 20 then
                CC:AdvanceChallenges("swim_long", 1)
                CC:ReportChallengeToServer("swim_long")
            elseif dur >= 3 then
                CC:AdvanceChallenges("swim_short", 1)
                CC:ReportChallengeToServer("swim_short")
            end
        end

    elseif event == "UNIT_AURA" then
        if a1 == "player" then
            local hasDrink = false
            for i = 1, 40 do
                local name = UnitBuff("player", i)
                if not name then break end
                if name == "Drink" then hasDrink = true; break end
            end

            if hasDrink and not _drankThisBuff then
                _drankThisBuff = true
                CC:AdvanceChallenges("drink_any", 1)
                CC:ReportChallengeToServer("drink_any")
            elseif not hasDrink then
                _drankThisBuff = false
            end
        end

    elseif event == "TRADE_SHOW" then
        CC:AdvanceChallenges("trade_player", 1)
        CC:ReportChallengeToServer("trade_player")

    elseif event == "AUCTION_HOUSE_SHOW" then
        CC:AdvanceChallenges("visit_auction_house", 1)
        CC:ReportChallengeToServer("visit_auction_house")

    elseif event == "GROUP_ROSTER_UPDATE" then
        local grouped = ((GetNumPartyMembers and GetNumPartyMembers() > 0)
            or (GetNumRaidMembers and GetNumRaidMembers() > 0)) or false
        if grouped and not _wasGrouped then
            CC:AdvanceChallenges("group_up", 1)
            CC:ReportChallengeToServer("group_up")
        end
        _wasGrouped = grouped

    elseif event == "COMPANION_LEARNED" then
        CC:AdvanceChallenges("learn_companion", 1)
        CC:ReportChallengeToServer("learn_companion")

    elseif event == "DUEL_REQUESTED" then

        CC:AdvanceChallenges("duel_request", 1)
        CC:ReportChallengeToServer("duel_request")

    elseif event == "PLAYER_DEAD" then
        _wasDead = true

    elseif event == "PLAYER_ALIVE" then
        if _wasDead then
            _wasDead = false
            CC:AdvanceChallenges("return_from_death", 1)
            CC:ReportChallengeToServer("return_from_death")
        end

    elseif event == "CHAT_MSG_SYSTEM" then
        local name = UnitName("player") or ""
        if name ~= "" and string.find(a1 or "", name .. " rolls ", 1, true) then
            CC:AdvanceChallenges("roll_dice", 1)
            CC:ReportChallengeToServer("roll_dice")
        end

    elseif event == "TRADE_SKILL_SHOW" then
        _tradeSkillLine = (GetTradeSkillLine and GetTradeSkillLine()) or nil

    elseif event == "TRADE_SKILL_CLOSE" then
        CC:AdvanceChallenges("craft_anything", 1)
        CC:ReportChallengeToServer("craft_anything")
        if _tradeSkillLine == "Cooking" then
            CC:AdvanceChallenges("cook_food", 1)
            CC:ReportChallengeToServer("cook_food")
        end
        _tradeSkillLine = nil
    end
end)

-- Register world-interaction events (some may not exist in all 3.3.5a builds)
SafeRegister(_ev, "QUEST_TURNED_IN")
SafeRegister(_ev, "ENCOUNTER_END")
SafeRegister(_ev, "LFG_COMPLETION_REWARD")
SafeRegister(_ev, "PLAYER_LEVEL_UP")
SafeRegister(_ev, "PLAYER_REGEN_DISABLED")
SafeRegister(_ev, "PLAYER_REGEN_ENABLED")
SafeRegister(_ev, "PLAYER_UPDATE_RESTING")
SafeRegister(_ev, "ZONE_CHANGED_NEW_AREA")
SafeRegister(_ev, "BANKFRAME_OPENED")
SafeRegister(_ev, "MERCHANT_SHOW")
SafeRegister(_ev, "TRAINER_SHOW")
SafeRegister(_ev, "MAIL_INBOX_UPDATE")
SafeRegister(_ev, "TRADE_SKILL_SHOW")
SafeRegister(_ev, "TRADE_SKILL_CLOSE")
SafeRegister(_ev, "CHAT_MSG_TEXT_EMOTE")
SafeRegister(_ev, "CHAT_MSG_LOOT")
SafeRegister(_ev, "UNIT_SPELLCAST_SUCCEEDED")

-- Added for the new challenges above.
SafeRegister(_ev, "UPDATE_SHAPESHIFT_FORM")
SafeRegister(_ev, "CHAT_MSG_MONEY")
SafeRegister(_ev, "CHAT_MSG_COMBAT_FACTION_CHANGE")
SafeRegister(_ev, "CHAT_MSG_COMBAT_HONOR_GAIN")
SafeRegister(_ev, "TRADE_SHOW")
SafeRegister(_ev, "AUCTION_HOUSE_SHOW")
SafeRegister(_ev, "GROUP_ROSTER_UPDATE")
SafeRegister(_ev, "COMPANION_LEARNED")
SafeRegister(_ev, "DUEL_REQUESTED")
SafeRegister(_ev, "PLAYER_DEAD")
SafeRegister(_ev, "PLAYER_ALIVE")
SafeRegister(_ev, "CHAT_MSG_SYSTEM")
SafeRegister(_ev, "ACHIEVEMENT_EARNED")
SafeRegister(_ev, "CHAT_MSG_GUILD")
SafeRegister(_ev, "TAXIMAP_OPENED")
SafeRegister(_ev, "ZONE_CHANGED")
SafeRegister(_ev, "MIRROR_TIMER_START")
SafeRegister(_ev, "MIRROR_TIMER_STOP")
SafeRegister(_ev, "UNIT_AURA")

-------------------------------------------------------------------------------
-- Lifecycle
-------------------------------------------------------------------------------
function CC:OnLoad()
    if type(CompanionCaddyDB) ~= "table" then
        CompanionCaddyDB = { players = {}, ui = {} }
    end
    self:GetUI()
    if RegisterAddonMessagePrefix then
        RegisterAddonMessagePrefix("CCADDY")
    end
    -- pcall wrapping: any crash in BuildUI/BuildConfig prints to chat for diagnosis
    -- instead of silently breaking everything downstream.
    local ok1, err1 = pcall(function() self:BuildUI() end)
    if not ok1 then
        DEFAULT_CHAT_FRAME:AddMessage("|cffff4444CC BuildUI error:|r " .. tostring(err1))
    end
    local ok2, err2 = pcall(function() self:BuildConfig() end)
    if not ok2 then
        DEFAULT_CHAT_FRAME:AddMessage("|cffff4444CC BuildConfig error:|r " .. tostring(err2))
    end
end

function CC:OnLogin()
    self._playerKey = nil   -- rebuild now that UnitName is available
    self:ScanActivePet()
    self:RefreshTickFrame()
    self:RefreshChallenges()
    CreateMinimapButton()
    self:RefreshUI()

    if not self:GetUI().tutorialSeen then
        C_Timer.After(1.5, function() CC:ShowTutorial() end)
    end

    self:StartWorkTicksTimer()
end

function CC:StartWorkTicksTimer()
    C_Timer.After(900, function()
        CC:AdvanceChallenges("work_ticks", 1)
        CC:ReportChallengeToServer("work_ticks")
        CC:StartWorkTicksTimer()
    end)
end

function CC:OnCompanionChanged(prevSID, currSID)
    if currSID and self:IsScavenging(tostring(currSID)) then
        DismissCompanion("CRITTER")
        if UIErrorsFrame then
            UIErrorsFrame:AddMessage("That companion is out scavenging!", 1.0, 0.1, 0.1, 1.0)
        end
        self:ScanActivePet()
        currSID = self.activePet and self.activePet.spellID
    end

    if currSID then
        self:Log("Summoned: " .. (self.activePet.name or "companion"))
    else
        self:Log("Companion dismissed.")
    end

    self:RefreshTickFrame()
    if self.ClearModel then self:ClearModel() end
    self:RefreshChallenges()
    self:RefreshUI()
end