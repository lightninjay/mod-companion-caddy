-------------------------------------------------------------------------------
-- Companion Caddy  —  UI.lua
-- Main window, all tabs, tracker, config panel, model management.
-- All 3.3.5a API calls follow the Wiley WoW Programming Guide.
-------------------------------------------------------------------------------

-------------------------------------------------------------------------------
-- Palette & sizing constants
-------------------------------------------------------------------------------
local Clamp = function(v, mn, mx) return math.max(mn, math.min(mx, v)) end

local WIN_W, WIN_H   = 720, 620
local LEFT_W         = 210   -- model column width
local RIGHT_W        = WIN_W - LEFT_W - 18
local SCAV_ROW_H     = 12    -- height of one row in the scrollable scavenge stack (see CC:UpdateScavengeStack)
local POPUP_ROW_H    = 34    -- height of one row in the scavenge-loot popup's scrollable list (see CC:RefreshScavengePopupList)
local HEADER_PAD     = 20    -- clearance below the title/close button so panel
                              -- content (tab bar, model frame, etc.) doesn't
                              -- crowd the window chrome above it

-- Care stat colours  {r, g, b}
local COL = {
    hunger      = { 0.95, 0.55, 0.20 },
    joy         = { 0.35, 0.90, 0.40 },
    energy      = { 0.45, 0.70, 1.00 },
    cleanliness = { 0.80, 0.50, 1.00 },
    bonding     = { 0.40, 0.80, 1.00 },
}

-- Tab definitions (order = display order)
local TABS = { "Habitat", "Store", "Info", "Customization", "Promo" }

-------------------------------------------------------------------------------
-- Low-level helpers
-------------------------------------------------------------------------------

local function ApplyBackdrop(f, r, g, b, a, br, bg, bb, ba)
    f:SetBackdrop({
        bgFile   = "Interface\\BUTTONS\\WHITE8X8",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        tile = true, tileSize = 16, edgeSize = 10,
        insets = { left=3, right=3, top=3, bottom=3 },
    })
    f:SetBackdropColor(r or 0.04, g or 0.06, b or 0.10, a or 0.95)
    f:SetBackdropBorderColor(br or 0.22, bg or 0.28, bb or 0.40, ba or 0.80)
end

local function ApplyBackdropAlpha(f, alpha)
    local r, g, b = 0.04, 0.06, 0.10
    f:SetBackdropColor(r, g, b, alpha)
    local br, bg, bb = 0.22, 0.28, 0.40
    f:SetBackdropBorderColor(br, bg, bb, alpha)
end

local function SetShown(widget, shown)
    if not widget then return end
    if shown then widget:Show() else widget:Hide() end
end

local function MakeCareBar(parent, label, col)
    local bg = CreateFrame("Frame", nil, parent)
    bg:SetBackdrop({ bgFile="Interface\\BUTTONS\\WHITE8X8" })
    bg:SetBackdropColor(0.04, 0.04, 0.06, 0.7)

    local bar = CreateFrame("StatusBar", nil, parent)
    bar:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
    bar:SetStatusBarColor(col[1], col[2], col[3])
    bar:SetMinMaxValues(0, 100)
    bar:SetValue(100)

    local lbl = bar:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    lbl:SetPoint("LEFT", bar, "LEFT", 35, 0)
    lbl:SetText(label)
    lbl:SetShadowOffset(1, -1)

    local val = bar:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    val:SetPoint("LEFT", bar, "LEFT", 4, 0)
    val:SetText("--")
    val:SetShadowOffset(1, -1)

    bar._bg  = bg
    bar._lbl = lbl
    bar._val = val

    function bar:SetLayout(x, y, w, h)
        bg:SetPoint("TOPLEFT",     nil, "TOPLEFT", x - 1, y + 1)
        bg:SetPoint("BOTTOMRIGHT", nil, "TOPLEFT", x + w + 1, y - h - 1)
        self:SetPoint("TOPLEFT",     nil, "TOPLEFT", x, y)
        self:SetPoint("BOTTOMRIGHT", nil, "TOPLEFT", x + w, y - h)
        bg:SetParent(parent)
        self:SetParent(parent)
    end

    function bar:Update(v)
        local pct = tonumber(v) or 0
        self:SetValue(pct)
        self._val:SetText(string.format("%.0f%%", pct))
        local r = pct < 30 and 1 or (pct < 60 and 0.9 or col[1])
        local g = pct < 30 and 0.2 or (pct < 60 and 0.6 or col[2])
        local b_c = col[3]
        self:SetStatusBarColor(r, g, b_c)
    end
    return bar
end

local function Clamp(v, mn, mx) return math.max(mn, math.min(mx, v)) end

local function ShrinkScrollBarArt(scrollBar, name, scale)
    local thumb = scrollBar.GetThumbTexture and scrollBar:GetThumbTexture()
    if thumb then
        thumb:SetSize(thumb:GetWidth() * scale, thumb:GetHeight() * scale)
    end
end

local function ReverseScrollBarArrows(scrollBar, name, step, getPos, setPos)
    local function Replace(orig, texKey, onClick)
        if not orig then return end
        orig:Hide()
        orig:EnableMouse(false)

        local btn = CreateFrame("Button", nil, scrollBar)
        btn:SetSize(orig:GetWidth(), orig:GetHeight())
        btn:SetPoint("CENTER", orig, "CENTER")
        btn:SetNormalTexture("Interface\\Buttons\\UI-ScrollBar-" .. texKey .. "-Up")
        btn:SetPushedTexture("Interface\\Buttons\\UI-ScrollBar-" .. texKey .. "-Down")
        btn:SetDisabledTexture("Interface\\Buttons\\UI-ScrollBar-" .. texKey .. "-Disabled")
        btn:SetHighlightTexture("Interface\\Buttons\\UI-ScrollBar-" .. texKey .. "-Highlight", "ADD")
        btn:SetScript("OnClick", onClick)
        return btn
    end

    Replace(_G[name .. "ScrollUpButton"], "ScrollUpButton", function()
        local mn, mx = scrollBar:GetMinMaxValues()
        setPos(Clamp(getPos() + step, mn, mx))
    end)
    Replace(_G[name .. "ScrollDownButton"], "ScrollDownButton", function()
        local mn, mx = scrollBar:GetMinMaxValues()
        setPos(Clamp(getPos() - step, mn, mx))
    end)
end

local function MakeBtn(parent, w, h, text, onClick)
    local btn = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    btn:SetSize(w, h)
    btn:SetText(text)
    btn:SetScript("OnClick", onClick)
    return btn
end

local function AttachCooldownOverlay(btn)
    local ovFrame = CreateFrame("Frame", nil, btn)
    ovFrame:SetAllPoints(btn)
    ovFrame:SetFrameLevel(btn:GetFrameLevel() + 10)
    ovFrame:EnableMouse(false)

    local ov = ovFrame:CreateTexture(nil, "OVERLAY")
    ov:SetTexture("Interface\\BUTTONS\\WHITE8X8")
    ov:SetVertexColor(0.5, 0, 0, 0.75)
    ov:SetPoint("TOPLEFT", btn, "TOPLEFT", 1, -1)
    ov:SetPoint("BOTTOMLEFT", btn, "BOTTOMLEFT", 1, 1)
    ov:SetWidth(1)

    ovFrame:Hide()
    btn._cooldownOverlay    = ovFrame
    btn._cooldownOverlayTex = ov
    return ovFrame
end

local function UpdateCooldownOverlay(btn, action)
    local ovFrame = btn and btn._cooldownOverlay
    if not ovFrame then return end
    local left, total = CC:CooldownLeft(action)
    if left <= 0 or total <= 0 then
        ovFrame:Hide()
        return
    end
    local w = math.max(1, math.floor(btn:GetWidth() * (left / total)))
    btn._cooldownOverlayTex:SetWidth(w)
    ovFrame:Show()
end

local function MakeHeader(parent, text)
    local fs = parent:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    fs:SetTextColor(0.55, 0.75, 1.0)
    fs:SetText(text)
    return fs
end

local function MakeLine(parent)
    local f = parent:CreateTexture(nil, "ARTWORK")
    f:SetTexture("Interface\\BUTTONS\\WHITE8X8")
    f:SetVertexColor(0.25, 0.32, 0.45, 0.6)
    f:SetHeight(1)
    return f
end

local _sliderSeq = 0
local function MakeSlider(parent, label, low, high, step, initial, onChange)
    _sliderSeq = _sliderSeq + 1
    local wrap = CreateFrame("Frame", nil, parent)
    wrap:SetSize(200, 44)

    local lblFS = wrap:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    lblFS:SetPoint("TOPLEFT", wrap, "TOPLEFT", 0, 0)
    lblFS:SetText(label)

    local valFS = wrap:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    valFS:SetPoint("TOPRIGHT", wrap, "TOPRIGHT", 0, 0)
    valFS:SetTextColor(1.0, 0.82, 0.1)

    local s = CreateFrame("Slider", "CCSlider" .. _sliderSeq, wrap)
    s:SetPoint("TOPLEFT",  wrap, "TOPLEFT",  0, -16)
    s:SetPoint("TOPRIGHT", wrap, "TOPRIGHT", 0, -16)
    s:SetHeight(16)
    s:SetMinMaxValues(low, high)
    s:SetValueStep(step)
    s:SetValue(initial or low)
    s:SetOrientation("HORIZONTAL")
    s:SetThumbTexture("Interface\\Buttons\\UI-SliderBar-Button-Horizontal")
    s:SetBackdrop({
        bgFile   = "Interface\\Buttons\\UI-SliderBar-Background",
        edgeFile = "Interface\\Buttons\\UI-SliderBar-Border",
        tile = true, tileSize = 8, edgeSize = 8,
        insets = { left=3, right=3, top=6, bottom=6 },
    })

    local loFS = wrap:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    loFS:SetPoint("TOPLEFT", s, "BOTTOMLEFT", 0, -2)
    loFS:SetTextColor(0.55, 0.55, 0.55)
    loFS:SetText(tostring(low))

    local hiFS = wrap:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    hiFS:SetPoint("TOPRIGHT", s, "BOTTOMRIGHT", 0, -2)
    hiFS:SetTextColor(0.55, 0.55, 0.55)
    hiFS:SetText(tostring(high))

    local function Refresh(val)
        val = math.floor(val * 100 + 0.5) / 100
        valFS:SetText(string.format("%.0f%%", val * 100))
        if onChange then onChange(val) end
    end
    Refresh(initial or low)
    s:SetScript("OnValueChanged", function(_, val) Refresh(val) end)

    wrap._slider = s
    return wrap
end

-------------------------------------------------------------------------------
-- Main window
-------------------------------------------------------------------------------
local _win     -- main Frame
local _tabs    = {}   -- [tabName] = { btn, panel }
local _activeTab = "Habitat"

-- References to frequently-updated widgets
local _petNameFS, _petStageFS, _petPersFS, _petCareStatusFS, _leftTreatsFS
local _bondBar, _careBars = nil, {}
local _scavBtns, _scavDetailFS
local _scavStack, _scavStackRows, _scavScrollFrame, _scavScrollBar, _scavTopKey
local _scavScrollPos = 0
local _logFrame
local _challengeRows = {}
local _promoBalFS, _promoDayFS, _promoContent, _promoScrollBar
local _quickBuyBtns = {}      -- Left-panel Quick Buy (purchase-only) buttons
local _careItemRows = {}      -- Left-panel "use an owned item" rows, by item key
local _storeRows = {}
local _model
local _modelPanel
local _bondSpinAngle = 0
local _modelDragging = false
local _modelDragFacing = 0
local _modelFrameMult  = 1.0   -- zoom multiplier (frame-resize zoom)

local function ShowTab(name)
    _activeTab = name
    for tname, t in pairs(_tabs) do
        local selected = (tname == name)
        SetShown(t.panel, selected)
        if t.btn._sel then SetShown(t.btn._sel, selected) end
    end
end

-------------------------------------------------------------------------------
-- Left panel: model + pet identity
-------------------------------------------------------------------------------
local function BuildLeftPanel(parent)
    local lp = CreateFrame("Frame", nil, parent)
    lp:SetPoint("TOPLEFT", parent, "TOPLEFT", 8, -8 - HEADER_PAD)
    lp:SetSize(LEFT_W, WIN_H - 16 - HEADER_PAD)
    ApplyBackdrop(lp, 0.03, 0.04, 0.08, 0.5)

    -- 3D model frame (camera 0 = portrait auto-frame)
    _modelPanel = CreateFrame("Frame", nil, lp)
    _modelPanel:SetPoint("TOP", lp, "TOP", 0, -8)
    _modelPanel:SetSize(LEFT_W - 8, LEFT_W)
    ApplyBackdrop(_modelPanel, 0.02, 0.03, 0.06, CC:GetUI().modelBgAlpha or 0.75)

    _model = CreateFrame("PlayerModel", "CompanionCaddyModel", _modelPanel)
    _model:SetSize(CC.MODEL_SIZES.default.w, CC.MODEL_SIZES.default.h)
    _model:SetPoint("CENTER", _modelPanel, "CENTER", 0, 0)
    _model:Hide()

    -- "No companion" label shown when model hidden
    local noCompFS = _modelPanel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    noCompFS:SetPoint("CENTER", _modelPanel, "CENTER", 0, 0)
    noCompFS:SetTextColor(0.40, 0.40, 0.45)
    noCompFS:SetText("No companion\nsummoned.")
    noCompFS:SetJustifyH("CENTER")
    _modelPanel.noCompLabel = noCompFS

    -- Model OnUpdate: bonding spin + one-shot position reset
    _model:SetScript("OnUpdate", function(self, dt)
        if self._needsTransform then
            self._needsTransform = nil
            pcall(self.SetPosition, self, 0, 0, 0)
        end
        local pet = CC:GetPet()
        if pet and pet.stage == "bonding" then
            _bondSpinAngle = (_bondSpinAngle + 0.55 * dt) % (2 * math.pi)
            pcall(self.SetFacing, self, -_bondSpinAngle)
        end
    end)

    -- Right-drag to rotate (companion stage only)
    _modelPanel:EnableMouse(true)
    _modelPanel:RegisterForDrag("RightButton")
    _modelPanel:SetScript("OnDragStart", function(self, btn)
        local pet = CC:GetPet()
        if btn ~= "RightButton" or not pet or pet.stage ~= "companion" then return end
        _modelDragging = true
        _modelDragFacing = 0
    end)
    _modelPanel:SetScript("OnDragStop", function()
        _modelDragging = false
    end)
    _modelPanel:SetScript("OnUpdate", function(self)
        if not _modelDragging then return end
        if not IsMouseButtonDown("RightButton") then _modelDragging = false; return end
        local _, y = GetCursorPosition()   -- x delta used for facing
        local cx   = select(1, GetCursorPosition())
        local scale = UIParent:GetEffectiveScale()
        local mx    = select(1, _modelPanel:GetCenter())
        local dx    = (cx / scale) - mx
        pcall(_model.SetFacing, _model, dx * 0.02)
    end)

    -- Scroll-wheel zoom (resize frame for camera-0 zoom)
    _modelPanel:EnableMouseWheel(true)
    _modelPanel:SetScript("OnMouseWheel", function(self, delta)
        local pet = CC:GetPet()
        if not pet or pet.stage ~= "companion" then return end
        _modelFrameMult = math.max(0.5, math.min(2.5, _modelFrameMult + delta * 0.15))
        local def = CC.MODEL_SIZES[CC.activePet and CC.activePet.creatureID] or CC.MODEL_SIZES.default
        local nw = math.floor(def.w * _modelFrameMult)
        local nh = math.floor(def.h * _modelFrameMult)
        _model:SetSize(nw, nh)
    end)

    -- Pet identity section
    _petNameFS = lp:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    _petNameFS:SetPoint("TOP", _modelPanel, "BOTTOM", 0, -8)
    _petNameFS:SetWidth(LEFT_W - 8)
    _petNameFS:SetJustifyH("CENTER")
    _petNameFS:SetText("—")

    _petStageFS = lp:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    _petStageFS:SetPoint("TOP", _petNameFS, "BOTTOM", 0, -2)
    _petStageFS:SetTextColor(0.65, 0.85, 1.0)
    _petStageFS:SetJustifyH("CENTER")
    _petStageFS:SetText("")

    _petPersFS = lp:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    _petPersFS:SetPoint("TOP", _petStageFS, "BOTTOM", 0, -2)
    _petPersFS:SetTextColor(0.75, 0.65, 0.90)
    _petPersFS:SetJustifyH("CENTER")
    _petPersFS:SetText("")

    _petCareStatusFS = lp:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    _petCareStatusFS:SetPoint("TOP", _petPersFS, "BOTTOM", 0, -2)
    _petCareStatusFS:SetWidth(LEFT_W - 8)
    _petCareStatusFS:SetJustifyH("CENTER")
    _petCareStatusFS:SetText("")

    -----------------------------------------------------------------------
    -- Care Items + Quick Buy — 
    -- Single-column layout since the left column is narrower than the
    -- right panel.
    -----------------------------------------------------------------------
    local lcW  = LEFT_W - 16
    local lyOff = -8

    local itemsHdr = lp:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    itemsHdr:SetPoint("TOP", _petCareStatusFS, "BOTTOM", 0, -10)
    itemsHdr:SetTextColor(0.55, 0.75, 1.0)
    itemsHdr:SetText("Care Items")

    local icRowH = 18
    _careItemRows = {}
    for idx, d in ipairs(CC.STORE_ITEMS) do
        local f = CreateFrame("Frame", nil, lp)
        f:SetPoint("TOP", itemsHdr, "BOTTOM", 0, -4 - (idx - 1) * (icRowH + 2))
        f:SetSize(lcW, icRowH)

        local invFS = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        invFS:SetPoint("LEFT", f, "LEFT", 0, 0)
        invFS:SetWidth(35)
        invFS:SetJustifyH("LEFT")
        invFS:SetTextColor(1.0, 0.82, 0.1)
        invFS:SetText("0")

        local nameFS = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        nameFS:SetPoint("LEFT", f, "LEFT", 26, 0)
        nameFS:SetPoint("RIGHT", f, "RIGHT", -34, 0)
        nameFS:SetJustifyH("LEFT")
        nameFS:SetText(d.name)

        local effFS = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        local capstr = (d.stat)
        local capitalized = "+" .. capstr:sub(1,1):upper() .. capstr:sub(2)
        effFS:SetPoint("RIGHT", f, "RIGHT", -34, 0)
        effFS:SetJustifyH("RIGHT")
        effFS:SetTextColor(0.7, 0.9, 0.55)
        effFS:SetText(capitalized)

        local key = d.key
        local useBtn = MakeBtn(f, 32, 16, "Use", function()
            local ok, msg = CC:UseFood(key)
            if not ok then CC:Print(msg) end
        end)
        useBtn:SetPoint("RIGHT", f, "RIGHT", 0, 0)

        f._invFS  = invFS
        f._useBtn = useBtn
        _careItemRows[d.key] = f
    end

    local itemsBottom = itemsHdr
    local qbHdr = lp:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    qbHdr:SetPoint("TOP", itemsHdr, "BOTTOM", 0, -4 - (#CC.STORE_ITEMS * (icRowH + 2)) - 8)
    qbHdr:SetTextColor(0.55, 0.75, 1.0)
    qbHdr:SetText("Quick Buy")

    _leftTreatsFS = lp:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    _leftTreatsFS:SetPoint("TOP", qbHdr, "BOTTOM", 0, -4)
    _leftTreatsFS:SetTextColor(1.0, 0.82, 0.1)
    _leftTreatsFS:SetText("(0)")

    _quickBuyBtns = {}
    for i = 1, 3 do
        local idx = i
        local btn = CreateFrame("Button", nil, lp, "UIPanelButtonTemplate")
        btn:SetSize(lcW, 18)
        btn:SetPoint("TOP", qbHdr, "BOTTOM", 0, -16 - (i - 1) * 21)
        btn:SetText("—")
        btn:SetScript("OnClick", function()
            local ui  = CC:GetUI()
            local key = ui.quickBuy and ui.quickBuy[idx]
            if not key then return end
            local ok, msg = CC:BuyItem(key)
            if not ok then CC:Print(msg) end
        end)
        btn:SetScript("OnEnter", function(self)
            local ui  = CC:GetUI()
            local key = ui.quickBuy and ui.quickBuy[idx]
            if not key then return end
            for _, d in ipairs(CC.STORE_ITEMS) do
                if d.key == key then
                    GameTooltip:SetOwner(self, "ANCHOR_TOP")
                    GameTooltip:SetText(d.name)
                    GameTooltip:AddDoubleLine("Effect", "+"..d.gain.." "..d.stat, 1,1,1, 0.8,0.9,0.5)
                    GameTooltip:AddDoubleLine("Cost",   d.cost.." treats",        1,1,1, 1.0,0.82,0.1)
                    GameTooltip:AddLine("Click to buy 1 (use it from Care Items above).", 0.6, 0.6, 0.65, true)
                    GameTooltip:Show()
                    break
                end
            end
        end)
        btn:SetScript("OnLeave", function() GameTooltip:Hide() end)
        _quickBuyBtns[i] = btn
    end

    local hintFS = lp:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    hintFS:SetPoint("BOTTOM", lp, "BOTTOM", 0, 6)
    hintFS:SetTextColor(0.35, 0.35, 0.40)
    hintFS:SetText("Scroll: zoom  |  Right-drag: rotate")
    hintFS:SetWidth(LEFT_W - 8)
    hintFS:SetJustifyH("CENTER")

    return lp
end

-------------------------------------------------------------------------------
-- Right panel: tab bar + content
-------------------------------------------------------------------------------
local function BuildRightPanel(parent)
    local rp = CreateFrame("Frame", nil, parent)
    rp:SetPoint("TOPLEFT", parent, "TOPLEFT", LEFT_W + 12, -8 - HEADER_PAD)
    rp:SetSize(RIGHT_W, WIN_H - 16 - HEADER_PAD)

    -- Tab bar
    local tabBar = CreateFrame("Frame", nil, rp)
    tabBar:SetPoint("TOPLEFT", rp, "TOPLEFT", 0, 0)
    tabBar:SetSize(RIGHT_W, 26)

    local tabW = math.floor(RIGHT_W / #TABS) - 2
    local tabX = 0

    for _, tname in ipairs(TABS) do
        local btn = CreateFrame("Button", nil, tabBar)
        btn:SetSize(tabW, 24)
        btn:SetPoint("TOPLEFT", tabBar, "TOPLEFT", tabX, 0)
        tabX = tabX + tabW + 2

        local bg = btn:CreateTexture(nil, "BACKGROUND")
        bg:SetAllPoints()
        bg:SetTexture("Interface\\BUTTONS\\WHITE8X8")
        bg:SetVertexColor(0.12, 0.16, 0.24, 0.85)
        btn._bg = bg

        local sel = btn:CreateTexture(nil, "BACKGROUND")
        sel:SetAllPoints()
        sel:SetTexture("Interface\\BUTTONS\\WHITE8X8")
        sel:SetVertexColor(0.25, 0.45, 0.80, 0.55)
        sel:Hide()
        btn._sel = sel

        btn:SetHighlightTexture("Interface\\BUTTONS\\WHITE8X8")
        btn:GetHighlightTexture():SetVertexColor(0.45, 0.65, 1.0, 0.15)

        local fs = btn:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        fs:SetAllPoints()
        fs:SetJustifyH("CENTER")
        fs:SetText(tname)

        local n = tname
        btn:SetScript("OnClick", function() ShowTab(n) end)

        -- Content panel
        local panel = CreateFrame("Frame", nil, rp)
        panel:SetPoint("TOPLEFT",     rp, "TOPLEFT",     0, -28)
        panel:SetPoint("BOTTOMRIGHT", rp, "BOTTOMRIGHT", 0,   0)
        panel:Hide()

        _tabs[tname] = { btn = btn, panel = panel }
    end

    return rp
end

-------------------------------------------------------------------------------
-- Habitat tab
-------------------------------------------------------------------------------
local function BuildHabitatTab(panel)
    local P  = panel
    local cW = RIGHT_W - 16
    local yOff = -6

    -----------------------------------------------------------------------
    -- Slot 1: Bonding Progress bar  OR  4 compact Needs bars (same slot)
    -----------------------------------------------------------------------
    _bondBar = MakeCareBar(P, "Bonding Progress", COL.bonding)
    _bondBar:SetPoint("TOPLEFT",  P, "TOPLEFT",  8, yOff)
    _bondBar:SetPoint("TOPRIGHT", P, "TOPRIGHT", -8, yOff)
    _bondBar:SetHeight(64)
    _bondBar._bg:SetPoint("TOPLEFT",     P, "TOPLEFT",  7, yOff + 1)
    _bondBar._bg:SetPoint("BOTTOMRIGHT", P, "TOPRIGHT", -7, yOff - 65)

    local statOrder = { "hunger", "joy", "energy", "cleanliness" }
    local statLabel = { hunger="Hunger", joy="Joy", energy="Energy", cleanliness="Cleanliness" }
    local barStep = 17   -- 15px bar + 2px gap
    for i, stat in ipairs(statOrder) do
        local by = yOff - (i - 1) * barStep
        local bar = MakeCareBar(P, statLabel[stat], COL[stat])
        bar:SetPoint("TOPLEFT",  P, "TOPLEFT",  8, by)
        bar:SetPoint("TOPRIGHT", P, "TOPRIGHT", -8, by)
        bar:SetHeight(15)
        bar._bg:SetPoint("TOPLEFT",     P, "TOPLEFT",  7, by + 1)
        bar._bg:SetPoint("BOTTOMRIGHT", P, "TOPRIGHT", -7, by - 16)
        _careBars[stat] = bar
    end
    yOff = yOff - (barStep * 4) - 6   -- reserve the taller of the two (4 bars)

    -----------------------------------------------------------------------
    -- Slot 2: Care Actions (Feed/Play/Rest/Clean, single row)  OR
    --         Bonding Actions (Soothe/Warm/Clean, single row) — same slot
    -----------------------------------------------------------------------
    local hdr = MakeHeader(P, "Care Actions")
    hdr:SetPoint("TOPLEFT", P, "TOPLEFT", 8, yOff)

    local bondHdr = MakeHeader(P, "Bonding Actions")
    bondHdr:SetPoint("TOPLEFT", P, "TOPLEFT", 8, yOff)
    yOff = yOff - 15

    local careActions = {
        { id="feed",  label="Feed"  },
        { id="play",  label="Play"  },
        { id="rest",  label="Rest"  },
        { id="clean", label="Clean" },
    }
    local cbW = math.floor((cW - (#careActions - 1) * 4) / #careActions)
    panel._careButtons = {}
    panel._careHdr     = hdr
    for i, ca in ipairs(careActions) do
        local btn = MakeBtn(P, cbW, 20, ca.label, function()
            local ok, msg = CC:DoAction(ca.id)
            if not ok then CC:Print(msg) end
        end)
        btn:SetPoint("TOPLEFT", P, "TOPLEFT", 8 + (i-1) * (cbW + 4), yOff)
        AttachCooldownOverlay(btn)
        btn._action = ca.id
        panel._careButtons[i] = btn
    end

    local bondActions = {
        { id="soothe", label="Soothe" },
        { id="warm",   label="Warm"   },
        { id="clean",  label="Clean"  },
    }
    local bbW = math.floor((cW - (#bondActions - 1) * 4) / #bondActions)
    panel._bondButtons = {}
    panel._bondHdr     = bondHdr
    for i, ba in ipairs(bondActions) do
        local btn = MakeBtn(P, bbW, 20, ba.label, function()
            local ok, msg = CC:DoAction(ba.id)
            if not ok then CC:Print(msg) end
        end)
        btn:SetPoint("TOPLEFT", P, "TOPLEFT", 8 + (i-1) * (bbW + 4), yOff)
        AttachCooldownOverlay(btn)
        btn._action = ba.id
        panel._bondButtons[i] = btn
    end
    yOff = yOff - 20 - 8

    do local ln = MakeLine(P)
        ln:SetPoint("TOPLEFT",  P, "TOPLEFT",  8, yOff)
        ln:SetPoint("TOPRIGHT", P, "TOPRIGHT", -8, yOff)
    end
    yOff = yOff - 8

    -----------------------------------------------------------------------
    -- Scavenging — header, duration buttons pulled up close under the
    -- separator above, then a scrollable stack of per-companion widgets
    -- (one row per companion currently out scavenging, any companion --
    -- not just whichever is summoned right now), and a single hint line
    -- about the currently-summoned companion specifically.
    -----------------------------------------------------------------------
    local scavHdr = MakeHeader(P, "Scavenging")
    scavHdr:SetPoint("TOPLEFT", P, "TOPLEFT", 8, yOff)
    panel._scavHdr = scavHdr
    yOff = yOff - 15

    local SCAV_BTN_H = 16
    local scavBtnW = math.floor((cW - 8) / 3)
    _scavBtns = {}
    for i, opt in ipairs(CC.SCAVENGE_OPTS) do
        local idx = i
        local btn = MakeBtn(P, scavBtnW, SCAV_BTN_H, opt.label, function()
            local ok, msg = CC:StartScavenge(idx)
            if not ok then CC:Print(msg) end
        end)
        btn:SetPoint("TOPLEFT", P, "TOPLEFT", 8 + (i-1) * (scavBtnW + 4), yOff)
        btn:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_TOP")
            GameTooltip:SetText(opt.label)
            GameTooltip:AddDoubleLine("Reward", opt.min .. "–" .. opt.max .. " treats", 1,1,1, 1.0,0.82,0.1)
            GameTooltip:AddLine("A better-cared-for companion has better odds at bonus loot on return.", 0.6, 0.85, 1.0, true)
            GameTooltip:Show()
        end)
        btn:SetScript("OnLeave", function() GameTooltip:Hide() end)
        _scavBtns[i] = btn
    end
    yOff = yOff - SCAV_BTN_H - 4

    local SCAV_VIEW_ROWS = 4
    local scavViewH = SCAV_VIEW_ROWS * SCAV_ROW_H

    _scavScrollFrame = CreateFrame("ScrollFrame", nil, P)
    _scavScrollFrame:SetPoint("TOPLEFT",  P, "TOPLEFT",  8, yOff)
    _scavScrollFrame:SetPoint("TOPRIGHT", P, "TOPRIGHT", -16, yOff)
    _scavScrollFrame:SetHeight(scavViewH)

    _scavScrollBar = CreateFrame("Slider", "CompanionCaddyScavScrollBar", P, "UIPanelScrollBarTemplate")
    _scavScrollBar:SetPoint("TOPRIGHT",    _scavScrollFrame, "TOPRIGHT",    18, -16)
    _scavScrollBar:SetPoint("BOTTOMRIGHT", _scavScrollFrame, "BOTTOMRIGHT", 18,  16)
    _scavScrollBar:SetMinMaxValues(0, 0)
    _scavScrollBar:SetValueStep(SCAV_ROW_H)
    _scavScrollBar:SetValue(0)
    _scavScrollBar:Hide()   -- shown by CC:UpdateScavengeStack only once there's anything to scroll
    ShrinkScrollBarArt(_scavScrollBar, "CompanionCaddyScavScrollBar", 0.75)
    ReverseScrollBarArrows(_scavScrollBar, "CompanionCaddyScavScrollBar", SCAV_ROW_H,
        function() return _scavScrollPos end,
        function(v) _scavScrollPos = v; _scavScrollBar:SetValue(v) end)
    _scavScrollBar:SetScript("OnValueChanged", function(self_, v)
        _scavScrollPos = v
        local _, mx = self_:GetMinMaxValues()
        _scavScrollFrame:SetVerticalScroll(mx - v)
    end)
    _scavScrollFrame:EnableMouseWheel(true)
    _scavScrollFrame:SetScript("OnMouseWheel", function(_, d)
        local mn, mx = _scavScrollBar:GetMinMaxValues()
        local newPos = Clamp(_scavScrollPos + d * SCAV_ROW_H * 2, mn, mx)
        _scavScrollPos = newPos
        _scavScrollBar:SetValue(newPos)
    end)

    _scavStack = CreateFrame("Frame", nil, _scavScrollFrame)
    _scavStack:SetSize(cW - 8, scavViewH)
    _scavScrollFrame:SetScrollChild(_scavStack)

    _scavStackRows = {}   -- grown on demand in CC:UpdateScavengeStack

    local _scavAccum = 0
    _scavScrollFrame:SetScript("OnUpdate", function(self, dt)
        _scavAccum = _scavAccum + dt
        if _scavAccum < 1 then return end
        _scavAccum = 0
        CC:UpdateScavengeStack()
    end)

    yOff = yOff - scavViewH - 4

    _scavDetailFS = P:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    _scavDetailFS:SetPoint("TOPLEFT",  P, "TOPLEFT",  8, yOff)
    _scavDetailFS:SetPoint("TOPRIGHT", P, "TOPRIGHT", -8, yOff)
    _scavDetailFS:SetHeight(36)
    _scavDetailFS:SetJustifyH("LEFT")
    _scavDetailFS:SetTextColor(0.55, 0.75, 1.0)
    _scavDetailFS:SetText("")
    yOff = yOff - 18 - 18

    do local ln = MakeLine(P)
        ln:SetPoint("TOPLEFT",  P, "TOPLEFT",  8, yOff)
        ln:SetPoint("TOPRIGHT", P, "TOPRIGHT", -8, yOff)
    end
    yOff = yOff - 8

    -----------------------------------------------------------------------
    -- Active Challenges — compact rows, statically visible, with a short
    -- explanation of the reward mechanic and a per-row hover hint on how
    -- to complete each one.
    -----------------------------------------------------------------------
    MakeHeader(P, "Active Challenges"):SetPoint("TOPLEFT", P, "TOPLEFT", 8, yOff)
    yOff = yOff - 14

    local challengeSub = P:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    challengeSub:SetPoint("TOPLEFT", P, "TOPLEFT", 8, yOff)
    challengeSub:SetWidth(cW)
    challengeSub:SetJustifyH("LEFT")
    challengeSub:SetWordWrap(true)
    challengeSub:SetTextColor(0.50, 0.55, 0.60)
    challengeSub:SetText("Completing a challenge awards Treats, plus Promo Points if connected to a Promo-enabled server. New challenges appear automatically. Hover over a challenge for a hint.")
    yOff = yOff - 28

    for i = 1, 4 do
        local row = CreateFrame("Frame", nil, P)
        row:SetPoint("TOPLEFT",  P, "TOPLEFT",  8, yOff)
        row:SetPoint("TOPRIGHT", P, "TOPRIGHT", -8, yOff)
        row:SetHeight(22)
        ApplyBackdrop(row, 0.06, 0.08, 0.12, 0.70)
        row:EnableMouse(true)

        local pbar = CreateFrame("StatusBar", nil, row)
        pbar:SetAllPoints()
        pbar:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
        pbar:SetStatusBarColor(0.35, 0.60, 0.90, 0.40)
        pbar:SetMinMaxValues(0, 1)
        pbar:SetValue(0)

        local lbl = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        lbl:SetPoint("LEFT",  row, "LEFT",  6, 0)
        lbl:SetPoint("RIGHT", row, "RIGHT", -38, 0)
        lbl:SetJustifyH("LEFT")
        lbl:SetText("No challenge")

        local prog = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        prog:SetPoint("RIGHT", row, "RIGHT", -6, 0)
        prog:SetTextColor(1.0, 0.82, 0.1)
        prog:SetText("")

        row:SetScript("OnEnter", function(self)
            if not self._hint or self._hint == "" then return end
            GameTooltip:SetOwner(self, "ANCHOR_TOP")
            GameTooltip:SetText(self._label or "Challenge", 1, 1, 1)
            GameTooltip:AddLine(self._hint, 0.65, 0.85, 1.0, true)
            if self._reward then
                GameTooltip:AddLine(" ")
                GameTooltip:AddDoubleLine("Reward", self._reward .. " treats", 1,1,1, 1.0,0.82,0.1)
            end
            GameTooltip:Show()
        end)
        row:SetScript("OnLeave", function() GameTooltip:Hide() end)

        row._lbl  = lbl
        row._prog = prog
        row._bar  = pbar
        _challengeRows[i] = row
        yOff = yOff - (22 + 3)
    end
    yOff = yOff - 3

    do local ln = MakeLine(P)
        ln:SetPoint("TOPLEFT",  P, "TOPLEFT",  8, yOff)
        ln:SetPoint("TOPRIGHT", P, "TOPRIGHT", -8, yOff)
    end
    yOff = yOff - 8

    -----------------------------------------------------------------------
    -- Activity Log 
    -----------------------------------------------------------------------
    MakeHeader(P, "Activity Log"):SetPoint("TOPLEFT", P, "TOPLEFT", 8, yOff)
    yOff = yOff - 15

    local logBG = CreateFrame("Frame", nil, P)
    logBG:SetPoint("TOPLEFT",     P, "TOPLEFT",     8, yOff)
    logBG:SetPoint("BOTTOMRIGHT", P, "BOTTOMRIGHT", -8, 6)
    ApplyBackdrop(logBG, 0.03, 0.04, 0.07, 0.80)

    _logFrame = CreateFrame("ScrollingMessageFrame", nil, logBG)
    _logFrame:SetPoint("TOPLEFT",     logBG, "TOPLEFT",     4, -4)
    _logFrame:SetPoint("BOTTOMRIGHT", logBG, "BOTTOMRIGHT", -4, 4)
    _logFrame:SetFading(false)
    _logFrame:SetMaxLines(120)
    _logFrame:SetFont("Fonts\\FRIZQT__.TTF", 10)
    _logFrame:SetJustifyH("LEFT")
    _logFrame:EnableMouseWheel(true)
    _logFrame:SetScript("OnMouseWheel", function(self, d)
        if d > 0 then self:ScrollUp() else self:ScrollDown() end
    end)

    -----------------------------------------------------------------------
    -- Scavenge-item popup (shown when a scavenge roll grants a bonus item)
    -----------------------------------------------------------------------
    local POPUP_ROWS_VISIBLE = 3

    local scavPopup = CreateFrame("Frame", "CCScavengeItemPopup", UIParent)
    scavPopup:SetSize(300, 90 + POPUP_ROWS_VISIBLE * POPUP_ROW_H)
    scavPopup:SetPoint("CENTER")
    scavPopup:SetFrameStrata("DIALOG")
    ApplyBackdrop(scavPopup, 0.04, 0.04, 0.08, 0.97, 0.45, 0.65, 1.0)
    scavPopup:Hide()
    scavPopup:EnableMouse(true)
    scavPopup:SetMovable(true)
    scavPopup:RegisterForDrag("LeftButton")
    scavPopup:SetScript("OnDragStart", scavPopup.StartMoving)
    scavPopup:SetScript("OnDragStop",  scavPopup.StopMovingOrSizing)

    local spTitle = scavPopup:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    spTitle:SetPoint("TOP", scavPopup, "TOP", 0, -14)
    spTitle:SetText("A find while scavenging!")

    local spFlavor = scavPopup:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    spFlavor:SetPoint("TOP", spTitle, "BOTTOM", 0, -8)
    spFlavor:SetWidth(264)
    spFlavor:SetJustifyH("CENTER")
    spFlavor:SetTextColor(0.65, 0.85, 1.0)
    spFlavor:SetText("Your companions brought back something unexpected!")

    local spListFrame = CreateFrame("ScrollFrame", nil, scavPopup)
    spListFrame:SetPoint("TOP",   spFlavor, "BOTTOM", 0, -8)
    spListFrame:SetSize(264, POPUP_ROWS_VISIBLE * POPUP_ROW_H)

    local spListBar = CreateFrame("Slider", "CCScavengeItemPopupScrollBar", scavPopup, "UIPanelScrollBarTemplate")
    spListBar:SetPoint("TOPLEFT",    spListFrame, "TOPRIGHT",    -4, -16)
    spListBar:SetPoint("BOTTOMLEFT", spListFrame, "BOTTOMRIGHT", -4,  16)
    spListBar:SetMinMaxValues(0, 0)
    spListBar:SetValueStep(POPUP_ROW_H)
    spListBar:SetValue(0)
    spListBar:Hide()
    ShrinkScrollBarArt(spListBar, "CCScavengeItemPopupScrollBar", 0.75)

    scavPopup._scrollPos = 0
    spListBar:SetScript("OnValueChanged", function(_, v)
        scavPopup._scrollPos = v
        spListFrame:SetVerticalScroll(v)
    end)
    spListFrame:EnableMouseWheel(true)
    spListFrame:SetScript("OnMouseWheel", function(_, d)
        local mn, mx = spListBar:GetMinMaxValues()
        local newPos = Clamp(scavPopup._scrollPos - d * POPUP_ROW_H, mn, mx)
        scavPopup._scrollPos = newPos
        spListBar:SetValue(newPos)
    end)

    local spListStack = CreateFrame("Frame", nil, spListFrame)
    spListStack:SetSize(264 - 20, POPUP_ROWS_VISIBLE * POPUP_ROW_H)
    spListFrame:SetScrollChild(spListStack)

    local spHint = scavPopup:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    spHint:SetPoint("TOP", spListFrame, "BOTTOM", 0, 0)
    spHint:SetWidth(264)
    spHint:SetJustifyH("CENTER")
    spHint:SetTextColor(0.50, 0.50, 0.55)
    spHint:SetText("Hover an item for details. Close this whenever you're ready.")

    local spClose = CreateFrame("Button", nil, scavPopup, "UIPanelCloseButton")
    spClose:SetPoint("TOPRIGHT", scavPopup, "TOPRIGHT", -4, -4)
    spClose:SetScript("OnClick", function()
        scavPopup:Hide()
        wipe(scavPopup._items)
    end)

    scavPopup._listFrame = spListFrame
    scavPopup._listBar   = spListBar
    scavPopup._listStack = spListStack
    scavPopup._items     = {}   -- [1] = newest; see CC:ShowScavengeItemNotice
    scavPopup._rows      = {}   -- grown on demand in CC:RefreshScavengePopupList
    P._scavengeItemPopup = scavPopup
end


-------------------------------------------------------------------------------
-- Store tab
-------------------------------------------------------------------------------
local function BuildStoreTab(panel)
    local yOff = -24

    -- Treats balance
    local treatFS = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    treatFS:SetPoint("TOPLEFT", panel, "TOPLEFT", 10, yOff)
    treatFS:SetText("Treats: --")
    panel._treatFS = treatFS
    yOff = yOff - 24

    do local ln=MakeLine(panel); ln:SetPoint("TOPLEFT",panel,"TOPLEFT",8,yOff); ln:SetPoint("TOPRIGHT",panel,"TOPRIGHT",-8,yOff) end; yOff = yOff - 8

    -- Full item list
    local shdr = MakeHeader(panel, "Shop")
    shdr:SetPoint("TOPLEFT", panel, "TOPLEFT", 10, yOff)
    yOff = yOff - 18

    local rowH  = 39
    local colW1 = math.floor(RIGHT_W * 0.44)
    local colW2 = 70
    local colW3 = 50

    for _, d in ipairs(CC.STORE_ITEMS) do
        local row = CreateFrame("Frame", nil, panel)
        row:SetPoint("TOPLEFT",  panel, "TOPLEFT",  8, yOff)
        row:SetPoint("TOPRIGHT", panel, "TOPRIGHT", -8, yOff)
        row:SetHeight(rowH)

        local icon = row:CreateTexture(nil, "ARTWORK")
        icon:SetSize(24, 24)
        icon:SetPoint("LEFT", row, "LEFT", 2, 0)
        icon:SetTexture("Interface\\Icons\\" .. (d.icon or CC.STORE_ICON_DEFAULT))

        local nameFS = row:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        nameFS:SetPoint("LEFT", icon, "RIGHT", 8, 0)
        nameFS:SetWidth(colW1 - 24)
        nameFS:SetJustifyH("LEFT")
        nameFS:SetText(d.name)

        local effFS = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        effFS:SetPoint("LEFT", row, "LEFT", colW1 - 64, 0)
        effFS:SetWidth(colW2 + 10)
        effFS:SetJustifyH("LEFT")
        effFS:SetTextColor(0.7, 0.9, 0.55)
        effFS:SetText(string.format("+%d %s", d.gain, d.stat))

        local costFS = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        costFS:SetPoint("LEFT", row, "LEFT", colW1 + colW2 + 20, 0)
        costFS:SetWidth(colW3)
        costFS:SetJustifyH("LEFT")
        costFS:SetTextColor(1.0, 0.82, 0.1)
        costFS:SetText(d.cost .. " treats")

        local key = d.key
        local buyBtn = MakeBtn(row, 52, 20, "Buy", function()
            local ok, msg = CC:BuyItem(key)
            if not ok then CC:Print(msg) end
        end)
        buyBtn:SetPoint("RIGHT", row, "RIGHT", -4, 0)
        row._buyBtn = buyBtn

        local invFS = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        invFS:SetPoint("RIGHT", buyBtn, "LEFT", -4, 0)
        invFS:SetTextColor(0.65, 0.65, 0.65)
        invFS:SetText("×0")
        row._invFS = invFS

        _storeRows[d.key] = row
        yOff = yOff - (rowH + 2)
    end
end

-------------------------------------------------------------------------------
-- Customization tab
-------------------------------------------------------------------------------
local function BuildCustomizationTab(panel)
    local yOff = -12

    MakeHeader(panel, "Display"):SetPoint("TOPLEFT", panel, "TOPLEFT", 10, yOff)
    yOff = yOff - 22

    -- Window transparency slider
    local winSlider = MakeSlider(panel, "Window Opacity", 0.3, 1.0, 0.05, CC:GetUI().windowAlpha,
        function(v)
            CC:GetUI().windowAlpha = v
            if _win then ApplyBackdropAlpha(_win, v) end
        end)
    winSlider:SetPoint("TOPLEFT", panel, "TOPLEFT", 20, yOff)
    yOff = yOff - 52

    -- Model background transparency slider
    local mdlSlider = MakeSlider(panel, "Model Background Opacity", 0.1, 1.0, 0.05, CC:GetUI().modelBgAlpha,
        function(v)
            CC:GetUI().modelBgAlpha = v
            if _modelPanel then ApplyBackdropAlpha(_modelPanel, v) end
        end)
    mdlSlider:SetPoint("TOPLEFT", panel, "TOPLEFT", 20, yOff)
    yOff = yOff - 52

    -- Tracker transparency slider
    local trkSlider = MakeSlider(panel, "Tracker Opacity", 0.1, 1.0, 0.05, CC:GetUI().trackerAlpha,
        function(v)
            CC:GetUI().trackerAlpha = v
            if CC._tracker then
                ApplyBackdropAlpha(CC._tracker, v)
                CC._tracker:SetAlpha(v)
            end
        end)
    trkSlider:SetPoint("TOPLEFT", panel, "TOPLEFT", 20, yOff)
    yOff = yOff - 52

    do local ln=MakeLine(panel); ln:SetPoint("TOPLEFT",panel,"TOPLEFT",8,yOff); ln:SetPoint("TOPRIGHT",panel,"TOPRIGHT",-8,yOff) end; yOff = yOff - 12

    MakeHeader(panel, "Model"):SetPoint("TOPLEFT", panel, "TOPLEFT", 10, yOff)
    yOff = yOff - 22

    MakeBtn(panel, 150, 24, "Reset Model Position", function()
        _modelFrameMult = 1.0
        local ap = CC.activePet
        local def = ap and (CC.MODEL_SIZES[ap.creatureID] or CC.MODEL_SIZES.default) or CC.MODEL_SIZES.default
        if _model then
            _model:SetSize(def.w, def.h)
            pcall(_model.SetFacing, _model, 0)
        end
    end):SetPoint("TOPLEFT", panel, "TOPLEFT", 10, yOff)
    yOff = yOff - 32

    do local ln=MakeLine(panel); ln:SetPoint("TOPLEFT",panel,"TOPLEFT",8,yOff); ln:SetPoint("TOPRIGHT",panel,"TOPRIGHT",-8,yOff) end; yOff = yOff - 12

    MakeHeader(panel, "Tracker"):SetPoint("TOPLEFT", panel, "TOPLEFT", 10, yOff)
    yOff = yOff - 22

    -- Show tracker checkbox
    local chk = CreateFrame("CheckButton", nil, panel, "UICheckButtonTemplate")
    chk:SetPoint("TOPLEFT", panel, "TOPLEFT", 10, yOff)
    chk:SetSize(24, 24)
    chk:SetChecked(CC:GetUI().showTracker)
    local chkLbl = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    chkLbl:SetPoint("LEFT", chk, "RIGHT", 4, 0)
    chkLbl:SetText("Show tracker bar")
    chk:SetScript("OnClick", function(self)
        local v = self:GetChecked() and true or false
        CC:GetUI().showTracker = v
        if CC._tracker then SetShown(CC._tracker, v and CC.activePet ~= nil) end
    end)
    yOff = yOff - 32

    MakeBtn(panel, 150, 24, "Reset Tracker Position", function()
        if CC._tracker then
            CC._tracker:ClearAllPoints()
            CC._tracker:SetPoint("BOTTOM", UIParent, "BOTTOM", 0, 200)
            CC:GetUI().trackerX = nil
            CC:GetUI().trackerY = nil
        end
    end):SetPoint("TOPLEFT", panel, "TOPLEFT", 10, yOff)
    yOff = yOff - 32

    do local ln=MakeLine(panel); ln:SetPoint("TOPLEFT",panel,"TOPLEFT",8,yOff); ln:SetPoint("TOPRIGHT",panel,"TOPRIGHT",-8,yOff) end; yOff = yOff - 12

    MakeHeader(panel, "Help"):SetPoint("TOPLEFT", panel, "TOPLEFT", 10, yOff)
    yOff = yOff - 22

    MakeBtn(panel, 150, 24, "Show Tutorial", function()
        CC:ShowTutorial()
    end):SetPoint("TOPLEFT", panel, "TOPLEFT", 10, yOff)
end

-------------------------------------------------------------------------------
-- Info tab
-- this tab is a simple companion bio/about card.
-------------------------------------------------------------------------------
local _infoNameFS, _infoStageFS, _infoPersFS, _infoPersDescFS, _infoAgeFS
local function BuildInfoTab(panel)
    local yOff = -8

    MakeHeader(panel, "Companion Bio"):SetPoint("TOPLEFT", panel, "TOPLEFT", 10, yOff)
    yOff = yOff - 20

    local bioBG = CreateFrame("Frame", nil, panel)
    bioBG:SetPoint("TOPLEFT",  panel, "TOPLEFT",  8, yOff)
    bioBG:SetPoint("TOPRIGHT", panel, "TOPRIGHT", -8, yOff)
    bioBG:SetHeight(120)
    ApplyBackdrop(bioBG, 0.06, 0.08, 0.12, 0.70)

    _infoNameFS = bioBG:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    _infoNameFS:SetPoint("TOPLEFT", bioBG, "TOPLEFT", 10, -10)
    _infoNameFS:SetText("No companion summoned.")

    _infoStageFS = bioBG:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    _infoStageFS:SetPoint("TOPLEFT", _infoNameFS, "BOTTOMLEFT", 0, -6)
    _infoStageFS:SetTextColor(0.65, 0.85, 1.0)
    _infoStageFS:SetText("")

    _infoAgeFS = bioBG:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    _infoAgeFS:SetPoint("TOPLEFT", _infoStageFS, "BOTTOMLEFT", 0, -4)
    _infoAgeFS:SetTextColor(0.60, 0.60, 0.65)
    _infoAgeFS:SetText("")

    _infoPersFS = bioBG:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    _infoPersFS:SetPoint("TOPLEFT", _infoAgeFS, "BOTTOMLEFT", 0, -10)
    _infoPersFS:SetTextColor(0.75, 0.65, 0.90)
    _infoPersFS:SetText("")

    _infoPersDescFS = bioBG:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    _infoPersDescFS:SetPoint("TOPLEFT", _infoPersFS, "BOTTOMLEFT", 0, -4)
    _infoPersDescFS:SetWidth((RIGHT_W - 16) - 20)   -- bioBG inner width minus padding
    _infoPersDescFS:SetJustifyH("LEFT")
    _infoPersDescFS:SetWordWrap(true)
    _infoPersDescFS:SetTextColor(0.60, 0.60, 0.65)
    _infoPersDescFS:SetText("")

    yOff = yOff - 128

    MakeLine(panel):SetPoint("TOPLEFT", panel, "TOPLEFT", 8, yOff)
    MakeLine(panel):SetPoint("TOPRIGHT", panel, "TOPRIGHT", -8, yOff)
    yOff = yOff - 12

    MakeHeader(panel, "About Companion Caddy"):SetPoint("TOPLEFT", panel, "TOPLEFT", 10, yOff)
    yOff = yOff - 18

    local aboutFS = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    aboutFS:SetPoint("TOPLEFT", panel, "TOPLEFT", 10, yOff)
    aboutFS:SetWidth(RIGHT_W - 20)
    aboutFS:SetJustifyH("LEFT")
    aboutFS:SetWordWrap(true)
    aboutFS:SetTextColor(0.60, 0.60, 0.65)
    aboutFS:SetText(string.format(
        "Companion Caddy v%s — care for your companion pets and earn promo rewards. \n"
        .. "Inspired by MurlocMinder (original concept by Kagrok); rebuilt for WoW 3.3.5a.",
        CC.VERSION))
end

-- Refreshes the Companion Bio card (called from CC:RefreshUI)
function CC:UpdateInfoBio()
    if not _infoNameFS then return end
    local pet = self:GetPet()
    local ap  = self.activePet
    local pDef = self:PetPersonality(pet)

    _infoNameFS:SetText(ap and (ap.name or "Companion") or "No companion summoned.")

    if pet then
        _infoStageFS:SetText(pet.stage == "bonding" and "Bonding Stage" or "Companion Stage")
        _infoAgeFS:SetText(string.format("Time together: %.0f min", pet.ageMinutes or 0))
    else
        _infoStageFS:SetText("")
        _infoAgeFS:SetText("")
    end

    if pDef then
        _infoPersFS:SetText(pDef.key)
        _infoPersDescFS:SetText(pDef.desc or "")
    else
        _infoPersFS:SetText("")
        _infoPersDescFS:SetText("")
    end
end

-------------------------------------------------------------------------------
-- Promo tab
-------------------------------------------------------------------------------
local function BuildPromoTab(panel)
    local yOff = -8

    -- Balance header
    local hdrBG = CreateFrame("Frame", nil, panel)
    hdrBG:SetPoint("TOPLEFT",  panel, "TOPLEFT",  0, 0)
    hdrBG:SetPoint("TOPRIGHT", panel, "TOPRIGHT", 0, 0)
    hdrBG:SetHeight(36)
    ApplyBackdrop(hdrBG, 0.06, 0.08, 0.14, 0.90)

    local icon = hdrBG:CreateTexture(nil, "ARTWORK")
    icon:SetSize(22, 22)
    icon:SetPoint("LEFT", hdrBG, "LEFT", 10, 0)
    icon:SetTexture("Interface\\Icons\\inv_misc_coin_18")

    _promoBalFS = hdrBG:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    _promoBalFS:SetPoint("LEFT", icon, "RIGHT", 6, 0)
    _promoBalFS:SetText("Promo Points: --")

    _promoDayFS = hdrBG:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    _promoDayFS:SetPoint("RIGHT", hdrBG, "RIGHT", -10, 0)
    _promoDayFS:SetTextColor(0.65, 0.85, 1.0)
    _promoDayFS:SetText("Today: -- remaining")

    yOff = -40

    -- Unavailable notice (shown when server isn't connected or TCG unavailable)
    local noticeBG = CreateFrame("Frame", nil, panel)
    noticeBG:SetPoint("TOPLEFT",     panel, "TOPLEFT",  8, yOff)
    noticeBG:SetPoint("BOTTOMRIGHT", panel, "BOTTOMRIGHT", -8, 8)
    noticeBG:Hide()
    local noticeFS = noticeBG:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    noticeFS:SetPoint("CENTER")
    noticeFS:SetTextColor(0.55, 0.55, 0.60)
    noticeFS:SetText("Promo shop not available on this server.\nConnect to a server with mod-companion-caddy installed and enabled.")
    noticeFS:SetJustifyH("CENTER")
    panel._noticeBG = noticeBG

    -- Scroll area
    local scrollFrame = CreateFrame("ScrollFrame", nil, panel)
    scrollFrame:SetPoint("TOPLEFT",     panel, "TOPLEFT",  0, yOff)
    scrollFrame:SetPoint("BOTTOMRIGHT", panel, "BOTTOMRIGHT", -16, 28)

    local scrollBar = CreateFrame("Slider", "CompanionCaddyPromoScrollBar", panel, "UIPanelScrollBarTemplate")
    scrollBar:SetPoint("TOPRIGHT",    scrollFrame, "TOPRIGHT",    18, -16)
    scrollBar:SetPoint("BOTTOMRIGHT", scrollFrame, "BOTTOMRIGHT", 18,  16)
    scrollBar:SetMinMaxValues(0, 0)
    scrollBar:SetValueStep(30)
    scrollBar:SetValue(0)
    ShrinkScrollBarArt(scrollBar, "CompanionCaddyPromoScrollBar", 0.75)
    scrollBar:SetScript("OnValueChanged", function(_, v)
        scrollFrame:SetVerticalScroll(v)
    end)
    scrollFrame:EnableMouseWheel(true)
    scrollFrame:SetScript("OnMouseWheel", function(_, d)
        local mn, mx = scrollBar:GetMinMaxValues()
        scrollBar:SetValue(Clamp(scrollBar:GetValue() - d * 60, mn, mx))
    end)

    _promoContent = CreateFrame("Frame", nil, scrollFrame)
    _promoContent:SetWidth(RIGHT_W - 20)
    _promoContent:SetHeight(1)
    scrollFrame:SetScrollChild(_promoContent)
    _promoScrollBar = scrollBar

    -- Refresh button
    MakeBtn(panel, 80, 20, "Refresh", function()
        CC.promoCatalog = {}
        CC:SendToServer("SYNC")
    end):SetPoint("BOTTOMRIGHT", panel, "BOTTOMRIGHT", -4, 4)

    -- Mail-notice popup (shown when code is mailed)
    local mailPopup = CreateFrame("Frame", "CCMailNoticePopup", UIParent)
    mailPopup:SetSize(320, 100)
    mailPopup:SetPoint("CENTER")
    mailPopup:SetFrameStrata("DIALOG")
    ApplyBackdrop(mailPopup, 0.04, 0.04, 0.08, 0.97,  0.45, 0.65, 1.0)
    mailPopup:Hide()
    mailPopup:EnableMouse(true)
    mailPopup:SetMovable(true)
    mailPopup:RegisterForDrag("LeftButton")
    mailPopup:SetScript("OnDragStart", mailPopup.StartMoving)
    mailPopup:SetScript("OnDragStop",  mailPopup.StopMovingOrSizing)

    local mpTitle = mailPopup:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    mpTitle:SetPoint("TOP", mailPopup, "TOP", 0, -14)
    mpTitle:SetText("Your code has been mailed!")

    local mpFS = mailPopup:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    mpFS:SetPoint("TOP", mpTitle, "BOTTOM", 0, -8)
    mpFS:SetWidth(280)
    mpFS:SetJustifyH("CENTER")
    mpFS:SetTextColor(0.65, 0.85, 1.0)
    mpFS:SetText("")
    mailPopup._itemFS = mpFS

    local mpHint = mailPopup:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    mpHint:SetPoint("TOP", mpFS, "BOTTOM", 0, -6)
    mpHint:SetTextColor(0.50, 0.50, 0.55)
    mpHint:SetText("Check your in-game mailbox, then visit the TCG vendor.")

    local mpClose = CreateFrame("Button", nil, mailPopup, "UIPanelCloseButton")
    mpClose:SetPoint("TOPRIGHT", mailPopup, "TOPRIGHT", -4, -4)
    mpClose:SetScript("OnClick", function() mailPopup:Hide() end)

    panel._mailPopup = mailPopup
end

-------------------------------------------------------------------------------
-- Main window assembly
-------------------------------------------------------------------------------
function CC:BuildUI()
    if _win then return end

    _win = CreateFrame("Frame", "CompanionCaddyMainFrame", UIParent)
    _win:SetSize(WIN_W, WIN_H)
    _win:SetPoint("CENTER")
    _win:SetFrameStrata("HIGH")
    _win:SetMovable(true)
    _win:SetClampedToScreen(true)
    _win:EnableMouse(true)
    _win:RegisterForDrag("LeftButton")
    _win:SetScript("OnDragStart", _win.StartMoving)
    _win:SetScript("OnDragStop",  _win.StopMovingOrSizing)
    _win:Hide()

    ApplyBackdrop(_win, 0.04, 0.05, 0.09, CC:GetUI().windowAlpha or 0.95)

    BuildLeftPanel(_win)
    local rp = BuildRightPanel(_win)

    -- Chrome: title + close button, pinned above every content panel
    local chrome = CreateFrame("Frame", nil, _win)
    chrome:SetAllPoints(_win)
    chrome:SetFrameLevel(_win:GetFrameLevel() + 20)

    local titleFS = chrome:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    titleFS:SetPoint("TOP", _win, "TOP", 0, -8)
    titleFS:SetText("Companion Caddy")

    local closeBtn = CreateFrame("Button", nil, chrome, "UIPanelCloseButton")
    closeBtn:SetSize(20, 20)
    closeBtn:SetPoint("TOPRIGHT", _win, "TOPRIGHT", -2, -2)
    closeBtn:SetScript("OnClick", function() CC:HideMainWindow() end)

    BuildHabitatTab(_tabs["Habitat"].panel)
    BuildStoreTab(_tabs["Store"].panel)
    BuildCustomizationTab(_tabs["Customization"].panel)
    BuildInfoTab(_tabs["Info"].panel)
    BuildPromoTab(_tabs["Promo"].panel)

    ShowTab("Habitat")
    _win._rp = rp
end

-------------------------------------------------------------------------------
-- Tracker frame (floating compact care bar strip)
-------------------------------------------------------------------------------
function CC:BuildTracker()
    local t = CreateFrame("Frame", "CompanionCaddyTracker", UIParent)
    t:SetSize(255, 20)
    t:SetFrameStrata("MEDIUM")
    t:SetMovable(true)
    t:SetClampedToScreen(true)
    t:EnableMouse(true)
    t:RegisterForDrag("LeftButton")
    t:SetScript("OnDragStart", t.StartMoving)
    t:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        local x, y = self:GetCenter()
        CC:GetUI().trackerX = x
        CC:GetUI().trackerY = y
    end)

    ApplyBackdrop(t, 0.05, 0.06, 0.10, CC:GetUI().trackerAlpha or 0.88)
    t:SetAlpha(CC:GetUI().trackerAlpha or 0.88)

    -- Restore position if saved
    local ui = CC:GetUI()
    if ui.trackerX and ui.trackerY then
        t:SetPoint("CENTER", UIParent, "BOTTOMLEFT", ui.trackerX, ui.trackerY)
    else
        t:SetPoint("BOTTOM", UIParent, "BOTTOM", 0, 210)
    end

    SetShown(t, ui.showTracker and CC.activePet ~= nil)

    -- Icon
    local icon = t:CreateTexture(nil, "ARTWORK")
    icon:SetSize(14, 14)
    icon:SetPoint("LEFT", t, "LEFT", 4, 0)
    icon:SetTexture("Interface\\Icons\\INV_Box_PetCarrier_01")

    -- Micro bars — clickable: clicking a stat bar performs the matching
    -- care action directly (Feed/Play/Rest/Clean), so players can top off
    -- their companion without opening the full window.
    local bars  = {}
    local statOrder  = { "hunger", "joy", "energy", "cleanliness" }
    local labels     = { hunger="Feed", joy="Play", energy="Rest", cleanliness="Clean" }
    local statAction = { hunger="feed", joy="play", energy="rest", cleanliness="clean" }
    local statVerb   = { hunger="Feed", joy="Play", energy="Rest", cleanliness="Clean" }
    local bW = math.floor((255 - 24) / 4) - 2
    local xOff = 22

    for _, stat in ipairs(statOrder) do
        local bar = CreateFrame("Button", nil, t)
        bar:SetSize(bW, 14)
        bar:SetPoint("LEFT", t, "LEFT", xOff, 0)

        local sbar = CreateFrame("StatusBar", nil, bar)
        sbar:SetAllPoints()
        sbar:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
        sbar:SetStatusBarColor(COL[stat][1], COL[stat][2], COL[stat][3])
        sbar:SetMinMaxValues(0, 100)
        sbar:SetValue(0)

        local lbl = sbar:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        lbl:SetAllPoints()
        lbl:SetJustifyH("CENTER")
        lbl:SetText(labels[stat])

        local action = statAction[stat]
        local verb   = statVerb[stat]
        bar:SetScript("OnClick", function()
            local ok, msg = CC:DoAction(action)
            if not ok then CC:Print(msg) end
        end)
        bar:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_TOP")
            GameTooltip:SetText(verb .. " companion", 1, 1, 1)
            GameTooltip:AddLine("Click to " .. string.lower(verb) .. ".", 0.65, 0.85, 1.0)
            GameTooltip:Show()
        end)
        bar:SetScript("OnLeave", function() GameTooltip:Hide() end)

        AttachCooldownOverlay(bar)
        bar._action = action

        bars[stat] = { button = bar, sbar = sbar }
        xOff = xOff + bW + 2
    end

    -- Bonding-stage bars: 3 equal segments spanning the same total width as
    -- the 4 companion bars above, so the widget doesn't resize when the
    -- companion bonds.
    local bondOrder  = { "soothe", "warm", "clean" }
    local bondLabels = { soothe="Soothe", warm="Warm", clean="Clean" }
    local bondVerb   = { soothe="Soothe", warm="Warm", clean="Clean" }
    local bbW = math.floor((255 - 24) / 3) - 2
    local bondTotalW = bbW * 3 + 2 * 2   -- 3 segments + the 2 gaps between them
    local bxOff = 22

    local bondFill = CreateFrame("StatusBar", nil, t)
    bondFill:SetSize(bondTotalW, 14)
    bondFill:SetPoint("LEFT", t, "LEFT", bxOff, 0)
    bondFill:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
    bondFill:SetStatusBarColor(COL.bonding[1], COL.bonding[2], COL.bonding[3])
    bondFill:SetMinMaxValues(0, 100)
    bondFill:SetValue(0)
    bondFill:Hide()

    local bondBars = {}
    for _, action in ipairs(bondOrder) do
        local bar = CreateFrame("Button", nil, t)
        bar:SetSize(bbW, 14)
        bar:SetPoint("LEFT", t, "LEFT", bxOff, 0)
        bar:SetFrameLevel(bondFill:GetFrameLevel() + 1)

        -- Faint static border only -- no per-segment value/fill; the actual
        -- progress visual is bondFill underneath, showing through this
        -- button's transparent body.
        local border = CreateFrame("Frame", nil, bar)
        border:SetAllPoints()
        ApplyBackdrop(border, 0, 0, 0, 0, 1, 1, 1, 0.18)

        local lbl = bar:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        lbl:SetAllPoints()
        lbl:SetJustifyH("CENTER")
        lbl:SetText(bondLabels[action])

        local verb = bondVerb[action]
        bar:SetScript("OnClick", function()
            local ok, msg = CC:DoAction(action)
            if not ok then CC:Print(msg) end
        end)
        bar:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_TOP")
            GameTooltip:SetText(verb .. " companion", 1, 1, 1)
            GameTooltip:AddLine("Click to " .. string.lower(verb) .. ".", 0.65, 0.85, 1.0)
            GameTooltip:Show()
        end)
        bar:SetScript("OnLeave", function() GameTooltip:Hide() end)

        AttachCooldownOverlay(bar)
        bar._action = action

        bar:Hide()   -- UpdateTracker shows whichever set matches the stage
        bondBars[action] = bar
        bxOff = bxOff + bbW + 2
    end

    t._bars     = bars
    t._bondBars = bondBars
    t._bondFill = bondFill
    self._tracker = t
end

function CC:UpdateActionCooldowns()
    local pet = self:GetPet()
    local isBonding = pet and pet.stage == "bonding"
    local isComp    = pet and pet.stage == "companion"
    if not (isBonding or isComp) then return end

    local habitatPanel = _tabs["Habitat"] and _tabs["Habitat"].panel
    if habitatPanel then
        local set = isBonding and habitatPanel._bondButtons or habitatPanel._careButtons
        for _, btn in ipairs(set or {}) do
            UpdateCooldownOverlay(btn, btn._action)
        end
    end

    if self._tracker then
        if isBonding and self._tracker._bondBars then
            for _, bar in pairs(self._tracker._bondBars) do
                UpdateCooldownOverlay(bar, bar._action)
            end
        elseif isComp and self._tracker._bars then
            for _, bar in pairs(self._tracker._bars) do
                UpdateCooldownOverlay(bar.button, bar.button._action)
            end
        end
    end
end

function CC:UpdateTracker()
    if not self._tracker then return end
    local pet = self:GetPet()
    local ui  = self:GetUI()
    SetShown(self._tracker, ui.showTracker and self.activePet ~= nil)
    if not pet then return end

    local isBonding = (pet.stage == "bonding")

    if self._tracker._bars then
        for stat, bar in pairs(self._tracker._bars) do
            SetShown(bar.button, not isBonding)
            if not isBonding then
                local v = pet[stat] or 0
                bar.sbar:SetValue(v)
                local r = v < 30 and 1 or (v < 60 and 0.85 or COL[stat][1])
                local g = v < 30 and 0.2 or (v < 60 and 0.55 or COL[stat][2])
                bar.sbar:SetStatusBarColor(r, g, COL[stat][3])
            end
        end
    end

    if self._tracker._bondBars then
        local prog = isBonding and (pet.bondProg or 0) or 0
        for _, bar in pairs(self._tracker._bondBars) do
            SetShown(bar, isBonding)
        end
        if self._tracker._bondFill then
            SetShown(self._tracker._bondFill, isBonding)
            self._tracker._bondFill:SetValue(prog)
        end
    end

    self:UpdateActionCooldowns()
end

-------------------------------------------------------------------------------
-- Config panel (Interface > AddOns)
-------------------------------------------------------------------------------
function CC:BuildConfig()
    local cfg = CreateFrame("Frame", "CompanionCaddyConfig", UIParent)
    cfg.name = "Companion Caddy"
    InterfaceOptions_AddCategory(cfg)

    local title = cfg:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
    title:SetPoint("TOPLEFT", 16, -16)
    title:SetText("Companion Caddy  v" .. CC.VERSION)

    local sub = cfg:CreateFontString(nil, "ARTWORK", "GameFontNormalSmall")
    sub:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -4)
    sub:SetTextColor(0.55, 0.55, 0.60)
    sub:SetText("Care for your companion pets and earn promo rewards.")

    local yOff = -80

    local function AddSlider(label, key, low, high, step, parent)
        local ui = CC:GetUI()
        local s = MakeSlider(parent or cfg, label, low, high, step, ui[key] or low,
            function(v)
                CC:GetUI()[key] = v
                if key == "windowAlpha"  and _win     then ApplyBackdropAlpha(_win, v) end
                if key == "modelBgAlpha" and _modelPanel then ApplyBackdropAlpha(_modelPanel, v) end
                if key == "trackerAlpha" and CC._tracker then
                    ApplyBackdropAlpha(CC._tracker, v)
                    CC._tracker:SetAlpha(v)
                end
            end)
        s:SetPoint("TOPLEFT", parent or cfg, "TOPLEFT", 20, yOff)
        yOff = yOff - 42
        return s
    end

    local function AddLabel(text)
        local fs = cfg:CreateFontString(nil, "ARTWORK", "GameFontNormal")
        fs:SetPoint("TOPLEFT", cfg, "TOPLEFT", 16, yOff)
        fs:SetText(text)
        fs:SetTextColor(0.80, 0.85, 1.0)
        yOff = yOff - 22
    end

    AddLabel("Appearance")
    AddSlider("Window Opacity",          "windowAlpha",  0.3, 1.0, 0.05)
    AddSlider("Model Background Opacity","modelBgAlpha", 0.1, 1.0, 0.05)
    AddSlider("Tracker Bar Opacity",     "trackerAlpha", 0.1, 1.0, 0.05)

    yOff = yOff - 10
    AddLabel("Quick Buy Shortcuts")

    -- 3 dropdowns / buttons to choose quick-buy items per slot
    local itemNames = {}
    local itemKeys  = {}
    for _, d in ipairs(CC.STORE_ITEMS) do
        itemNames[#itemNames+1] = d.name
        itemKeys[#itemKeys+1]  = d.key
    end

    for slot = 1, 3 do
        local slotLbl = cfg:CreateFontString(nil, "ARTWORK", "GameFontNormalSmall")
        slotLbl:SetPoint("TOPLEFT", cfg, "TOPLEFT", 16, yOff)
        slotLbl:SetText("Slot " .. slot .. ":")

        local btnW = 160
        local cycleBtn = CreateFrame("Button", nil, cfg, "UIPanelButtonTemplate")
        cycleBtn:SetSize(btnW, 22)
        cycleBtn:SetPoint("TOPLEFT", cfg, "TOPLEFT", 70, yOff + 2)

        local function UpdateCycleBtn()
            local ui  = CC:GetUI()
            local key = ui.quickBuy and ui.quickBuy[slot]
            local name = "—"
            for _, d in ipairs(CC.STORE_ITEMS) do
                if d.key == key then name = d.name; break end
            end
            cycleBtn:SetText(name)
        end
        UpdateCycleBtn()

        local s = slot
        cycleBtn:SetScript("OnClick", function()
            local ui = CC:GetUI()
            ui.quickBuy = ui.quickBuy or {}
            local cur = ui.quickBuy[s]
            local nxt = 1
            for i, k in ipairs(itemKeys) do
                if k == cur then nxt = (i % #itemKeys) + 1; break end
            end
            ui.quickBuy[s] = itemKeys[nxt]
            UpdateCycleBtn()
            CC:UpdateStoreUI()
        end)
        yOff = yOff - 28
    end

    yOff = yOff - 10
    AddLabel("Minimap")

    local chk = CreateFrame("CheckButton", nil, cfg, "UICheckButtonTemplate")
    chk:SetPoint("TOPLEFT", cfg, "TOPLEFT", 16, yOff)
    chk:SetSize(24, 24)
    chk:SetChecked(CC:GetUI().minimapHidden)
    local chkLbl = cfg:CreateFontString(nil, "ARTWORK", "GameFontNormalSmall")
    chkLbl:SetPoint("LEFT", chk, "RIGHT", 4, 0)
    chkLbl:SetText("Hide minimap button")
    chk:SetScript("OnClick", function(self)
        local v = self:GetChecked() and true or false
        CC:GetUI().minimapHidden = v
        local btn = CC.MinimapBtn()
        if btn then if v then btn:Hide() else btn:Show() end end
    end)

    cfg.okay    = function() end
    cfg.cancel  = function() end
    cfg.refresh = function()
        chk:SetChecked(CC:GetUI().minimapHidden)
    end

    self._configPanel = cfg
end

function CC:OpenConfig()
    InterfaceOptionsFrame_OpenToCategory(self._configPanel)
end

-------------------------------------------------------------------------------
-- Show / Hide / Toggle
-------------------------------------------------------------------------------
function CC:ShowMainWindow()
    if not _win then
        local ok, err = pcall(function() self:BuildUI() end)
        if not ok then
            DEFAULT_CHAT_FRAME:AddMessage("|cffff4444CC BuildUI error:|r " .. tostring(err))
            return
        end
    end
    if not self._tracker then
        pcall(function() self:BuildTracker() end)
    end
    if _win then
        _win:Show()
        local ok, err = pcall(function() self:RefreshUI() end)
        if not ok then
            DEFAULT_CHAT_FRAME:AddMessage("|cffff4444CC RefreshUI error:|r " .. tostring(err))
        end

        if not self._hasSyncedOnce then
            self._hasSyncedOnce = true
            self.promoCatalog = {}
            self:SendToServer("SYNC")
            self:RequestStateFromServer()
        end
    end
end

function CC:HideMainWindow()
    if _win then _win:Hide() end
end

function CC:ToggleMainWindow()
    if _win and _win:IsShown() then
        self:HideMainWindow()
    else
        self:ShowMainWindow()
    end
end

-------------------------------------------------------------------------------
-- Model management
-------------------------------------------------------------------------------
function CC:ClearModel()
    if not _model then return end
    pcall(_model.ClearModel, _model)
    _model:Hide()
    _bondSpinAngle  = 0
    _modelFrameMult = 1.0
    if _modelPanel and _modelPanel.noCompLabel then
        _modelPanel.noCompLabel:Show()
    end
end

function CC:LoadModel()
    if not _model or not self.activePet then return end
    local ap  = self.activePet
    local def = CC.MODEL_SIZES[ap.creatureID] or CC.MODEL_SIZES.default

    -- Reset zoom when loading a new companion
    _modelFrameMult = 1.0
    _model:SetSize(def.w, def.h)

    pcall(_model.SetCreature, _model, ap.creatureID)

    _model._needsTransform = true
    _model:Show()

    if _modelPanel and _modelPanel.noCompLabel then
        _modelPanel.noCompLabel:Hide()
    end
end

-------------------------------------------------------------------------------
-- RefreshUI
-------------------------------------------------------------------------------
function CC:RefreshUI()
    if not _win or not _win:IsShown() then return end
    local pet  = self:GetPet()
    local eco  = self:GetEconomy()
    local ap   = self.activePet

    -- Left panel: pet identity
    if _petNameFS then
        _petNameFS:SetText(ap and (ap.name or "Companion") or "No companion summoned.")
        _petNameFS:SetTextColor(ap and 1 or 0.55, ap and 0.82 or 0.55, ap and 0.1 or 0.55)
    end
    if _petStageFS then
        if pet then
            _petStageFS:SetText(pet.stage == "bonding" and "Bonding Stage" or
                string.format("Companion  •  %.0f min", pet.ageMinutes or 0))
        else
            _petStageFS:SetText("")
        end
    end
    if _petPersFS then
        _petPersFS:SetText(pet and (pet.personality or "") or "")
    end
    if _petCareStatusFS then
        if not pet or pet.stage ~= "companion" then
            _petCareStatusFS:SetText("")
        elseif pet.neglectSince then
            _petCareStatusFS:SetText("|cffff4444Neglected! Care to zero soon.|r")
        else
            local tier = CC:GetCareTier(pet)
            local col  = tier.color or {1, 1, 1}
            local text = tier.label
            local mult = pet.streakMult or 0
            if mult > 0 then
                text = text .. string.format("  •  Combo +%.0f%%", mult * 100)
            end
            _petCareStatusFS:SetTextColor(col[1], col[2], col[3])
            _petCareStatusFS:SetText(text)
        end
    end

    -- Model: load if not loaded yet
    if ap then
        if not _model:IsShown() then self:LoadModel() end
    else
        self:ClearModel()
    end

    -- Disable main window interaction when no pet
    local alpha = ap and 1.0 or 0.30
    -- We leave the alpha at full; instead dim individual content
    if _bondBar then _bondBar:SetValue(pet and pet.bondProg or 0) end
    for stat, bar in pairs(_careBars) do
        bar:Update(pet and pet[stat] or 0)
    end

    -- Show/hide bonding vs companion content
    local isBonding = (pet and pet.stage == "bonding")
    local isComp    = pet and not isBonding and ap ~= nil
    if _bondBar then
        SetShown(_bondBar, isBonding)
        SetShown(_bondBar._bg, isBonding)
    end
    for _, bar in pairs(_careBars) do
        SetShown(bar, isComp)
        SetShown(bar._bg, isComp)
    end

    local habitatPanel = _tabs["Habitat"] and _tabs["Habitat"].panel
    if habitatPanel then
        if habitatPanel._bondHdr then SetShown(habitatPanel._bondHdr, isBonding) end
        if habitatPanel._careHdr then SetShown(habitatPanel._careHdr, isComp) end
        for _, btn in ipairs(habitatPanel._bondButtons or {}) do SetShown(btn, isBonding) end
        for _, btn in ipairs(habitatPanel._careButtons or {}) do SetShown(btn, isComp) end
        if habitatPanel._scavHdr then SetShown(habitatPanel._scavHdr, isComp) end
    end

    self:UpdateActionCooldowns()


    do
        local store = self:GetStore()
        local inv   = store and store.inventory or {}
        for key, row in pairs(_careItemRows) do
            local n = inv[key] or 0
            if row._invFS  then row._invFS:SetText(tostring(n)) end
            if row._useBtn then
                if n > 0 and isComp then row._useBtn:Enable() else row._useBtn:Disable() end
            end
        end
    end

    -- Treats balance shown next to the Quick Buy header in the left panel.
    if _leftTreatsFS then
        local eco = self:GetEconomy()
        _leftTreatsFS:SetText(string.format("(|cffffd700%d|r Treats)", eco and eco.treats or 0))
    end

    -- Scavenge display
    if eco then
        self:UpdateScavengeStack()
        self:UpdateScavengeDetail()

        -- Store: treat balance
        self:UpdateStoreUI()
    end

    -- Challenges
    self:UpdateChallengesUI()

    -- Info tab bio card
    self:UpdateInfoBio()

    -- Promo tab
    if _promoBalFS then self:RefreshPromoUI() end

    -- Tracker
    self:UpdateTracker()
end

local function CreateScavRow(parent)
    local row = CreateFrame("Frame", nil, parent)
    row:SetHeight(SCAV_ROW_H)

    local bar = CreateFrame("StatusBar", nil, row)
    bar:SetAllPoints()
    bar:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
    bar:SetStatusBarColor(0.65, 0.85, 0.35)
    bar:SetMinMaxValues(0, 1)
    bar:SetValue(0)
    row._bar = bar

    local icon = bar:CreateTexture(nil, "OVERLAY")
    icon:SetSize(SCAV_ROW_H, SCAV_ROW_H)
    icon:SetPoint("LEFT", row, "LEFT", 1, 0)
    row._icon = icon

    local txt = bar:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    txt:SetPoint("LEFT",  row, "LEFT",  SCAV_ROW_H + 2, 0)
    txt:SetPoint("RIGHT", row, "RIGHT", -2, 0)
    txt:SetJustifyH("LEFT")
    row._txt = txt

    row:EnableMouse(true)
    row:SetScript("OnEnter", function(self_)
        if not row._scavKey then return end
        local scavs = CC:GetScavenges()
        local scav  = scavs and scavs[row._scavKey]
        if not scav then return end
        GameTooltip:SetOwner(self_, "ANCHOR_CURSOR")
        GameTooltip:SetText(scav.petName or "Companion", 1, 1, 1)
        GameTooltip:AddDoubleLine("Duration", scav.label or "?", 1,1,1, 0.7,0.7,0.7)
        GameTooltip:AddDoubleLine("Reward", (scav.min or 0) .. "–" .. (scav.max or 0) .. " treats", 1,1,1, 1.0,0.82,0.1)
        if scav.careTierLabel then
            GameTooltip:AddDoubleLine("Care when it left", scav.careTierLabel, 1,1,1, 0.7,0.85,1.0)
        end
        GameTooltip:Show()
    end)
    row:SetScript("OnLeave", function() GameTooltip:Hide() end)

    row:Hide()
    return row
end

function CC:UpdateScavengeStack()
    if not _scavStackRows then return end
    local scavs = self:GetScavenges()
    local pd    = self:GetPlayerData()

    local active = {}
    if scavs then
        for key, s in pairs(scavs) do
            if s.active then active[#active + 1] = { key = key, scav = s } end
        end
    end

    table.sort(active, function(a, b) return (a.scav.start or 0) > (b.scav.start or 0) end)
    local newTopKey = active[1] and active[1].key

    while #_scavStackRows < #active do
        local i = #_scavStackRows + 1
        local row = CreateScavRow(_scavStack)
        row:SetPoint("TOPLEFT",  _scavStack, "TOPLEFT",  0, -(i-1) * SCAV_ROW_H)
        row:SetPoint("TOPRIGHT", _scavStack, "TOPRIGHT", 0, -(i-1) * SCAV_ROW_H)
        _scavStackRows[i] = row
    end

    for i, row in ipairs(_scavStackRows) do
        local entry = active[i]
        if entry then
            local scav = entry.scav
            local elapsed = time() - scav.start
            local left    = math.max(0, scav.sec - elapsed)
            local pct     = Clamp(elapsed / scav.sec, 0, 1)
            row._bar:SetValue(pct)
            local m, s = math.floor(left / 60), left % 60
            local name = scav.petName or (pd and pd.companions[entry.key] and pd.companions[entry.key].name) or "Companion"
            row._txt:SetText(string.format("%s  %d:%02d", name, m, s))
            if scav.petIcon then row._icon:SetTexture(scav.petIcon) end
            row._scavKey = entry.key
            row:Show()
        else
            row._scavKey = nil
            row:Hide()
        end
    end

    local contentH = #active * SCAV_ROW_H
    if _scavStack then _scavStack:SetHeight(math.max(contentH, 1)) end

    if _scavScrollFrame and _scavScrollBar then
        local viewH     = _scavScrollFrame:GetHeight()
        local maxScroll = math.max(0, contentH - viewH)
        _scavScrollBar:SetMinMaxValues(0, maxScroll)

        if newTopKey ~= _scavTopKey then
            _scavTopKey = newTopKey
            _scavScrollPos = maxScroll
            _scavScrollBar:SetValue(maxScroll)
        end

        if maxScroll <= 0 then
            _scavScrollPos = 0
            _scavScrollBar:SetValue(0)
            _scavScrollBar:Hide()
        else
            _scavScrollPos = Clamp(_scavScrollPos, 0, maxScroll)
            _scavScrollBar:SetValue(_scavScrollPos)
            _scavScrollBar:Show()
        end
    end
end

function CC:UpdateScavengeDetail()
    if not _scavDetailFS then return end
    local pet  = self:GetPet()
    local pDef = self:PetPersonality(pet)
    local mult = ((pDef and pDef.scavengeBonus) and 1.20 or 1.0) * self:GetTreatMultiplier(pet)
    local key  = self.activePet and tostring(self.activePet.spellID)
    local isActiveScavenging = self:IsScavenging(key)

    if not self.activePet then
        _scavDetailFS:SetText("Summon a bonded companion to send it scavenging.")
    elseif isActiveScavenging then
        local scavs = self:GetScavenges()
        local scav  = scavs and scavs[key]
        local lo, hi = math.floor((scav and scav.min or 0) * mult), math.floor((scav and scav.max or 0) * mult)
        local startClock = scav and date("%H:%M", scav.start) or "?"
        local careTxt = (scav and scav.careTierLabel) and ("  •  " .. scav.careTierLabel .. " care when it left") or ""
        _scavDetailFS:SetText(string.format(
            "This companion is out scavenging (since %s, expecting %d–%d treats%s). "
            .. "Summon a different one to keep earning Treats directly.", startClock, lo, hi, careTxt))
    else
        local bonusTxt = ""
        if pDef and pDef.scavengeBonus then
            bonusTxt = string.format("  (+%.0f%% %s bonus already applied)", (pDef.bonus or 0) * 100, pDef.key)
        end
        local tier = self:GetCareTier(pet)
        _scavDetailFS:SetText(string.format(
            "Pick a duration above to send your companion out —\ncurrently |cff%02x%02x%02x%s|r care.%s",
            math.floor((tier.color and tier.color[1] or 1) * 255),
            math.floor((tier.color and tier.color[2] or 1) * 255),
            math.floor((tier.color and tier.color[3] or 1) * 255),
            tier.label, bonusTxt))
    end

    if _scavBtns then
        local canSend = pet and pet.stage == "companion" and not isActiveScavenging
        for _, b in ipairs(_scavBtns) do
            if canSend then b:Enable() else b:Disable() end
        end
    end
end

function CC:UpdateStoreUI()
    local eco   = self:GetEconomy()
    local store = self:GetStore()
    local ui    = self:GetUI()

    if _tabs["Store"] and _tabs["Store"].panel._treatFS then
        _tabs["Store"].panel._treatFS:SetText(string.format("Treats: |cffffd700%d|r", eco and eco.treats or 0))
    end

    local treats = eco and eco.treats or 0
    for i, btn in ipairs(_quickBuyBtns) do
        local key = ui.quickBuy and ui.quickBuy[i]
        local name, cost = "—", nil
        if key then
            for _, d in ipairs(CC.STORE_ITEMS) do
                if d.key == key then name = d.name; cost = d.cost; break end
            end
        end
        btn:SetText(cost and string.format("%s (%d tr)", name, cost) or name)
        if key and cost and treats >= cost then btn:Enable() else btn:Disable() end
    end

    for key, row in pairs(_storeRows) do
        local inv = (store and store.inventory and store.inventory[key]) or 0
        if row._invFS then row._invFS:SetText("×" .. inv) end
    end
end

function CC:UpdateChallengesUI()
    if _activeTab ~= "Habitat" then return end
    local eco = self:GetEconomy()
    local chs = eco and eco.challenges or {}

    for i = 1, 4 do
        local row = _challengeRows[i]
        local ch  = chs[i]
        if row then
            if ch then
                row._lbl:SetText(ch.label)
                local pct = ch.goal > 0 and (ch.progress / ch.goal) or 0
                row._bar:SetValue(pct)
                row._bar:SetStatusBarColor(0.35, 0.60, 0.90, 0.35 + pct * 0.35)
                row._prog:SetText(string.format("%d/%d", ch.progress, ch.goal))
                row._hint   = ch.hint
                row._label  = ch.label
                row._reward = ch.reward
            else
                row._lbl:SetText("|cff555555No challenge|r")
                row._bar:SetValue(0)
                row._prog:SetText("")
                row._hint, row._label, row._reward = nil, nil, nil
            end
        end
    end
end

function CC:UpdateLog()
    if not _logFrame then return end
    _logFrame:Clear()
    local log = self:GetLog()
    for i = #log, 1, -1 do
        _logFrame:AddMessage(log[i].text, 0.75, 0.80, 0.90)
    end
    _logFrame:ScrollToBottom()
end

-------------------------------------------------------------------------------
-- Promo tab functions
-------------------------------------------------------------------------------
function CC:RefreshPromoUI()
    if not _promoBalFS then return end
    _promoBalFS:SetText(string.format("Promo Points: |cffffd700%d|r", self.promoBalance or 0))
    if _promoDayFS then
        if not self.promoEnabled then
            _promoDayFS:SetText("|cff888888Promo points are disabled on this server.|r")
        elseif (self.promoDailyLeft or 0) < 0 then
            _promoDayFS:SetText("Today: |cff7ec8e3Unlimited|r remaining")
        else
            _promoDayFS:SetText(string.format("Today: |cff7ec8e3%d|r remaining", self.promoDailyLeft or 0))
        end
    end

    local hasItems = #(self.promoCatalog or {}) > 0
    local promoPanel = _tabs["Promo"] and _tabs["Promo"].panel
    if promoPanel and promoPanel._noticeBG then
        SetShown(promoPanel._noticeBG, not self.promoEnabled or not self.promoTcgReady or not hasItems)
    end

    self:UpdatePromoButtonStates()
end

function CC:UpdatePromoButtonStates()
    for _, row in ipairs(self._promoRows or {}) do
        if row.btn and row.cost then
            if (self.promoBalance or 0) < row.cost or not self.promoTcgReady or not self.promoEnabled then
                row.btn:Disable()
            else
                row.btn:Enable()
            end
        end
    end
end

function CC:ShowPromoTooltip(anchor, item)
    if not item or not item.itemEntry or item.itemEntry == 0 then
        GameTooltip:SetOwner(anchor, "ANCHOR_CURSOR")
        GameTooltip:SetText(item and (item.displayName or item.rewardGroup) or "Unknown reward")
        GameTooltip:Show()
        return
    end

    if item.factionSplit and item.itemEntryAlt and item.itemEntryAlt ~= 0 then
        local isAlliance = (UnitFactionGroup and UnitFactionGroup("player") == "Alliance")
        local ownEntry   = isAlliance and item.itemEntry or item.itemEntryAlt
        local otherEntry = isAlliance and item.itemEntryAlt or item.itemEntry
        local otherFaction = isAlliance and "Horde" or "Alliance"

        GameTooltip:SetOwner(anchor, "ANCHOR_CURSOR")
        GameTooltip:SetHyperlink("item:" .. ownEntry)
        GameTooltip:AddLine(" ")
        GameTooltip:AddLine("|cff7ec8e3This reward is faction-specific.|r", 1, 1, 1)
        local otherName = GetItemInfo(otherEntry)
        GameTooltip:AddLine(string.format(
            "%s players receive: %s", otherFaction, otherName or ("item #" .. otherEntry)),
            0.7, 0.7, 0.7)
        GameTooltip:Show()
        return
    end

    GameTooltip:SetOwner(anchor, "ANCHOR_CURSOR")
    GameTooltip:SetHyperlink("item:" .. item.itemEntry)
    if item.itemEntryAlt and item.itemEntryAlt ~= 0 then
        GameTooltip:AddLine(" ")
        GameTooltip:AddLine("|cff7ec8e3Ships with BOTH appearances.|r", 1, 1, 1)
    end
    GameTooltip:Show()
end

function CC:RebuildPromoShop()
    if not _promoContent then return end

    local children = { _promoContent:GetChildren() }
    for _, c in ipairs(children) do c:Hide(); c:SetParent(nil) end

    self._promoRows = {}   -- {btn=, cost=} per row -- see UpdatePromoButtonStates()

    local yOff   = 0
    local curCat = nil
    local rowH   = 32

    for _, item in ipairs(self.promoCatalog or {}) do
        if item.category ~= curCat then
            curCat = item.category
            local hdr = _promoContent:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            hdr:SetPoint("TOPLEFT", _promoContent, "TOPLEFT", 4, yOff - 4)
            hdr:SetText("|cff7ec8e3" .. (curCat or "Other") .. "|r")
            yOff = yOff - 18
        end

        local row = CreateFrame("Frame", nil, _promoContent)
        row:SetPoint("TOPLEFT",  _promoContent, "TOPLEFT", 2, yOff)
        row:SetPoint("TOPRIGHT", _promoContent, "TOPRIGHT", -2, yOff)
        row:SetHeight(rowH)
        ApplyBackdrop(row, 0.06, 0.08, 0.12, 0.60)
        row:EnableMouse(true)
        row:SetScript("OnEnter", function(self_) CC:ShowPromoTooltip(self_, item) end)
        row:SetScript("OnLeave", function() GameTooltip:Hide() end)

        local icon = row:CreateTexture(nil, "ARTWORK")
        icon:SetSize(24, 24)
        icon:SetPoint("LEFT", row, "LEFT", 4, 0)
        icon:SetTexture(CC:GetPromoIcon(item.rewardGroup, item.category))
        icon:SetTexCoord(0, 1, 0, 1)  -- crop the icon's default border

        local nameFS = row:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        nameFS:SetPoint("LEFT", icon, "RIGHT", 6, 0)
        nameFS:SetPoint("RIGHT", row, "RIGHT", -120, 0)
        nameFS:SetJustifyH("LEFT")
        nameFS:SetText(item.displayName or item.rewardGroup)

        local costFS = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        costFS:SetPoint("RIGHT", row, "RIGHT", -68, 0)
        costFS:SetTextColor(1.0, 0.82, 0.1)
        costFS:SetText(item.pointCost .. " pts")

        local rg   = item.rewardGroup
        local cost = item.pointCost
        local dn   = item.displayName or rg
        local btn  = MakeBtn(row, 60, 20, "Redeem", function()
            CC:ConfirmPromoPurchase(rg, dn, cost)
        end)
        btn:SetPoint("RIGHT", row, "RIGHT", -4, 0)
        table.insert(self._promoRows, { btn = btn, cost = cost })

        yOff = yOff - rowH - 2
    end

    _promoContent:SetHeight(math.abs(yOff) + 8)
    local visH = 0
    local promoPanel = _tabs["Promo"] and _tabs["Promo"].panel
    if promoPanel then visH = promoPanel:GetHeight() - 80 end
    local maxScroll = math.max(0, math.abs(yOff) - visH)
    _promoScrollBar:SetMinMaxValues(0, maxScroll)
    _promoScrollBar:SetValue(0)

    self:RefreshPromoUI()
end

function CC:ConfirmPromoPurchase(rg, displayName, cost)
    StaticPopupDialogs["CC_PROMO_CONFIRM"] = {
        text        = string.format("Purchase |cffffd700%s|r for |cffffff00%d Promo Points|r?", displayName, cost),
        button1     = "Purchase",
        button2     = "Cancel",
        OnAccept    = function() CC:SendToServer("PURCHASE|" .. rg) end,
        timeout     = 0,
        whileDead   = false,
        hideOnEscape = true,
    }
    StaticPopup_Show("CC_PROMO_CONFIRM")
end

function CC:ShowMailNotice(displayName)
    local promoPanel = _tabs["Promo"] and _tabs["Promo"].panel
    if not promoPanel or not promoPanel._mailPopup then return end
    local popup = promoPanel._mailPopup
    if popup._itemFS then
        popup._itemFS:SetText(displayName or "")
    end
    popup:Show()
end

local function CreatePopupItemRow(parent)
    local row = CreateFrame("Frame", nil, parent)
    row:SetHeight(POPUP_ROW_H)
    row._itemEntry = 0

    local icon = row:CreateTexture(nil, "ARTWORK")
    icon:SetSize(20, 20)
    icon:SetPoint("LEFT", row, "LEFT", 2, 0)
    icon:SetTexCoord(0, 1, 0, 1)   -- crop the icon's default border
    row._icon = icon

    local name = row:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    name:SetPoint("TOPLEFT",  icon, "TOPRIGHT", 6, -2)
    name:SetPoint("TOPRIGHT", row,  "RIGHT",   -2, -2)
    name:SetJustifyH("LEFT")
    row._nameFS = name

    local hint = row:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    hint:SetPoint("TOPLEFT", name, "BOTTOMLEFT", 0, -2)
    hint:SetJustifyH("LEFT")
    row._hintFS = hint

    row:EnableMouse(true)
    row:SetScript("OnEnter", function(self_)
        if not row._itemEntry or row._itemEntry == 0 then return end

        GameTooltip:SetOwner(self_, "ANCHOR_CURSOR")
        GameTooltip:SetHyperlink("item:" .. row._itemEntry)
        GameTooltip:Show()
    end)
    row:SetScript("OnLeave", function() GameTooltip:Hide() end)

    row:Hide()
    return row
end

function CC:RefreshScavengePopupRow(row, itemEntry)
    local name, _, quality, _, _, _, _, _, _, texture = GetItemInfo(itemEntry)

    row._nameFS:SetText(name or ("Item #" .. tostring(itemEntry)))
    if quality and GetItemQualityColor then
        local r, g, b = GetItemQualityColor(quality)
        row._nameFS:SetTextColor(r, g, b)
    else
        row._nameFS:SetTextColor(1, 1, 1)
    end

    local icon = texture or CC.ITEM_ICON_OVERRIDES[itemEntry]
    row._icon:SetTexture(icon or "Interface\\Icons\\INV_Misc_QuestionMark")

    return name ~= nil
end

function CC:RefreshScavengePopupList(popup)
    local items = popup._items

    while #popup._rows < #items do
        local i = #popup._rows + 1
        local row = CreatePopupItemRow(popup._listStack)
        row:SetPoint("TOPLEFT",  popup._listStack, "TOPLEFT",  0, -(i-1) * POPUP_ROW_H)
        row:SetPoint("TOPRIGHT", popup._listStack, "TOPRIGHT", 0, -(i-1) * POPUP_ROW_H)
        popup._rows[i] = row
    end

    for i, row in ipairs(popup._rows) do
        local it = items[i]
        if it then
            row._itemEntry = it.entry
            row._hintFS:SetText(it.mailed and "Mailed (bags were full)" or "Placed in bags")
            row:Show()

            local haveData = self:RefreshScavengePopupRow(row, it.entry)
            if not haveData then
                row._retryFrame = row._retryFrame or CreateFrame("Frame")
                local f = row._retryFrame
                f._elapsed   = 0
                f._ticksLeft = 10   -- ~5 seconds at 0.5s/tick
                f:SetScript("OnUpdate", function(self_, elapsed)
                    self_._elapsed = self_._elapsed + elapsed
                    if self_._elapsed < 0.5 then return end
                    self_._elapsed = 0
                    self_._ticksLeft = self_._ticksLeft - 1

                    if not row:IsShown() or row._itemEntry ~= it.entry then
                        self_:SetScript("OnUpdate", nil)
                        return
                    end

                    if CC:RefreshScavengePopupRow(row, it.entry) or self_._ticksLeft <= 0 then
                        self_:SetScript("OnUpdate", nil)
                    end
                end)
            end
        else
            row._itemEntry = nil
            row:Hide()
        end
    end

    local contentH = #items * POPUP_ROW_H
    popup._listStack:SetHeight(math.max(contentH, 1))

    local viewH     = popup._listFrame:GetHeight()
    local maxScroll = math.max(0, contentH - viewH)
    popup._listBar:SetMinMaxValues(0, maxScroll)

    popup._scrollPos = 0
    if maxScroll <= 0 then
        popup._listBar:SetValue(0)
        popup._listBar:Hide()
    else
        popup._listBar:SetValue(0)
        popup._listBar:Show()
    end
end

function CC:ShowScavengeItemNotice(itemEntry, mailed)
    local habitatPanel = _tabs["Habitat"] and _tabs["Habitat"].panel
    if not habitatPanel or not habitatPanel._scavengeItemPopup then return end
    local popup = habitatPanel._scavengeItemPopup

    table.insert(popup._items, 1, { entry = itemEntry, mailed = mailed })
    self:RefreshScavengePopupList(popup)
    popup:Show()
end

-------------------------------------------------------------------------------
-- First-launch tutorial
-------------------------------------------------------------------------------
local _tutFrame
local _tutTitleFS, _tutBodyFS, _tutStepFS
local _tutBackBtn, _tutNextBtn
local _tutDots = {}
local _tutIndex = 1

local _tutSteps = {
    { title = "Welcome to Companion Caddy!",
      body  = "Companion Caddy turns any summoned companion pet into an ongoing little companion you actually take care of. Feed it, play with it, keep it clean and rested -- and get rewarded for the attention with Treats, and on some servers, Promo Points too.\n\nThis walkthrough covers everything, step by step. Revisit it anytime from Customization -> Show Tutorial, or by typing /cc tutorial." },
    { title = "Getting a Companion", tab = "Habitat",
      body  = "Companion Caddy doesn't summon anything on its own -- just call out any companion pet you already own the normal way, from your Pets & Mounts panel. Whichever one is currently out is the one Companion Caddy tracks.\n\nSummon a companion now if you'd like to follow along on the Habitat tab as we go." },
    { title = "Bonding Stage", tab = "Habitat",
      body  = "A freshly summoned companion starts out Bonding with you -- a Bonding Progress bar takes the place of the usual Needs bars at the top of the Habitat tab. Three Bonding Actions are available while bonding: Soothe, Warm, and Clean. Use them regularly, and once the bond completes your companion graduates to full Companion status." },
    { title = "Needs & Care Actions", tab = "Habitat",
      body  = "Once bonded, four Needs bars take over -- Hunger, Joy, Energy, and Cleanliness -- each slowly drifting down over time. Feed, Play, Rest, and Clean are free Care Actions (on a short cooldown) that top them back up. Keeping Needs high is where the good rewards come from.\n\nA Care Status line above shows your companion's overall standing at a glance -- Struggling, Okay, Good, or Thriving -- based on both the average of all four bars AND the single lowest one, so three full bars can't hide one neglected bar." },
    { title = "Treat Combo & Neglect", tab = "Habitat",
      body  = "Keep a companion Thriving for a while and a Treat combo builds, boosting every Treats reward it earns -- Care Actions, Challenges, even Scavenging. Slipping out of Thriving only costs a little of that combo, not all of it, so one bad hour won't erase a good week. Thriving and Good companions also have a small chance of a spontaneous event -- a free Care Item, just for keeping up the good work.\n\nThe flip side: if every single Need bar bottoms out at zero, your companion needs to fully re-bond with you. You'll get a clear warning first, and topping off even one bar cancels it -- but the longer it's ignored after that warning, the longer re-bonding takes next time (up to 5x)." },
    { title = "Care Items & Quick Buy", tab = "Habitat",
      body  = "Below the model on the left, Care Items lists everything you own for your companion -- the number on the left is how many you have, and Use lights up once you own at least one. Quick Buy just underneath is three configurable one-click restock buttons, so your favorite items are always a click away without leaving this screen." },
    { title = "Scavenging", tab = "Habitat",
      body  = "Send your companion off to scavenge for 30 minutes, an hour, or two, for guaranteed Treats plus a chance at a bonus item when it returns. Its progress shows right on the Habitat tab while it's away -- it'll still want feeding and attention once it's back.\n\nHow well cared-for it is when it leaves matters: a Thriving companion has noticeably better bonus-item odds than a Struggling one, on top of everything else Care Status affects. While it's out, that companion is locked: summoning it early just gets it sent straight back, whether you try from the Pet Journal, a macro, or anything else. Every other companion you own is completely unaffected and stays summonable exactly as before." },
    { title = "Challenges & the Activity Log", tab = "Habitat",
      body  = "Active Challenges appear automatically and reward Treats for completing them -- plus Promo Points too, on servers running the matching server module. Hover a challenge row for a hint on how to finish it. Everything that happens gets recorded in the Activity Log underneath, so there's always a history to scroll back through." },
    { title = "The Store", tab = "Store",
      body  = "Spend the Treats you've earned here. Each item shows what it restores and its cost -- the small ×N next to Buy is how many you already own. Anything purchased here shows up on the Habitat tab's Care Items list, ready to use." },
    { title = "Promo Points", tab = "Promo",
      body  = "On a server running the Companion Caddy server module, Challenges also earn Promo Points, spendable here in a rotating catalog -- purchases get mailed to you in-game. If this server isn't running that module, you'll just see a friendly notice instead of an error; everything else works exactly the same either way." },
    { title = "Customization & the Tracker", tab = "Customization",
      body  = "Adjust how see-through the main window, model background, and floating Tracker bar are -- each slider genuinely reaches fully opaque at 100%. The Tracker is a small draggable bar that keeps your companion's Needs visible even with this window closed; toggle it or reset its position from here too, along with the model camera." },
    { title = "You're All Set!",
      body  = "Open Companion Caddy anytime from the minimap button or by typing /cc -- /cc config jumps straight to these settings, and /cc tutorial brings this walkthrough back whenever you want a refresher.\n\nNow go take care of your companions!" },
}

local function BuildTutorial()
    local f = CreateFrame("Frame", nil, UIParent)
    f:SetSize(440, 320)
    f:SetPoint("TOPRIGHT", UIParent, "CENTER", -(WIN_W / 2) - 24, WIN_H / 2)
    f:SetClampedToScreen(true)
    f:SetFrameStrata("DIALOG")
    ApplyBackdrop(f, 0.04, 0.05, 0.09, 0.97, 0.45, 0.65, 1.0)
    f:EnableMouse(true)
    f:SetMovable(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", f.StartMoving)
    f:SetScript("OnDragStop", f.StopMovingOrSizing)
    f:Hide()

    local closeBtn = CreateFrame("Button", nil, f, "UIPanelCloseButton")
    closeBtn:SetPoint("TOPRIGHT", f, "TOPRIGHT", -2, -2)
    closeBtn:SetScript("OnClick", function() CC:FinishTutorial() end)

    _tutTitleFS = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    _tutTitleFS:SetPoint("TOP", f, "TOP", 0, -16)
    _tutTitleFS:SetWidth(380)
    _tutTitleFS:SetJustifyH("CENTER")

    local rule = MakeLine(f)
    rule:SetPoint("TOP", _tutTitleFS, "BOTTOM", 0, -8)
    rule:SetWidth(380)

    _tutBodyFS = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    _tutBodyFS:SetPoint("TOP", rule, "BOTTOM", 0, -14)
    _tutBodyFS:SetWidth(392)
    _tutBodyFS:SetJustifyH("LEFT")
    _tutBodyFS:SetWordWrap(true)
    _tutBodyFS:SetSpacing(3)

    -- Step dots
    local dotsWrap = CreateFrame("Frame", nil, f)
    dotsWrap:SetPoint("BOTTOM", f, "BOTTOM", 0, 46)
    dotsWrap:SetSize(#_tutSteps * 14, 10)
    for i = 1, #_tutSteps do
        local dot = dotsWrap:CreateTexture(nil, "ARTWORK")
        dot:SetTexture("Interface\\BUTTONS\\WHITE8X8")
        dot:SetSize(6, 6)
        dot:SetPoint("LEFT", dotsWrap, "LEFT", (i - 1) * 14, 0)
        _tutDots[i] = dot
    end

    _tutStepFS = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    _tutStepFS:SetPoint("BOTTOM", f, "BOTTOM", 0, 58)
    _tutStepFS:SetTextColor(0.55, 0.55, 0.60)

    _tutBackBtn = MakeBtn(f, 80, 22, "Back", function()
        if _tutIndex > 1 then
            _tutIndex = _tutIndex - 1
            CC:RenderTutorialStep()
        end
    end)
    _tutBackBtn:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", 16, 14)

    local skipBtn = MakeBtn(f, 80, 22, "Skip", function() CC:FinishTutorial() end)
    skipBtn:SetPoint("BOTTOM", f, "BOTTOM", 0, 14)

    _tutNextBtn = MakeBtn(f, 80, 22, "Next", function()
        if _tutIndex < #_tutSteps then
            _tutIndex = _tutIndex + 1
            CC:RenderTutorialStep()
        else
            CC:FinishTutorial()
        end
    end)
    _tutNextBtn:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -16, 14)

    _tutFrame = f
end

function CC:RenderTutorialStep()
    if not _tutFrame then return end
    local step = _tutSteps[_tutIndex]
    if not step then return end

    _tutTitleFS:SetText(step.title)
    _tutBodyFS:SetText(step.body)
    _tutStepFS:SetText(string.format("Step %d of %d", _tutIndex, #_tutSteps))

    for i, dot in ipairs(_tutDots) do
        if i == _tutIndex then
            dot:SetVertexColor(1.0, 0.82, 0.1, 1.0)
        elseif i < _tutIndex then
            dot:SetVertexColor(0.55, 0.75, 1.0, 0.8)
        else
            dot:SetVertexColor(0.35, 0.35, 0.40, 0.8)
        end
    end

    if _tutIndex <= 1 then _tutBackBtn:Disable() else _tutBackBtn:Enable() end
    _tutNextBtn:SetText(_tutIndex >= #_tutSteps and "Finish" or "Next")

    if step.tab then
        CC:ShowMainWindow()
        ShowTab(step.tab)
    end
end

function CC:ShowTutorial()
    if not _tutFrame then BuildTutorial() end
    _tutIndex = 1
    self:RenderTutorialStep()
    _tutFrame:Show()
end

function CC:FinishTutorial()
    CC:GetUI().tutorialSeen = true
    if _tutFrame then _tutFrame:Hide() end
end